# Overview
This document provides a detailed description of the Function App configuration, including the properties, modules, and conditions used in the Bicep template. The goal is to explain the setup in a simple and clear manner, suitable for both technical and non-technical audiences.

## Metadata
The metadata section provides basic information about the module:
*	Name: Function App Configuration
*	Description: This module configures Function App resources including the Function App itself, diagnostic settings, and resource locks.
*	Version: 1.0.0
*	Project: Melbourne Water Azure Integration Services Implementation

# Parameters
The template uses several parameters to configure the Function App resources. Parameters are like inputs that you provide to customize the deployment.
1.	faProperties: Object that contains all the Function App properties.
2.	peProperties: An array of objects that contains all the Private Endpoint properties.
3.	utcValue: Used as part of the deployment name to include the time it was deployed. This is automatically set to the current UTC time.

## Parameter Definitions
*	faProperties: Function App properties.
*	peProperties: Private Endpoint properties.
*	utcValue: Current UTC time.

# Function App Modules
The main module for the Function App configuration includes several submodules to set up different aspects of the Function App service. These submodules are crucial for a complete and functional Function App deployment.

## Function App 
The functionapp module is used to create the Function App resource. The Function App is a serverless compute service that enables you to run event-driven code without having to explicitly provision or manage infrastructure.

### Usage
*	functionAppName: The name of the Function App.
*	storageAccountName: The name of the storage account used by the Function App.
*	location: The Azure region where the Function App will be deployed.
*	identityType: The type of identity used for the Function App.
*	userAssignedIdentities: User-assigned identities for the Function App.
*	functionAppPlanSku: The SKU of the App Service Plan.
*	functionAppPlanTier: The tier of the App Service Plan.
*	maximumElasticWorkerCount: The maximum number of elastic workers.
*	functionPlanOS: The operating system of the Function App Plan.
*	functionWorkerRuntime: The runtime stack for the Function App.
*	linuxFxVersion: The Linux FX version for the Function App.
*	minTlsVersion: The minimum TLS version.
*	virtualNetworkSubnetId: The ID of the virtual network subnet.
*	publicNetworkAccess: The public network access setting.
*	clientAffinityEnabled: Indicates if client affinity is enabled.
*	httpsOnly: Indicates if HTTPS-only is enabled.
*	vnetRouteAllEnabled: Indicates if VNet route all is enabled.
*	targetWorkerCount: The target number of workers.
*	netFrameworkVersion: The .NET Framework version.
*	lock: Resource lock for the Function App.

## Diagnostic Settings 
The diagnostic settings is used to create diagnostic settings for the Function App. Diagnostic settings enable you to collect logs and metrics for monitoring and troubleshooting.

### Usage
*	name: The name of the diagnostic settings.
*	scope: The scope of the diagnostic settings, which is the Function App.
*	properties: Properties of the diagnostic settings, including logs, metrics, and destinations (e.g., Log Analytics, Storage Account, Event Hub).

## Resource Lock 
The resource lock is used to create a resource lock for the Function App. Resource locks prevent accidental deletion or modification of the Function App.

### Usage
*	name: The name of the resource lock.
*	scope: The scope of the resource lock, which is the Function App.
*	properties: Properties of the resource lock, including the lock level (e.g., CanNotDelete, ReadOnly).

## Resources Created and Their Linkages
1.	Function App: This submodule creates the Function App resource, which is a serverless compute service that enables you to run event-driven code.
2.	Diagnostic Settings: The diagnostic settings submodule creates diagnostic settings for the Function App, enabling the collection of logs and metrics for monitoring and troubleshooting.
3.	Resource Lock: The resource lock creates a resource lock for the Function App, preventing accidental deletion or modification.

# Summary
This Bicep template configures Function App resources including the Function App itself, diagnostic settings, and resource locks. The template ensures that all necessary configurations are applied based on the provided parameters. The resources created are linked to each other through parameters, ensuring a cohesive and well-integrated deployment. The submodules for the Function App, diagnostic settings, and resource locks are crucial for a complete and functional Function App deployment, allowing for the execution of event-driven code, monitoring, and protection against accidental changes.
