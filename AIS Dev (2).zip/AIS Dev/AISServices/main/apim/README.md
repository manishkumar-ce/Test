# Overview
This document provides a detailed description of the Azure API Management (APIM) main module configuration, including the properties, modules, and conditions used in the Bicep template. The goal is to explain the setup in a simple and clear manner.

## Target Scope
The target scope for this deployment is set to the resource group level:
targetScope = 'resourceGroup'
This means all resources defined in this template will be deployed within a specific Azure resource group.

# Parameters
The template uses several parameters to configure the APIM service and related resources:
1.	apimProperties: An object containing all the properties required to configure the APIM service.
2.	dnsProperties: An array of objects containing properties for configuring Private DNS Zones.
3.	utcValue: A string representing the current UTC time, used to uniquely name resources.

# APIM Service Module
The main module for the APIM service is defined as follows:

## Explanation of Parameters
*	name: The name of the APIM service, which includes the APIM name and the current UTC time for uniqueness.
*	scope: The resource group where the APIM service will be deployed.
*	params: A set of parameters passed to the APIM service module to configure it.

Check the module for a complete list of parameters used.

## Detailed Parameter Descriptions
* apimServiceName: The name of the APIM service.
* location: The Azure region where the APIM service will be deployed. Defaults to 'australiasoutheast' if not specified.
* skuName: The SKU (pricing tier) of the APIM service (e.g., Developer, Basic, Standard, Premium).
* skuCapacity: The capacity of the SKU, which determines the number of units.
* tags: Tags to categorize and organize the APIM service.
* additionallocations: Additional locations for the APIM service if it is deployed in multiple regions.
* virtualNetworkType: The type of virtual network integration (e.g., None, External, Internal).
* subnetResourceId: The resource ID of the subnet where the APIM service will be deployed if using virtual network integration.
* customProperties: Custom properties for the APIM service.
* enableClientCertificate: A boolean flag to enable or disable client certificate authentication.
* disableGateway: A boolean flag to disable the gateway.
* developerPortalStatus: The status of the developer portal (e.g., enabled, disabled).
* minapiVersion: The minimum API version supported by the APIM service.
* hostnameConfigurations: Configurations for custom hostnames.
* notificationSenderEmail: The email address used for sending notifications.

## Modules and Submodules
The APIM main module calls several submodules to set up different aspects of the APIM service. These submodules are crucial for a complete and functional APIM deployment.

### API Submodule
The serviceApis submodule is used to deploy individual APIs within the APIM service. Each API is configured with various properties such as name, display name, path, protocols, service URL, description, type, version, version description, and revision.

### API Diagnostics Submodule
The serviceAPIDiagnostics submodule is used to create API diagnostics in the APIM service. Diagnostics help in monitoring and troubleshooting APIs by capturing logs and metrics.

### API Version Set Submodule
The serviceapiVersionSet submodule is used to create API version sets in the APIM service. Version sets allow you to manage multiple versions of an API.

### Loggers Submodule
The serviceLoggers submodule is used to create loggers in the APIM service. Loggers are used to send logs to external logging services.

### Authorization Servers Submodule
The serviceauthorizationServers submodule is used to create authorization servers in the APIM service. Authorization servers are used to manage OAuth 2.0 authentication.

### Backends Submodule
The serviceBackends submodule is used to create backends in the APIM service. Backends represent the backend services that the APIs connect to.

### Cache Submodule
The serviceCache submodule is used to create cache configurations in the APIM service. Caching improves performance by storing responses for a specified duration.

### Identity Providers Submodule
The serviceIdentityProviders submodule is used to configure identity providers in the APIM service. Identity providers enable authentication using external services like Azure AD, Facebook, Google, etc.

### Policies Submodule
The servicePolicies submodule is used to apply policies to the APIM service. Policies are used to modify the behavior of APIs, such as adding rate limiting, transforming requests, etc.

### Named Values Submodule
The serviceNamedValues submodule is used to create named values in the APIM service. Named values are used to store configuration settings that can be referenced in policies.

### Subscriptions Submodule
The serviceSubscriptions submodule is used to create subscriptions in the APIM service. Subscriptions allow users to access the APIs.

### Products Submodule
The serviceProducts submodule is used to create products in the APIM service. Products are used to group APIs and manage access.

### Users Submodule
The serviceUsers submodule is used to create users in the APIM service. Users represent the consumers of the APIs.

### Groups Submodule
The serviceGroups submodule is used to create groups in the APIM service. Groups are used to manage user access to APIs.
### Portal Settings Submodule
The servicePortalSettings submodule is used to configure the developer portal settings in the APIM service. The developer portal is a customizable website for API consumers.

### APIM Diagnostics Settings Submodule
The apimDiagnosticsSettings submodule is used to configure diagnostics settings for the APIM service. Diagnostics settings help in monitoring and troubleshooting the APIM service.

### APIM Lock 
The apimLock is used to create a resource lock for the APIM service. Resource locks prevent accidental deletion or modification of the APIM service.

### Outputs
The outputs section provides information about the deployed resources:
*	apimServiceName: The name of the deployed APIM service.
*	apimServiceUrl: The gateway URL of the deployed APIM service.
*	apimServiceDeveloperPortalUrl: The developer portal URL of the deployed APIM service.


## Resources Created and Their Linkages
1.	APIM Service: The primary resource created is the APIM service, which is configured with the properties defined apimProperties. This service allows you to manage and publish APIs to external and internal consumers.
2.	Private DNS Zones: If specified in dnsProperties, private DNS zones are created and linked to the APIM service. These DNS zones help in managing the domain names used by the APIM service.
3.	Virtual Network Integration: If virtualNetworkType is set to 'External' or 'Internal', the APIM service is integrated with a specified subnet in a virtual network. This allows for secure communication between the APIM service and other resources within the virtual network.
4.	Custom Hostnames: The hostnameConfigurations parameter allows for the configuration of custom domain names for the APIM service, making it accessible via user-friendly URLs.
5.	Developer Portal: The developerPortalStatus parameter controls the availability of the developer portal, which provides a user interface for API consumers to discover and use the APIs.

# Summary
This Bicep template configures an Azure API Management (APIM) service with various properties and settings, including SKU, capacity, virtual network integration, custom hostnames, and developer portal status. Additionally, it conditionally deploys private DNS zones based on the dnsProperties parameter. The template ensures that all necessary configurations are applied based on the provided parameters and conditions. The resources created are linked to each other through parameters and conditional logic, ensuring a cohesive and well-integrated deployment.
