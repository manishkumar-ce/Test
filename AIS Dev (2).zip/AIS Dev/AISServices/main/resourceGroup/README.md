# Overview
This document provides a detailed description of the Resource Groups, including the properties, modules, and conditions used in the Bicep template.

## Metadata
The metadata section [defined here](../../_modules/resourceGroup/resourceGroup.bicep) provides basic information about the module:
*	Name: Resource Grop
*	Description: This module configures Resource groups, roles allocation and resource locks.

## Parameters
The template uses several parameters to configure the Logic App Standard resources. Parameters are like inputs that you provide to customize the deployment.
1.	rgProperties: Object that contains all the Resource Group properties.
2.  Role Assignments: An optional list of role assignments to create
3.  utcValue: Used as part of the deployment name to include the time it was deployed. This is automatically set to the current UTC time.


## Summary
This Bicep template configures Resource Group resources and resource locks. The template ensures that all necessary configurations are applied based on the provided parameters. The resources created are linked to each other through parameters, ensuring a cohesive and well-integrated deployment.
