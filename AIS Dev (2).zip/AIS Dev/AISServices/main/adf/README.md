# Azure Data Factory for AIS

### Folder structure and modules usage for ADF

    
    ├── _modules                # Modules consumed by ADF
    │   └── adf.bicep           # Modularized bicep file for ADF
    ├── adf                     # ADF folder
    │   ├── parameters          # Parameter files per environment 
    │   │   └── paramfiles
    │   ├── main.bicep          # Main bicep file calling ADF module
    │   ├── pipeline.yml        # CICD pipeline for deploying ADF to Azure 
    │   └── README.md           # Read me file for ADF

### Azure Pipelines

| Name | Build Status |
| -------------|--------------|
| AIS.AzureDataFactory| [![Build Status](https://dev.azure.com/mwcloud/AIS/_apis/build/status%2FAIS.AzureDataFactory?branchName=feature%2Fadf_updates)](https://dev.azure.com/mwcloud/AIS/_build/latest?definitionId=337&branchName=feature%2Fadf_updates)


