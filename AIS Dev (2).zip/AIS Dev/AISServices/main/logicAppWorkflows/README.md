# Overview
This document provides a detailed description of the AIS logic app workflow and app settings

The metadata section provides basic information about the module:
*	Name: Logic App Workflows and App settings
*	Description: This module configures AIS Logic App worklflows and supporting files, and merges app settings that are used by the workflows.
*	Version: 1.0.0
*	Project: Melbourne Water Azure Integration Services Implementation

# Workflows
Workflows are deployed manually at this point in time due to build issues (2025-05-02)

# App settings
The app settings deployment uses a Bicep template and merges existing app settings from the logic app with new app settings. 
Note: If there are app settings deleted from the list in the parameters then these will NOT be deleted in the Logic App.

The template uses several parameters to configure the Logic App Standard resources. Parameters are like inputs that you provide to customize the deployment.
1.	logicAppName: The name of the Logic App to update settings on.
2.	resourceGroup: The resource group that the Logic App resides in.
3.	appSettings: an object (name/value set) of application settings that are specific to the workflows.
