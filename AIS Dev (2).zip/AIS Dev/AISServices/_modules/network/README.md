# Overview
This document provides a detailed description of the Private DNS Zone configuration, including the properties, modules, and conditions used in the Bicep template. The goal is to explain the setup in a simple and clear manner, suitable for both technical and non-technical audiences.

## Metadata
The metadata section provides basic information about the module:
*	Name: Private DNS Zone
*	Description: This module deploys a Private DNS Zone.
*	Author: Sree Mandiram
*	Date: 25-7-2024
*	Project: Melbourne Water Azure Integration Services Implementation

# Parameters
The template uses several parameters to configure the Private DNS Zone resources. Parameters are like inputs that you provide to customize the deployment.
1.	pdnszName: The name of the Private DNS Zone.
2.	pdnszTags: List of required tags including Owner, Role, Environment, Classification, Application, and Service Type.
3.	pdnszLinkTags: List of required tags for link connections including Owner, Role, Environment, Classification, Application, and Service Type.
4.	registrationEnabled: Determines if auto-registration of virtual machines occurs within the Azure Private DNS Zone.
5.	pdnszVirtualNetworks: One or more virtual network objects to link the Private DNS Zone to.

## Parameter Definitions
*	pdnszName: Name of the Private DNS Zone. Must be in the form of subDomain.domain.root or domain.root format (up to 32 sub-domain labels).
*	pdnszTags: Tags for categorizing and organizing the Private DNS Zone.
*	pdnszLinkTags: Tags for categorizing and organizing the link connections.
*	registrationEnabled: Boolean to enable or disable auto-registration of virtual machines.
*	pdnszVirtualNetworks: Array of virtual network objects to link to the Private DNS Zone.

### Variables
*	location: The location for the Private DNS Zone is set to 'global' as Private DNS Zones and Link Connections are global only.

## Resources
The main module for the Private DNS Zone configuration includes several resources to set up different aspects of the DNS service. These resources are crucial for a complete and functional DNS deployment.

### Private DNS Zone Resource
The privatednszone resource is used to create the Private DNS Zone. A Private DNS Zone allows you to manage and resolve domain names in a virtual network without needing to configure a custom DNS solution.

### Private DNS Zone Virtual Network Links Resource
The privateDnsZoneVirtualNetworkLinks resource is used to create virtual network links within the Private DNS Zone. These links associate virtual networks with the Private DNS Zone for DNS resolution and, optionally, auto-registration of virtual machines.

# Summary
This Bicep template configures Private DNS Zone resources including the Private DNS Zone itself and virtual network links. The template ensures that all necessary configurations are applied based on the provided parameters. The resources created are linked to each other through parameters, ensuring a cohesive and well-integrated deployment. The resources for the Private DNS Zone and virtual network links are crucial for a complete and functional DNS deployment, allowing for secure and efficient name resolution within Azure
