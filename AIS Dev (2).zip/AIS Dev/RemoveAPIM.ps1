# Remove API Management Instance

Remove-AzApiManagement -ResourceGroupName "rg-devtest-ais-ase" -Name "apim-dev-test-ais-ase"