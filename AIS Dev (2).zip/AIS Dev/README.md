# Introduction 
The AIS project code is structured to enhance reusability and streamline the deployment process. Modules are used extensively, with each service having its own modularized Bicep files, such as adf.bicep for Azure Data Factory, apim.bicep for API Management, and so on. These modules are located in the _modules directory and are called by the main Bicep files in their respective service folders. Each service folder, like adf, apim, eventGrid, and others, contains a main.bicep file that orchestrates the deployment by calling the relevant modules and a parameters folder that holds environment-specific parameter files. The deployment flow is controlled by these main files and parameters, ensuring that values are not hardcoded and can be easily updated. Additionally, each service folder includes an azure-pipelines.yml file to define the CI/CD pipeline for deploying the service to Azure. This structure allows for easy reuse of code snippets across different jobs or pipelines, minimizing the need for redundant code and simplifying the deployment process. Different deployment environments are managed using the “Environment” sections of Azure Pipelines, which also facilitate approvals and checks before deployments.

# Module/Main Structure

### Folder structure and modules usage for the AIS project

    
    ├── _modules                             # Modules for AIS Project
    ├── adf   
    │   └── adf.bicep                        # Modularized bicep file for ADF
    ├── apim
    │   └── service                          # Modularized bicep file for APIM Service and its sub modules
    │       └── api 
    │       └── apiVersionSet
    │       └── authorizationServer
    │       └── backend
    │       └── cache
    │       └── group
    │       └── identityProvider
    │       └── loggers
    │       └── namedValue
    │       └── policy
    │       └── portalSetting
    │       └── product
    │       └── subscription
    │       └── users
    │       └── apim.bicep                   
    ├── eventGrid                           # Modularized bicep file for Event Grid and its sub modules
    │   └── domain
    │       └── domain.bicep
    │       └── domainTopic.bicep
    │   └── systemTopic
    │       └── systemTopic.bicep
    │       └── systemTopicEventSubscription.bicep
    │   └── topic
    │       └── topic.bicep
    │       └── topicEventSubscription.bicep
    ├── eventHub
    │   └── modules                          # Modularized bicep file for Event Hub Namespace and its sub modules
    │       └── eventHub.bicep
    │       └── eventHubAuthorisationRules.bicep
    │       └── eventHubConsumergroups.bicep
    │       └── namespaceAuthorisationRules.bicep
    │   └── eventHubNamespace.bicep          # Modularized bicep file for Event Hub Namespace
    ├── functionApp
    │   └── functionApp.bicep                # Modularized bicep file for Function App
    ├── keyVault  
    │   └── keyVault.bicep                   # Modularized bicep file for KeyVault
    │   └── key.bicep                        # Modularized bicep file for Keys in the KeyVault
    │   └── secret.bicep                     # Modularized bicep file for Secrets in the KeyVault
    │   └── accessPolicy.bicep               # Modularized bicep file for accesspolicy 
    ├── logicApp
    │   └── logicAppStandard.bicep           # Modularized bicep file for Standard Logic App
    ├── monitor
    │   └── diagnosticSettings.bicep         # Modularized bicep file for Diagnostic Settings for resources
    ├── network
    │   └── dns
    │      └── privateDNSZone.bicep          # Modularized bicep file for Azure Private DNS Zone
    │      └── privateDnsRecord.bicep        # Modularized bicep file for Private DNS Records
    │   └── privateEndPoint
    │       └── privateEndPoint.bicep        # Modularized bicep file for Private Endpoint
    ├── serviceBus
    │   └── modules
    │       └── authorisationRule
    │           └── authorisationRules.bicep # Modularized bicep file for Service Bus Authorisation Rules
    │       └── queue
    │           └── authorisationRules.bicep # Modularized bicep file for Queue Authorisation Rules    
    │           └── queue.bicep              # Modularized bicep file for Queues
    │       └── topic
    │           └── authorisationRules.bicep # Modularized bicep file for Queue Authorisation Rules     
    │           └── subscription.bicep       # Modularized bicep file for Subscription
    │           └── topic.bicep              # Modularized bicep file for Topic
    │   └── serviceBus.bicep                 # Modularized bicep file for Service Bus
    ├── storageAccount
    │   └── modules  
    │       └── blobcontainer.bicep          # Modularized bicep file for Blob Container
    │       └── fileshare.bicep              # Modularized bicep file for File Share
    │       └── table.bicep                  # Modularized bicep file for Table Service
    │   └── storageAccount.bicep             # Modularized bicep file for Storage Account

    ├── main                                 # Main folder
    ├   ├── adf                              # ADF folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling ADF module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying ADF to Azure 
    ├   ├── apim                             # APIM folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling APIM module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying APIM to Azure 
    ├   ├── eventGrid                        # eventGrid folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling Event Grid module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying Event Grid to Azure 
    ├   ├── eventHub                         # eventHub folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling eventHub module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying eventHub to Azure 
    ├   ├── functionApp                      # functionApp folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling functionApp module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying functionApp to Azure 
    ├   ├── keyVault                         # keyVault folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling keyVault module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying keyVault to Azure 
    ├   ├── logicApp                         # logicApp folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling logicApp module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying logicApp to Azure 
    ├   ├── network                          # network folder
    │       ├── dns          
    │       │   └── main.bicep               # Main bicep file calling network resources module
    ├   ├── serviceBus                       # serviceBus folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling serviceBus module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying serviceBus to Azure 
    ├   ├── storageAccount                   # storageAccount folder
    │       ├── parameters                   # Parameter files per environment 
    │       │   └── paramfiles
    │       ├── main.bicep                   # Main bicep file calling storageAccount module
    │       ├── azure-pipelines.yml          # CICD pipeline for deploying storageAccount to Azure 



# Azure Pipelines

The Azure pipelines are set up using the azure-pipelines.yml file located in the Service Main folder. These pipelines are configured to not run automatically, as this is an Infrastructure as Code (IaC) deployment, and we want to avoid triggering the pipelines with every commit to the repository. Each pipeline runs on a Microsoft-hosted Ubuntu agent and is divided into three distinct stages for Dev Test deployments.

### Stage: SecurityScanner

This stage serves as a prerequisite for all pipeline activities to ensure adherence to security best practices. The SecurityScanner stage runs a job called “Run security scanner,” which checks out the source code and executes the Microsoft Security DevOps tool with the ‘azuredevops’ policy, utilizing the ‘iacfilescanner’ and ‘templateanalyzer’ tools. This setup ensures that the code undergoes security scanning without breaking the pipeline if issues are detected, allowing for continuous integration and delivery. However, the ultimate goal is to halt the deployment by breaking the pipeline at this security scan stage if any issues are found, ensuring that only production-ready and securely deployed Azure services are created using the pipeline and IaC modules.

### Stage: RunWhatIfStage

The RunWhatIf job in this pipeline stage performs a “what-if” deployment validation using the Azure CLI. It executes a Bash script to check for potential changes in a specified resource group without actually applying them. The script runs in incremental mode, utilizing a defined Bicep template and parameters file. This job helps identify any issues or unexpected changes before the actual deployment, ensuring a smoother and more predictable process. Reviewers can examine the results from this RunWhatIf job to ensure that only intended changes are applied to the Azure resources, and they can choose to accept or reject the changes after validation. The template and parameters files are passed as variables in the pipeline to avoid hardcoding values, allowing the same template file to be reused in other jobs or pipelines by simply updating the variable values. This approach eliminates the need to create a new WhatIf job from scratch, enabling easy reuse of code snippets with minimal modifications.

### Stage: DeployToDevTest

The DeployToDevTest stage in the pipeline is designed to deploy resources to the DevTest environment. It depends on the successful completion of the RunWhatIfStage and only runs if the pipeline has succeeded and is executed from the main branch of the AIS repository. This ensures that during development work using a forked branch (e.g., develop), unnecessary services are not accidentally deployed to the Dev environment. The stage includes a deployment job named Dev, which checks out the source code and runs an Azure CLI task to create a deployment in the specified resource group using an ARM template and parameters file. The deployment is performed in incremental mode, ensuring that only new or changed resources are deployed, while existing resources not present in the template file remain unaffected. The template and parameters files are passed as variables in the pipeline to avoid hardcoding values, allowing the same template file to be reused in other jobs or pipelines by simply updating the variable values. This approach eliminates the need to create a new deployment job from scratch, enabling easy reuse of code snippets with minimal modifications. Different deployment environments are configured using the “Environment” sections of Azure Pipelines, allowing for special deployment jobs and the configuration of approvals and checks before each deployment is carried out in the respective environments.

# Naming Convention Format

`<ResourceType>-<Environment>-<Region+Zone>-<Project:Optional>-<ApplicationName>` 
 
e.g. rg-devtest-ase-ais

## Resource Type Abbreviatons
- rg:             Resource group
- eh:             event hubs
- func:           function app
- la:             logic app
- kv:             key vault
- apim:           api management service
- pri:            private endpoint
- rt:             route table
- sb:             service bus
- st:             storage account
- log:            Log analytics
- privatelink:    Private DNS Zone
- nic:            network interface (or are we happy to group this with provate endpoint?)
