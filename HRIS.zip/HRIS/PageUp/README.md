# Introduction 
This logic app project contains workflows fulfilling Pageup integrations
- 235 Organisation Hierarchy Data
- 234 Cost Center Data
- 232 Position Data
- 233 User Data 
- 275 Job Requisition
- 239 Offered Apllicant

# Getting Started
Pageup has a dependence on the AIS projects that is setup using Git submodules. 
after you check out this project you need to retriev the AIS submodlule by runnning these git commands 

`$ git submodule init`

`$ git submodule update`

If you neeed to point to another AIS branch, other than the default main branch, then you can make that change in the .gitmodules file
After you update the .gitmodule file this will pull the latest commit from the AIS repo
 
`git submodule update --init --recursive --remote`
 
# API references
[Dayforce developer docs](https://developers.dayforce.com)
[Pageup developer docs](https://developers.pageuppeople.com/Api)

# Workflow file structure for Azure deployment
We are using a tool called zip deploy in our Infrastructure As Code (IAC) to deploy our workflows to Azure. 
For this to function we need a specified folder and file structure to be adheared to. 
There are two sections to this
- Workflow definition 
- Deployment yml file

## Workflow definition
At the root of the project we will need a file structure like this

```
main\LogicApp
|   workflow1
|   |   workflow1.json
|   workflow2
|   |   workflow2.json
|
|   connections.json (shared across workflows)
|   parameters.json (shared across workflows)
```

Each workflow will get its own folder containing the workflow.json and there will be shared connections and param values across workflows.

## Deployment step

The main things to take note of here are
`pool: HRIS-Dev` This needs to be our on prem build agent, otherwise deployment will fail

[Deployment pipeline for Pageup Logic App](https://dev.azure.com/mwcloud/HRIS/_build?definitionId=362)
