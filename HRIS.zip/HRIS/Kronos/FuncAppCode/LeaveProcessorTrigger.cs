using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using CsvHelper;
using System.Globalization;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Text;
using Azure.Data.Tables;

namespace MW.HRIS
{
    public class LeaveProcessorTrigger
    {
        private readonly ILogger<LeaveProcessorTrigger> _logger;
        private static readonly string? _apimBaseUrl = Environment.GetEnvironmentVariable("ApimBaseUrl");
        private static readonly string? _apimKey = Environment.GetEnvironmentVariable("ApimSubscriptionKey");
        private static readonly string? _accountsTbl = Environment.GetEnvironmentVariable("AccountsTableName");
        private static readonly string? _errorEmail = Environment.GetEnvironmentVariable("ErrorEmail");         
        private static bool _validated = false;
        private static Dictionary<string, long> _leaveCategories = [];
        private static Dictionary<string, long> _employeeAccounts = [];
        private static HttpClient _httpClient;
        private static TableClient _tableClient;

        public LeaveProcessorTrigger(ILogger<LeaveProcessorTrigger> logger)
        {
            _logger = logger;
            _validated = EnvVarsValidation();
        }

        [Function(nameof(LeaveProcessorTrigger))]
        public async Task Run([BlobTrigger("hris-employeeleave/{name}", Connection = "AzureWebJobsStorage")] Stream stream, string name)
        {
            if (_validated)
            {
                InitiateEmployeeAccounts();
                _httpClient = GetKronosClient();
            }
            else
            {
                return;
            }

            var rawList = await GetTimeEntriesFromCsv(stream);
            _logger.LogInformation("Leave processor function processed file {fileName}", name);

            await InitiateLeaveCategoriesAsync();
            TimeEntrySet[]? sets = await ParseTimeEntrySets(rawList);
            if (sets is null)
            {
                return;
            }

            _logger.LogInformation("Sending Time entries collection data for {count} employees", sets.Length);
            var result = await PutLeaveDataAsync(sets);
            _logger.LogInformation("Sending Time entries collection data result: {result}", result);
            _httpClient.Dispose();
        }

        private bool EnvVarsValidation()
        {
            var envVars = new string[] { _apimBaseUrl, _apimKey, _accountsTbl, _errorEmail };
            bool isValidated = true;

            foreach (var envVar in envVars)
            {
                if (string.IsNullOrEmpty(envVar))
                {
                    _logger.LogWarning($"Environment variable value is missing to run LeaveProcessor");
                    isValidated = false;
                    break;
                }
            }

            return isValidated;
        }

        private static HttpClient GetKronosClient()
        {
            var client = new HttpClient() { BaseAddress = new Uri(_apimBaseUrl) };
            client.DefaultRequestHeaders.Add("ocp-apim-subscription-key", _apimKey);
            var token = Environment.GetEnvironmentVariable("token");
            if (!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            return client;
        }

        private async Task<TimeEntrySet[]?> ParseTimeEntrySets(List<KronosTimeEntry> rawList)
        {
            try
            {
                var employeeGroups = rawList.GroupBy(g => g.EmployeeId)
                                    .Select(group => new
                                    {
                                        EmployeeId = group.Key,
                                        Entries = group.Select(kronosEntry => ConvertTimeEntry(kronosEntry))
                                                    .OrderBy(e => e.Date).ToList()
                                    });
                var groupCnt = employeeGroups.Count();
                if (groupCnt == 0)
                {
                    _logger.LogWarning("No employee data found while parsing file");
                    return null;
                }

                var sets = new TimeEntrySet[groupCnt];
                var index = 0;
                foreach (var employeeEntries in employeeGroups)
                {
                    if (employeeEntries.Entries.Count > 0)
                    {
                        var timeEntrySet = new TimeEntrySet
                        {
                            Employee = new Employee { AccountId = LookupAccountId(employeeEntries.EmployeeId) },
                            TimeEntries = employeeEntries.Entries,
                            StartDate = employeeEntries.Entries.First().Date,
                            EndDate = employeeEntries.Entries.Last().Date
                        };
                        sets[index] = timeEntrySet;
                        index++;
                    }
                }
                return sets;
            }
            catch (Exception ex)
            {
                var errMsg = $"Error parsing leave file: {ex.Message}";
                _logger.LogWarning(errMsg);

                await SendErrorMessageAsync(new MessageDetails()
                {
                    HtmlBody = $"<p>{errMsg}</p>",
                    RecipientAddress = _errorEmail
                });
                return null;
            }
        }

        private async Task<List<KronosTimeEntry>> GetTimeEntriesFromCsv(Stream stream)
        {
            var records = new List<KronosTimeEntry>();
            var cancellationToken = new CancellationToken();
            try
            {
                using var reader = new StreamReader(stream);
                using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

                await foreach (var record in csv.GetRecordsAsync<KronosTimeEntry>(cancellationToken))
                {
                    records.Add(record);
                }
            }
            catch (Exception ex)
            {
                var errMsg = $"Error parsing employee leave CSV file: {ex.Message}";
                _logger.LogWarning(errMsg);
                var message = new MessageDetails()
                {
                    HtmlBody = $"<p>{errMsg}</p>",
                    RecipientAddress = _errorEmail
                };
                await SendErrorMessageAsync(message);
            }

            _logger.LogInformation("Function parsed {cnt} records", records.Count);
            return records;
        }

        private async Task<string> PutLeaveDataAsync(TimeEntrySet[]? sets)
        {
            var data = new TimeEntrySets() { Sets = sets };
            try
            {
                var jsonContent = JsonConvert.SerializeObject(data);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync("v1/kronos/timeEntries", content);
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync();

                return result;
            }
            catch (Exception ex)
            {
                var errMsg = $"Time entries data update failed: {ex.Message}";
                await SendErrorMessageAsync(new MessageDetails()
                {
                    HtmlBody = $"<p>{errMsg}</p>",
                    RecipientAddress = _errorEmail
                });
                return $"{errMsg} \nData:{data}";
            }
        }

        private async Task InitiateLeaveCategoriesAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("v1/kronos/timeoffs");
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync();

                var cats = JsonConvert.DeserializeObject<LeaveCategories>(result) ?? throw new Exception("Fail to retrieve Kronos time offs");
                foreach (LeaveCategory cat in cats.Categories)
                {
                    if (string.IsNullOrEmpty(cat.Code) || !cat.Visible || IsLeaveExcluded(cat))
                    {
                        continue;
                    }
                    _leaveCategories[cat.Code] = cat.Id;
                }
                _logger.LogInformation("LeaveCategories initiated with {count} entries", _leaveCategories.Count);
            }
            catch (Exception ex)
            {
                var errMsg = $"LeaveCategories initiation failed: {ex.Message}";
                _logger.LogWarning(errMsg);

                await SendErrorMessageAsync(new MessageDetails()
                {
                    HtmlBody = $"<p>{errMsg}</p>",
                    RecipientAddress = _errorEmail
                });
            }
        }

        private void InitiateEmployeeAccounts()
        {
            try
            {
                var tblConnStr = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
                _tableClient = new TableClient(tblConnStr, _accountsTbl);

                var latest = _tableClient.Query<TableEntity>(entity => entity.PartitionKey == Constants.AccountsTblPartitionKey).LastOrDefault();

                var json = latest.GetString("Json");
                string[] rows = json.Split(new[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 1; i < rows.Length; i++) // skip header row
                {
                    string[] columns = rows[i].Split(',');
                    var accountId = long.Parse(columns[1].Trim('"'));
                    _employeeAccounts[columns[0].Trim('"')] = accountId;
                }
                _logger.LogInformation("Processed {count} Employee Account Lookup", _employeeAccounts.Count);
            }
            catch (System.Exception ex)
            {
                _logger.LogWarning("EmployeeAccounts initiation failed: {message}", ex.Message);
            }
        }

        private long LookupAccountId(string employeeId)
        {
            if (_employeeAccounts.TryGetValue(employeeId, out long accountId))
            {
                return accountId;
            }
            _logger.LogWarning("Unable to find a matching account Id for employee: {employeeId}", employeeId);
            return 0;
        }

        private static TimeEntry ConvertTimeEntry(KronosTimeEntry kronosEntry)
        {
            var entry = new TimeEntry()
            {
                Date = DateTime.Parse(kronosEntry.Date).ToString(Constants.KronosDateFormat),
                Total = (int)(kronosEntry.Total * 3600000) // hour to millisecond
            };
            if (kronosEntry.Type != null && _leaveCategories.TryGetValue(kronosEntry.Type, out long catId))
            {
                entry.TimeOff = new TimeOff() { Id = catId };
            }
            return entry;
        }

        private static bool IsLeaveExcluded(LeaveCategory leave)
        {
            return leave.Code == Constants.SickLeaveCode && leave.Name == Constants.SickLeaveNameExcluded;
        }

        private async Task SendErrorMessageAsync(MessageDetails messageDetails)
        {
            try
            {
                var jsonContent = JsonConvert.SerializeObject(messageDetails);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync("v1/utility/messages", content);
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to send error message");
            }
        }

    }
}