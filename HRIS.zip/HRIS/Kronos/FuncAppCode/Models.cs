using CsvHelper.Configuration.Attributes;
using Newtonsoft.Json;

namespace MW.HRIS
{
    #region Kronos218
    public class EmployeeTimeEntry
    {
        public string? RateCode { get; set; } = "B";
        public bool Replace => false;
        [Name("Employee_Number")]
        public string? EmployeeXRefCode { get; set; }
        public string? SALARY_CLASS { get; set; }
        [Name("Hours")]
        public string? HoursString { get; set; }
        public decimal Hours { get; set; }
        [Name("Allow_Code")]
        public string? CodeXRefCode { get; set; }
        [Name("Pay_End_Date")]
        public string? BusinessDate { get; set; }
        public double? RateValue { get; set; }
    }

    public class ImportTimeData
    {
        public string ImportSetName => "Kronos Time Import";
        public string SourceSystem => "UKG Kronos";
        public string ImportIdentifier => $"Kronos_{DateTime.Today.Date}";
        public string PayGroupXrefCode => "MW_FORTNIGHTLY";
        public int ErrorOnAction => 1;
        public bool AutoDetectPayGroup => true;
        public bool DeleteImportedData => true;
        public required EmployeeTimeEntry[] DataEntries { get; set; }
    }
    #endregion

    #region Kronos251
    public class KronosTimeEntry
    {
        [Name("Employee ID")]
        public string? EmployeeId { get; set; }
        [Name("Time Off")]
        public string? Type { get; set; }
        public string? Date { get; set; }
        [Name("Hours")]
        public decimal Total { get; set; }
    }

    public class TimeEntrySets
    {
        [JsonProperty("time_entry_sets")]
        public TimeEntrySet[]? Sets { get; set; }
    }

    public class TimeEntrySet
    {
        [JsonProperty("employee")]
        public Employee? Employee { get; set; }
        [JsonProperty("start_date")]
        public String StartDate { get; set; }
        [JsonProperty("end_date")]
        public String EndDate { get; set; }
        [JsonProperty("time_entries")]
        public List<TimeEntry>? TimeEntries { get; set; }
    }

    public class Employee
    {
        [JsonProperty("account_id")]
        public long AccountId { get; set; }
    }

    public class TimeEntry
    {
        [JsonProperty("date")]
        public String Date { get; set; }
        [JsonProperty("type")]
        public string? Type { get; set; } = "TIME";
        [JsonProperty("total")]
        public int Total { get; set; }
        [JsonProperty("time_off")]
        public TimeOff? TimeOff { get; set; }
    }

    public class TimeOff
    {
        [JsonProperty("id")]
        public long Id { get; set; }
    }
    public class LeaveCategory
    {
        [JsonProperty("id")]
        public long Id { get; set; }
        [JsonProperty("parent_id")]
        public long ParentId { get; set; }
        [JsonProperty("name")]
        public required string Name { get; set; }
        [JsonProperty("payroll_code")]
        public required string Code { get; set; }
        [JsonProperty("visible")]
        public required bool Visible { get; set; }
    }
    public class LeaveCategories
    {
        [JsonProperty("time_offs")]
        public LeaveCategory[] Categories { get; set; }
    }
    #endregion

    public class MessageDetails
    {
        [JsonProperty("htmlBody")]
        public string HtmlBody { get; set; }
        [JsonProperty("impact")]
        public string Impact { get; set; }
        [JsonProperty("recipientAddress")]
        public string RecipientAddress { get; set; }
    }
}
