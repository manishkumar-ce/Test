using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.ApplicationInsights;

var builder = FunctionsApplication.CreateBuilder(args);

builder.ConfigureFunctionsWebApplication();

builder.Services
    .AddApplicationInsightsTelemetryWorkerService()
    .ConfigureFunctionsApplicationInsights();

// Remove the default logging filter that captures only warnings and more severe logs for Application Insights
// https://learn.microsoft.com/en-us/azure/azure-functions/dotnet-isolated-process-guide?tabs=ihostapplicationbuilder%2Cwindows#managing-log-levels
string appInsightLoggerProviderName = "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider";
builder.Services.Configure<LoggerFilterOptions>(options =>
{
    var defaultLoggingFilter = options.Rules.FirstOrDefault(rule =>
        rule.ProviderName == appInsightLoggerProviderName);
    if (defaultLoggingFilter != null)
    {
        options.Rules.Remove(defaultLoggingFilter);
    }
});

builder.Build().Run();
