using Newtonsoft.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System.Net.Http.Headers;
using System.Text;
using Azure.Data.Tables;
using CsvHelper;
using System.Globalization;

namespace MW.HRIS
{
    public class DatBlobTrigger
    {
        private readonly ILogger<DatBlobTrigger> _logger;
        private static readonly string? _apimKey = Environment.GetEnvironmentVariable("ApimSubscriptionKey");
        private readonly TableClient _tableClient;
        private static readonly Dictionary<string, double?> rateDictionary = [];
        private readonly List<string> systemProperties = ["PartitionKey", "RowKey", "Timestamp", "odata.etag"];

        public DatBlobTrigger(ILogger<DatBlobTrigger> logger)
        {
            _logger = logger;
            var rateTbl = Environment.GetEnvironmentVariable("RateTableName");
            var tblConnStr = Environment.GetEnvironmentVariable("AzureWebJobsStorage");

            _logger.LogInformation($"Initiating table client and rate lookup");
            _tableClient = new TableClient(tblConnStr, rateTbl);
            InitRateLookup();
        }


        [Function(nameof(DatBlobTrigger))]
        public async Task Run([BlobTrigger("kronos-payroll/{name}", Connection = "SftpConnection")] Stream stream, string name)
        {
            _logger.LogInformation($"DAT Blob trigger function processing file: {name}, size: {stream.Length} bytes");
            var records = await GetTimeEntriesFromCsv(stream);

            if(records.Count == 0)
            {
                _logger.LogInformation($"No time entries found from file {name}, abort");
                return;
            }
            
            records
                .Where(x => !string.IsNullOrEmpty(x.SALARY_CLASS))
                .ToList()
                .ForEach(record => LookupRate(record));

            var payload = new ImportTimeData() {
                DataEntries = [.. records]
            };
            var result = await ImportTimeData(payload);
            _logger.LogInformation(result);
        }

        private void InitRateLookup()
        {
            var entities = _tableClient.Query<TableEntity>(entity => entity.PartitionKey == Constants.RateTblPartitionKey);
            
            foreach (var entity in entities)
            {
                foreach (var property in entity)
                {
                    if(!systemProperties.Contains(property.Key))
                    {
                        var subclass = GetSubClass(entity.RowKey, property.Key);
                        rateDictionary[entity.RowKey + subclass] = entity.GetDouble(property.Key);
                        _logger.LogInformation($"SALARY_CLASS: {entity.RowKey + subclass}, RateValue: {property.Value}");
                    }
                }
            }
        }

        // the subclass of salary_class starts with a delimiter followed by the subclass number with is part of the azure table column header
        // e.g. WLD5.1 has a subclass of .1, while JSP2/4 has a subclass of /4
        private static string GetSubClass(string rowHeader, string colHeader)
        {
            var delimiter = rowHeader.Contains(Constants.SecondaryCodePrefix) ? Constants.SecondaryDelimiter : Constants.PrimaryDelimiter;
            return delimiter + colHeader.Replace(Constants.RateEntityPrefix, string.Empty);
        }

        private async Task<List<EmployeeTimeEntry>> GetTimeEntriesFromCsv(Stream stream)
        {
            int cnt = 0;
            var records = new List<EmployeeTimeEntry>();

            try
            {
                cnt = await ParseDatCsv(stream, records);
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"Error parsing Csv file: {ex.Message}");
            }

            _logger.LogInformation($"Converted {records.Count} out of {cnt} records");
            return records;
        }

        private async Task<int> ParseDatCsv(Stream stream, List<EmployeeTimeEntry> records)
        {
            int cnt = 0;
            var config = new CsvHelper.Configuration.CsvConfiguration(CultureInfo.InvariantCulture)
            {
                MissingFieldFound = null
            };
            using var reader = new StreamReader(stream);
            using var csv = new CsvReader(reader, config);
            await csv.ReadAsync();
            csv.ReadHeader();

            while (await csv.ReadAsync())
            {
                cnt++;
                var record = csv.GetRecord<EmployeeTimeEntry>();
                if (record is null)
                {
                    _logger.LogWarning($"Unable to parse record number {cnt}");
                }
                else
                {
                    records.Add(record);
                }
            }

            return cnt;
        }

        private static void LookupRate(EmployeeTimeEntry record)
        {
            if(record.SALARY_CLASS is null)
                return;

            if(rateDictionary.TryGetValue(record.SALARY_CLASS, out double? rateValue))
            {
                record.RateValue = rateValue;
                record.RateCode = null;
            }
        }

        private static async Task<string> ImportTimeData(ImportTimeData timeData)
        {
            var client = new HttpClient();
                client.DefaultRequestHeaders.Add("ocp-apim-subscription-key", _apimKey);
            var token = Environment.GetEnvironmentVariable("token");
            if(!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }

            var jsonContent = JsonConvert.SerializeObject(timeData);
            try
            {
                var baseUrl = Environment.GetEnvironmentVariable("ApimBaseUrl");;                
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
                var response = await client.PostAsync($"{baseUrl}v1/dayforce/Imports/TimeData", content);
                response.EnsureSuccessStatusCode();
                var result = response.Content.ReadAsStringAsync();

                return result.Result;
            }
            catch (Exception ex)
            {
                return $"Time data import failed: {ex.Message} \nPayload:{jsonContent}";
            }
        }
    }

}