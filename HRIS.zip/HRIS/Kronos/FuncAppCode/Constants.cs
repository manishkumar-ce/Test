namespace MW.HRIS
{
    public static class Constants
    {
        public const string RateTblPartitionKey = "RateSetLookup";
        public const string AccountsTblPartitionKey = "AccountLookup";
        public const string RateEntityPrefix = "XRefCode";
        public const string PrimaryDelimiter = "/";
        public const string SecondaryDelimiter = ".";
        public const string SecondaryCodePrefix = "WLD";
        public const string KronosDateFormat = "yyyy-MM-dd";
        public const string SickLeaveCode = "SIC";
        public const string SickLeaveNameExcluded = "Sick Leave With Cert";
    }
}