# Introduction 
This logic app project contains workflows fulfilling Kronos integration #251, 252, 252b, 218 and 274(new).

# Getting Started
Kronos has a dependence on the AIS projects that is setup using Git submodules. 
after you check out this project you need to retriev the AIS submodlule by runnning these git commands 

`$ git submodule init`

`$ git submodule update`

If you neeed to point to another AIS branch, other than the default main branch, then you can make that change in the .gitmodules file
After you update the .gitmodule file this will pull the latest commit from the AIS repo
 
`git submodule update --init --recursive --remote`
 
# API references
https://developers.dayforce.com/
https://secure.workforceready.com.au/

# Workflow file structure for Azure deployment
We are using a tool called zip deploy in our Infrastructure As Code (IAC) to deploy our workflows to Azure. 
For this to function we need a specified folder and file structure to be adheared to. 
There are two sections to this
- Workflow definition 
- Deployment yml file

## Workflow definition
At the root of the project we will need a file structure like this

```
LogicApp
|   workflow1
|   |   workflow1.json
|   workflow2
|   |   workflow2.json
|
|   connections.json (shared across workflows)
|   parameters.json (shared across workflows)
```

Each workflow will get its own folder containing the workflow.json and there will be shared connections and param values across workflows.

## Deployment step

The main things to take note of here are
`pool: HRIS-Dev` This needs to be our on prem build agent, otherwise deployment will fail

```
variables:
    logicAppName: 'la-devtest-ase-hris-integrationName'
    serviceConnectionDev: 'azure.devtest-HRIS'
    resourceGroupNameDev: 'rg-devtest-ase-HRIS'

stages:  
#zip deploy stage (workflow deployment)
  - stage: 'ZipDeployIntegrationName'
    dependsOn: DeployToDevTest
    displayName: Deploy Logic App (zip deploy) (Integration Name)
    pool: HRIS-Dev
    jobs:
    - job: DeployLogicApp
      displayName: Deploy Logic App via Zip Deploy
      steps:
      - task: ArchiveFiles@2
        displayName: Zip Logic App Files
        inputs:
          rootFolderOrFile: '$(System.DefaultWorkingDirectory)/LogicApp'
          includeRootFolder: false
          archiveType: 'zip'
          archiveFile: '$(System.DefaultWorkingDirectory)/integrationLogicApp.zip'
          replaceExistingArchive: true
      - task: AzureWebApp@1
        displayName: Deploy Logic App Zip
        inputs:
          azureSubscription: $(serviceConnectionDev)
          appType: 'webApp'
          appName: $(logicAppName)
          resourceGroupName: $(resourceGroupNameDev)
          package: '$(System.DefaultWorkingDirectory)/integrationLogicApp.zip'
```
