# Overview
This document provides a detailed description of the Key Vault configuration, including the properties, modules, and conditions used in the Bicep template. The goal is to explain the setup in a simple and clear manner, suitable for both technical and non-technical audiences.

## Metadata
The metadata section provides basic information about the module:
*	Name: Key Vault Configuration
*	Description: This module configures Key Vault resources including the Key Vault itself, keys, secrets, and access policies.
*	Version: 1.0.0
*	Project: Melbourne Water Azure Integration Services Implementation

# Parameters
The template uses several parameters to configure the Key Vault resources. Parameters are like inputs that you provide to customize the deployment.
1.	kvProperties: Object that contains all the Key Vault properties.
2.	peProperties: An array of objects that contains all the Private Endpoint properties.
3.	utcValue: Used as part of the deployment name to include the time it was deployed. This is automatically set to the current UTC time.

## Parameter Definitions
*	kvProperties: Key Vault properties.
*	peProperties: Private Endpoint properties.
*	utcValue: Current UTC time.

# Key Vault Modules
The main module for the Key Vault configuration includes several submodules to set up different aspects of the Key Vault service. These submodules are crucial for a complete and functional Key Vault deployment.

## Key Vault Submodule
The keyVault submodule is used to create the Key Vault resource. Key Vault is used to safeguard cryptographic keys and secrets used by cloud applications and services. Check the module for a complete list of parameters used.

### Usage
*	kvName: The name of the Key Vault.
*	location: The Azure region where the Key Vault will be deployed.
*	skuName: The SKU name for the Key Vault.
*	skuFamily: The SKU family for the Key Vault.
*	tags: Tags to categorize and organize the Key Vault.
*	bypass: Network ACL bypass setting.
*	defaultAction: Network ACL default action.
*	NetworkAclsIpRules: Network ACL IP rules.
*	NetworkAclsVirtualNetworkRules: Network ACL virtual network rules.
*	accessPolicies: Access policies for the Key Vault.
*	enabledForDeployment: Indicates if the Key Vault is enabled for deployment.
*	enabledForDiskEncryption: Indicates if the Key Vault is enabled for disk encryption.
*	enabledForTemplateDeployment: Indicates if the Key Vault is enabled for template deployment.
*	enableSoftDelete: Indicates if soft delete is enabled.
*	softDeleteRetentionInDays: The number of days to retain soft-deleted items.
*	enablePurgeProtection: Indicates if purge protection is enabled.
*	publicNetworkAccess: Indicates if public network access is enabled.
*	enableRbacAuthorization: Indicates if RBAC authorization is enabled.
*	createMode: The create mode for the Key Vault.
*	lock: Resource lock for the Key Vault.
*	tenantId: The tenant ID.

## Keys Submodule
The keys submodule is used to create keys within the Key Vault. Keys are used for encryption and decryption operations.

### Usage
*	keyName: The name of the key.
*	keyType: The type of the key (e.g., RSA, EC).
*	keySize: The size of the key.
*	keyOps: The operations that can be performed with the key (e.g., encrypt, decrypt, sign, verify).
*	enabled: Indicates if the key is enabled.
*	expiresOn: The expiration date of the key.
*	notBefore: The date before which the key cannot be used.
*	tags: Tags to categorize and organize the key.

## Secrets Submodule
The secrets submodule is used to create secrets within the Key Vault. Secrets are used to store sensitive information such as passwords and connection strings.

### Usage
*	secretName: The name of the secret.
*	value: The value of the secret.
*	contentType: The content type of the secret.
*	enabled: Indicates if the secret is enabled.
*	expiresOn: The expiration date of the secret.
*	notBefore: The date before which the secret cannot be used.
*	tags: Tags to categorize and organize the secret.

## Access Policies Submodule
The accessPolicies submodule is used to create access policies for the Key Vault. Access policies define the permissions for accessing the Key Vault and its contents.

### Usage
*	tenantId: The tenant ID.
*	objectId: The object ID of the principal (user, group, or service principal).
*	permissions: The permissions assigned to the principal (e.g., get, list, create, delete).

## Resources Created and Their Linkages
1.	Key Vault: The keyVault submodule creates the Key Vault resource, which is used to safeguard cryptographic keys and secrets.
2.	Keys: The keys submodule creates keys within the Key Vault. These keys are used for encryption and decryption operations.
3.	Secrets: The secrets submodule creates secrets within the Key Vault. These secrets are used to store sensitive information such as passwords and connection strings.
4.	Access Policies: The accessPolicies submodule creates access policies for the Key Vault. These policies define the permissions for accessing the Key Vault and its contents.

# Summary
This Bicep template configures Key Vault resources including the Key Vault itself, keys, secrets, and access policies. The template ensures that all necessary configurations are applied based on the provided parameters. The resources created are linked to each other through parameters, ensuring a cohesive and well-integrated deployment. The submodules for the Key Vault, keys, secrets, and access policies are crucial for a complete and functional Key Vault deployment, allowing for the secure storage and management of cryptographic keys and secrets.
