# Overview
This document provides a detailed description of the Logic App Standard configuration, including the properties, modules, and conditions used in the Bicep template. The goal is to explain the setup in a simple and clear manner, suitable for both technical and non-technical audiences.

## Metadata
The metadata section provides basic information about the module:
*	Name: Logic App Standard Configuration
*	Description: This module configures Logic App Standard resources including the Logic App itself, diagnostic settings, and resource locks.
*	Version: 1.0.0
*	Project: Melbourne Water Azure Integration Services Implementation

# Parameters
The template uses several parameters to configure the Logic App Standard resources. Parameters are like inputs that you provide to customize the deployment.
1.	logicAppProperties: Object that contains all the Logic App properties.
2.	peProperties: An array of objects that contains all the Private Endpoint properties.
3.	utcValue: Used as part of the deployment name to include the time it was deployed. This is automatically set to the current UTC time.

## Parameter Definitions
*	logicAppProperties: Logic App properties.
*	peProperties: Private Endpoint properties.
*	utcValue: Current UTC time.

## Logic App Standard Modules
The main module for the Logic App Standard configuration includes several submodules to set up different aspects of the Logic App service. These submodules are crucial for a complete and functional Logic App deployment.

## Logic App Standard 
The logicAppStandard submodule is used to create the Logic App Standard resource. Logic Apps are used to automate workflows and integrate systems and services. Check the module for a complete list of parameters used.

### Usage
*	logicAppName: The name of the Logic App.
*	storageAccountName: The name of the storage account used by the Logic App.
*	location: The Azure region where the Logic App will be deployed.
*	tags: Tags to categorize and organize the Logic App.
*	identityType: The type of identity used for the Logic App.
*	userAssignedIdentities: User-assigned identities for the Logic App.
*	logicAppPlanSkuName: The SKU name of the Logic App Plan.
*	logicAppPlanSkuCode: The SKU code of the Logic App Plan.
*	ftpsState: The FTPS state for the Logic App.
*	minTlsVersion: The minimum TLS version.
*	publicNetworkAccess: The public network access setting.
*	virtualNetworkSubnetId: The ID of the virtual network subnet.
*	use32BitWorkerProcess: Indicates if a 32-bit worker process is used.
*	netFrameworkVersion: The .NET Framework version.
*	targetWorkerSizeId: The target worker size ID.
*	targetWorkerCount: The target worker count.
*	maximumElasticWorkerCount: The maximum number of elastic workers.
*	alwaysOn: Indicates if Always On is enabled.
*	vnetPrivatePortsCount: The number of private ports in the VNet.
*	minimumElasticInstanceCount: The minimum number of elastic instances.
*	numberOfWorkers: The number of workers.
*	preWarmedInstanceCount: The number of pre-warmed instances.

## Diagnostic Settings 
The diagnostic settings is used to create diagnostic settings for the Logic App. Diagnostic settings enable you to collect logs and metrics for monitoring and troubleshooting.

### Usage
*	name: The name of the diagnostic settings.
*	scope: The scope of the diagnostic settings, which is the Logic App.
*	properties: Properties of the diagnostic settings, including logs, metrics, and destinations (e.g., Log Analytics, Storage Account, Event Hub).

## Resource Lock 
The resource lock is used to create a resource lock for the Logic App. Resource locks prevent accidental deletion or modification of the Logic App.

### Usage
*	name: The name of the resource lock.
*	scope: The scope of the resource lock, which is the Logic App.
*	properties: Properties of the resource lock, including the lock level (e.g., CanNotDelete, ReadOnly).

## Resources Created and Their Linkages
1.	Logic App Standard: The logicAppStandard submodule creates the Logic App Standard resource, which is used to automate workflows and integrate systems and services.
2.	Diagnostic Settings: The diagnostic settings submodule creates diagnostic settings for the Logic App, enabling the collection of logs and metrics for monitoring and troubleshooting.
3.	Resource Lock: The resource lock submodule creates a resource lock for the Logic App, preventing accidental deletion or modification.

# Summary
This Bicep template configures Logic App Standard resources including the Logic App itself, diagnostic settings, and resource locks. The template ensures that all necessary configurations are applied based on the provided parameters. The resources created are linked to each other through parameters, ensuring a cohesive and well-integrated deployment. The submodules for the Logic App, diagnostic settings, and resource locks are crucial for a complete and functional Logic App deployment, allowing for the automation of workflows, monitoring, and protection against accidental changes.
