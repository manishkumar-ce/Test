# Overview
This document provides a detailed description of the Service Bus configuration, including the properties, modules, and conditions used in the Bicep template. The goal is to explain the setup in a simple and clear manner, suitable for both technical and non-technical audiences.

## Metadata
The metadata section provides basic information about the module:
*	Name: Service Bus Configuration
*	Description: This module configures Service Bus resources including the Service Bus namespace, queues, topics, subscriptions, and authorization rules.
*	Version: 1.0.0
*	Project: Melbourne Water Azure Integration Services Implementation

# Parameters
The template uses several parameters to configure the Service Bus resources. Parameters are like inputs that you provide to customize the deployment.
1.	serviceBusProperties: Object that contains all the Service Bus properties.
2.	peProperties: An array of objects that contains all the Private Endpoint properties.
3.	dnsProperties: An array of objects that contains all the Private DNS Zone properties.
4.	utcValue: Used as part of the deployment name to include the time it was deployed. This is automatically set to the current UTC time.

## Parameter Definitions
*	serviceBusProperties: Service Bus properties.
*	peProperties: Private Endpoint properties.
*	dnsProperties: Private DNS Zone properties.
*	utcValue: Current UTC time.

# Service Bus Modules
The main module for the Service Bus configuration includes several submodules to set up different aspects of the Service Bus service. These submodules are crucial for a complete and functional Service Bus deployment.

## Service Bus Namespace Submodule
The serviceBus submodule is used to create the Service Bus namespace. A Service Bus namespace is a container for Service Bus entities such as queues and topics. Check the module for a complete list of parameters used.

### Usage
*	serviceBusName: The name of the Service Bus namespace.
*	location: The Azure region where the Service Bus namespace will be deployed.
*	tags: Tags to categorize and organize the Service Bus namespace.
*	skuName: The SKU name for the Service Bus namespace.
	* To support private endpoint, the SKU must be at least Premium. Otherwise it will throw error "Private endpoint connections are only supported on Premium Service Bus namespaces" with code "PrivateEndpointInvalidSku".
*	skuCapacity: The capacity of the SKU.
	* To support private endpoint, the SKU must be at least Premium, and the skuCapacity must be at least 1, otherwise it will throw error "The specified value 0 is invalid. The property Messaging Units must be one of the following values: 1,2,4,8,16." with code "InvalidMessagingUnitsValue".
*	zoneRedundant: Indicates if the namespace is zone redundant.
*	minimumTlsVersion: The minimum TLS version.
*	alternateName: An alternate name for the namespace.
*	premiumMessagingPartitions: The number of premium messaging partitions.
*	authorizationRules: Authorization rules for the namespace.
*	lock: Resource lock for the namespace.
*	publicNetworkAccess: Indicates if public network access is enabled.
*	networkRuleSets: Network rule sets for the namespace.
*	privateEndpointsStatus: Status of private endpoints.
*	disableLocalAuth: Indicates if local authentication is disabled.
*	CreateQueues: Boolean to create queues.
*	queueName: The name of the queue.
*	CreateTopics: Boolean to create topics.

## Queue Submodule
The queue submodule is used to create queues within the Service Bus namespace. Queues are used to store messages until they are processed by the receiving application. Check the module for a complete list of parameters used.

### Usage
*	queueName: The name of the queue.
*	namespace: The namespace where the queue will be deployed.
*	resourceGroup: The resource group where the queue will be deployed.
*	location: The Azure region where the queue will be deployed.
*	tags: Tags to categorize and organize the queue.
*	lock: Resource lock for the queue.
*	maxSizeInMegabytes: The maximum size of the queue in megabytes.
*	defaultMessageTimeToLive: The default message time to live.
*	duplicateDetectionHistoryTimeWindow: The duplicate detection history time window.
*	enablePartitioning: Indicates if partitioning is enabled.
*	forwardTo: The name of the queue or topic to forward messages to.
*	forwardDeadLetteredMessagesTo: The name of the queue or topic to forward dead-lettered messages to.
*	enableExpress: Indicates if express entities are enabled.
*	enableBatchedOperations: Indicates if batched operations are enabled.
*	status: The status of the queue.
*	autoDeleteOnIdle: The auto-delete on idle time span.
*	enableDeadLetteringOnMessageExpiration: Indicates if dead-lettering on message expiration is enabled.
*	enableDeadLetteringOnFilterEvaluationExceptions: Indicates if dead-lettering on filter evaluation exceptions is enabled.

## Topic Submodule
The topic submodule is used to create topics within the Service Bus namespace. Topics are used to send messages to multiple subscribers. Check the module for a complete list of parameters used.
### Usage
*	topicName: The name of the topic.
*	namespace: The namespace where the topic will be deployed.
*	resourceGroup: The resource group where the topic will be deployed.
*	location: The Azure region where the topic will be deployed.
*	tags: Tags to categorize and organize the topic.
*	lock: Resource lock for the topic.
*	maxSizeInMegabytes: The maximum size of the topic in megabytes.
*	defaultMessageTimeToLive: The default message time to live.
*	duplicateDetectionHistoryTimeWindow: The duplicate detection history time window.
*	enablePartitioning: Indicates if partitioning is enabled.
*	enableExpress: Indicates if express entities are enabled.
*	enableBatchedOperations: Indicates if batched operations are enabled.
*	status: The status of the topic.
*	autoDeleteOnIdle: The auto-delete on idle time span.

## Subscription Submodule
The subscription submodule is used to create subscriptions for topics within the Service Bus namespace. Subscriptions enable multiple subscribers to receive messages from a single topic. Check the module for a complete list of parameters used.

### Usage
*	subscriptionName: The name of the subscription.
*	topicName: The name of the topic.
*	namespace: The namespace where the subscription will be deployed.
*	resourceGroup: The resource group where the subscription will be deployed.
*	location: The Azure region where the subscription will be deployed.
*	tags: Tags to categorize and organize the subscription.
*	lock: Resource lock for the subscription.
*	defaultMessageTimeToLive: The default message time to live.
*	maxDeliveryCount: The maximum delivery count.
*	enableDeadLetteringOnMessageExpiration: Indicates if dead-lettering on message expiration is enabled.
*	enableDeadLetteringOnFilterEvaluationExceptions: Indicates if dead-lettering on filter evaluation exceptions is enabled.
*	forwardTo: The name of the queue or topic to forward messages to.
*	forwardDeadLetteredMessagesTo: The name of the queue or topic to forward dead-lettered messages to.
*	status: The status of the subscription.
*	autoDeleteOnIdle: The auto-delete on idle time span.

## Authorization Rules Submodule
The authorizationRules submodule is used to create authorization rules for the Service Bus namespace, queues, and topics. Authorization rules define the permissions for accessing the Service Bus entities. Check the module for a complete list of parameters used.

### Usage
*	ruleName: The name of the authorization rule.
*	namespace: The namespace where the authorization rule will be deployed.
*	entityName: The name of the entity (queue or topic) if applicable.
*	resourceGroup: The resource group where the authorization rule will be deployed.
*	rights: The rights assigned to the authorization rule (e.g., Listen, Send, Manage).

## Resources Created and Their Linkages
1.	Service Bus Namespace: The serviceBus submodule creates the Service Bus namespace, which serves as a container for Service Bus entities such as queues and topics.
2.	Queues: The queue submodule creates queues within the Service Bus namespace. These queues store messages until they are processed by the receiving application.
3.	Topics: The topic submodule creates topics within the Service Bus namespace. These topics send messages to multiple subscribers.
4.	Subscriptions: The subscription submodule creates subscriptions for topics within the Service Bus namespace. These subscriptions enable multiple subscribers to receive messages from a single topic.
5.	Authorization Rules: The authorizationRules submodule creates authorization rules for the Service Bus namespace, queues, and topics. These rules define the permissions for accessing the Service Bus entities.

# Summary
This Bicep template configures Service Bus resources including the Service Bus namespace, queues, topics, subscriptions, and authorization rules. The template ensures that all necessary configurations are applied based on the provided parameters. The resources created are linked to each other through parameters, ensuring a cohesive and well-integrated deployment. The submodules for the Service Bus namespace, queues, topics, subscriptions, and authorization rules are crucial for a complete and functional Service Bus deployment, allowing for the reliable and secure exchange of messages between different applications and services.
