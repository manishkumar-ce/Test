# Overview
This document provides a detailed description of the storage account configuration, including the properties, modules, and conditions used in the Bicep template.

# Storage Account Properties
The storage account is configured with various properties defined under saProperties. These properties are used to set up different aspects of the storage account, including update services, domain settings, SMB configurations, and diagnostics.
Properties. Check the module for a complete list of parameters used.
*	updateTableServices: Configures the update table services for the storage account.
*	forestName: Specifies the forest name for the storage account.
*	domainGuid: Specifies the domain GUID for the storage account.
*	domainName: Specifies the domain name for the storage account.
*	azureStorageSid: Specifies the Azure Storage SID for the storage account.
*	directoryServiceOptions: Configures the directory service options for the storage account.
*	domainSid: Specifies the domain SID for the storage account.
*	netBiosDomainName: Specifies the NetBIOS domain name for the storage account.
*	smbMultichannel: Configures SMB multichannel settings for the storage account.
*	updateProtocolSettings: Configures the update protocol settings for the storage account.
*	smbAuthenticationMethods: Specifies the SMB authentication methods for the storage account.
*	smbChannelEncryption: Configures SMB channel encryption settings for the storage account.
*	smbKerberosTicketEncryption: Configures SMB Kerberos ticket encryption settings for the storage account.
*	smbVersions: Specifies the SMB versions supported by the storage account.
*	NetworkAclsResourceAccessRules: Configures network ACLs and resource access rules for the storage account.
*	enableDiagnostics: A boolean flag to enable or disable diagnostics for the storage account.
*	diagnosticsSettings: Configures diagnostics settings if enableDiagnostics is set to true.
*	Conditional Diagnostics Settings
The diagnosticsSettings property is conditionally set based on the value of enableDiagnostics
diagnosticsSettings: (saProperties.enableDiagnostics == true) ? diagnosticSettings : null

### Network ACLs
The storage account includes several parameters for configuring network ACLs:
*	NetworkAclsResourceAccessRules: An array to set the Virtual Network ACL: Resource Access rules.
*	NetworkAclsVirtualNetworkRules: An array to set the Virtual Network ACL: Virtual Network rules using subnet IDs.
*	NetworkAclsBypass: Specifies whether traffic is bypassed for Logging/Metrics/AzureServices.
*	NetworkAclsIpRules: An array to set the virtual network rules.

### Blob Services
The template includes parameters for configuring Blob Services, which are conditionally applied based on the updateBlobServices parameter:
*	updateBlobServices: A boolean flag to determine if Blob Service Policies are configured.
*	deleteRetentionPolicy: Indicates whether DeleteRetentionPolicy is enabled for Containers.

### File Services
*	The template includes parameters for configuring File Services, which are conditionally applied based on the updateFileServices parameter:

## Resources Created and Their Linkages
1.	Storage Account: The primary resource created is the storage account itself, defined by the Microsoft.Storage/storageAccounts resource type. It includes various configurations such as update services, domain settings, SMB configurations, and network ACLs.
2.	Private DNS Zone: If the privateDnsZoneRequired property is true, a private DNS zone is created using the privateDnsZone module. This DNS zone is linked to the storage account by specifying the DNS zone name and other related properties.
3.	Diagnostics Settings: If enableDiagnostics is true, diagnostics settings are applied to the storage account. These settings include logs and metrics configurations.
4.	Network ACLs: Network ACLs are configured to control access to the storage account. This includes resource access rules, virtual network rules, IP rules, and bypass settings.
5.	Blob Services: If updateBlobServices is true, Blob Service Policies are configured, including the delete retention policy for containers

## Private DNS Zone Module
The template includes a module for configuring private DNS zones. This module is conditionally deployed based on the privateDnsZoneRequired property

### Parameters
*	pdnszName: The name of the private DNS zone.
*	registrationEnabled: A boolean flag to enable or disable registration for the private DNS zone.
*	pdnszLinkTags: Tags to be applied to the private DNS zone link.
*	pdnszTags: Tags to be applied to the private DNS zone.

### Storage Account Module and Submodules
The storage account module is defined to include various configurations and submodules. Below is an expanded view of the storage account module and its configurations:
1.	Private DNS Zone Module: Configures private DNS zones based on the privateDnsZoneRequired property.
2.	Diagnostics Settings: Configures diagnostics settings if enableDiagnostics is set to true.
