# Overview
This document provides a detailed description of the Event Hub configuration, including the properties, modules, and conditions used in the Bicep template. The goal is to explain the setup in a simple and clear manner, suitable for both technical and non-technical audiences.

## Metadata
The metadata section provides basic information about the module:
*	Name: Event Hub Configuration
*	Description: This module configures Event Hub resources including namespaces, event hubs, authorization rules, and consumer groups.
*	Version: 1.0.0
*	Project: Melbourne Water Azure Integration Services Implementation

# Parameters
The template uses several parameters to configure the Event Hub resources. Parameters are like inputs that you provide to customize the deployment.
1.	eventHubProperties: Object that contains all the Event Hub properties.
2.	peProperties: An array of objects that contains all the Private Endpoint properties.
3.	dnsProperties: An array of objects that contains all the Private DNS Zone properties.
4.	utcValue: Used as part of the deployment name to include the time it was deployed. This is automatically set to the current UTC time.

## Parameter Definitions
*	eventHubProperties: Event Hub properties.
*	peProperties: Private Endpoint properties.
*	dnsProperties: Private DNS Zone properties.
*	utcValue: Current UTC time.

# Event Hub Modules
The main module for the Event Hub configuration includes several submodules to set up different aspects of the Event Hub service. These submodules are crucial for a complete and functional Event Hub deployment.

## Event Hub Namespace Submodule
This submodule is used to create an Event Hub namespace. An Event Hub namespace is a container for Event Hub instances and related resources. Check the module for a complete list of parameters used.

### Usage
*	namespace: The name of the Event Hub namespace.
*	resourceGroup: The resource group where the Event Hub namespace will be deployed.
*	location: The Azure region where the Event Hub namespace will be deployed.
*	tags: Tags to categorize and organize the Event Hub namespace.
*	skuName: The SKU name for the Event Hub namespace.
*	skuCapacity: The capacity of the SKU.
*	zoneRedundant: Indicates if the namespace is zone redundant.
*	isAutoInflateEnabled: Indicates if auto-inflate is enabled.
*	maximumThroughputUnits: The maximum throughput units for the namespace.
*	authorizationRules: Authorization rules for the namespace.
*	disableLocalAuth: Indicates if local authentication is disabled.
*	KafkaEnabled: Indicates if Kafka is enabled.
*	minimumTlsVersion: The minimum TLS version.
*	publicNetworkAccess: Indicates if public network access is enabled.
*	networkRuleSets: Network rule sets for the namespace.
*	lock: Resource lock for the namespace.
*	identityType: The type of identity used for the namespace.
*	userAssignedIdentities: User-assigned identities for the namespace.
*	privateEndpointsStatus: Status of private endpoints.

## Event Hubs Submodule
The eventHubs submodule is used to create individual Event Hubs within the namespace. Event Hubs are used to ingest and process large volumes of events. Check the module for a complete list of parameters used.

### Usage
*	eventHubName: The name of the Event Hub.
*	namespace: The namespace where the Event Hub will be deployed.
*	resourceGroup: The resource group where the Event Hub will be deployed.
*	location: The Azure region where the Event Hub will be deployed.
*	tags: Tags to categorize and organize the Event Hub.
*	partitionCount: The number of partitions in the Event Hub.
*	messageRetentionInDays: The number of days to retain messages in the Event Hub.
*	status: The status of the Event Hub.
*	captureDescription: Capture description for the Event Hub.

## Authorization Rules Submodule

The authorisationrules submodule is used to create authorization rules for the Event Hub namespace or individual Event Hubs. Authorization rules define the permissions for accessing the Event Hub. Check the module for a complete list of parameters used.

### Usage
*	ruleName: The name of the authorization rule.
*	namespace: The namespace where the authorization rule will be deployed.
*	eventHubName: The name of the Event Hub (if applicable).
*	resourceGroup: The resource group where the authorization rule will be deployed.
*	rights: The rights assigned to the authorization rule (e.g., Listen, Send, Manage).

## Consumer Groups Submodule
The consumerGroups submodule is used to create consumer groups for the Event Hub. Consumer groups enable multiple consumers to read from the same Event Hub independently. Check the module for a complete list of parameters used.

### Usage
*	consumerGroupName: The name of the consumer group.
*	namespace: The namespace where the consumer group will be deployed.
*	eventHubName: The name of the Event Hub.
*	resourceGroup: The resource group where the consumer group will be deployed.

## Resources Created and Their Linkages

1.	Event Hub Namespace: This submodule creates an Event Hub namespace that serves as a container for Event Hub instances and related resources.
2.	Event Hubs: The eventHubs submodule creates individual Event Hubs within the namespace. These Event Hubs are used to ingest and process large volumes of events.
3.	Authorization Rules: This submodule creates authorization rules for the Event Hub namespace or individual Event Hubs. These rules define the permissions for accessing the Event Hub.
4.	Consumer Groups: The consumerGroups submodule creates consumer groups for the Event Hub. These groups enable multiple consumers to read from the same Event Hub independently.

# Summary
This Bicep template configures Event Hub resources including namespaces, event hubs, authorization rules, and consumer groups. The template ensures that all necessary configurations are applied based on the provided parameters. The resources created are linked to each other through parameters, ensuring a cohesive and well-integrated deployment. The submodules for Event Hub namespaces, event hubs, authorization rules, and consumer groups are crucial for a complete and functional Event Hub deployment, allowing for the ingestion, processing, and consumption of large volumes of events.
