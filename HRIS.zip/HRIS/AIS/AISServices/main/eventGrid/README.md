# Overview
This document provides a detailed description of the Event Grid configuration, including the properties, modules, and conditions used in the Bicep template. The goal is to explain the setup in a simple and clear manner, suitable for both technical and non-technical audiences.

## Metadata
The metadata section provides basic information about the module:
*	Name: Event Grid Configuration
*	Description: This module configures Event Grid resources including system topics, domains, and topics.
*	Version: 1.0.0
*	Project: Melbourne Water Azure Integration Services Implementation

# Parameters
The template uses several parameters to configure the Event Grid resources. Parameters are like inputs that you provide to customize the deployment.
1.	peProperties: An array of objects that contains all the Private Endpoint properties.
2.	dnsProperties: An array of objects that contains all the Private DNS Zone properties.
3.	utcValue: Used as part of the deployment name to include the time it was deployed. This is automatically set to the current UTC time.

## Parameter Definitions
*	peProperties: Private Endpoint properties.
*	dnsProperties: Private DNS Zone properties.
*	utcValue: Current UTC time.

# Event Grid Modules
The main module for the Event Grid configuration includes several submodules to set up different aspects of the Event Grid service. These submodules are crucial for a complete and functional Event Grid deployment.

## System Topic Submodule
The systemTopic submodule is used to create system topics in the Event Grid service. System topics are automatically created by Azure services and are used to publish events from these services. Check the module for a complete list of parameters used.

### Usage
*	topicName: The name of the system topic.
*	resourceGroup: The resource group where the system topic will be deployed.
*	location: The Azure region where the system topic will be deployed.
*	topicSource: The source of the events for the system topic.
*	topicType: The type of the system topic.
*	tags: Tags to categorize and organize the system topic.
*	identityType: The type of identity used for the system topic.
*	userAssignedIdentities: User-assigned identities for the system topic.
*	eventSubscriptions: Event subscriptions for the system topic.
*	lock: Resource lock for the system topic.

## Domain Submodule
The domain submodule is used to create domains in the Event Grid service. Domains are used to manage multiple topics as a single resource, simplifying the management of large numbers of topics. Check the module for a complete list of parameters used.

### Usage
*	domainName: The name of the domain.
*	resourceGroup: The resource group where the domain will be deployed.
*	location: The Azure region where the domain will be deployed.
*	tags: Tags to categorize and organize the domain.
*	identityType: The type of identity used for the domain.
*	userAssignedIdentities: User-assigned identities for the domain.
*	eventSubscriptions: Event subscriptions for the domain.
*	lock: Resource lock for the domain.

## Topic Submodule
The topic submodule is used to create custom topics in the Event Grid service. Custom topics are user-defined and are used to publish events from custom applications. Check the module for a complete list of parameters used.

### Usage
*	topicName: The name of the custom topic.
*	resourceGroup: The resource group where the custom topic will be deployed.
*	location: The Azure region where the custom topic will be deployed.
*	tags: Tags to categorize and organize the custom topic.

## Resources Created and Their Linkages
1.	System Topics: The systemTopic submodule creates system topics that are automatically managed by Azure services. These topics are used to publish events from Azure services to Event Grid.
2.	Domains: The domain submodule creates domains that manage multiple topics as a single resource. This simplifies the management of large numbers of topics.
3.	Custom Topics: The topic submodule creates custom topics that are user-defined. These topics are used to publish events from custom applications to Event Grid.

# Summary
This Bicep template configures Event Grid resources including system topics, domains, and custom topics. The template ensures that all necessary configurations are applied based on the provided parameters. The resources created are linked to each other through parameters, ensuring a cohesive and well-integrated deployment. The submodules for system topics, domains, and custom topics are crucial for a complete and functional Event Grid deployment, allowing for the management and publication of events from both Azure services and custom applications.
