

### Step 1: Create a Bicep Template for the VM

1. **Create a Bicep Template:**
   - In your repository, create a new file named `main.bicep` with the following content:

```bicep
param location string = resourceGroup

().

location
param adminUsername string = 'azureuser'
param adminPassword string

resource nic 'Microsoft.Network/networkInterfaces@2021-02-01' = {
  name: 'myNic'
  location: location
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
        properties: {
          subnet: {
            id: resourceId('Microsoft.Network/virtualNetworks/subnets', 'vnet-dev-test-ase', 'sn-dev-test-aispe-ase')
          }
          privateIPAllocationMethod: 'Dynamic'
        }
      }
    ]
  }
}

resource vm 'Microsoft.Compute/virtualMachines@2021-03-01' = {
  name: 'myLinuxVM'
  location: location
  properties: {
    hardwareProfile: {
      vmSize: 'Standard_DS1_v2'
    }
    storageProfile: {
      imageReference: {
        publisher: 'Canonical'
        offer: 'UbuntuServer'
        sku: '18.04-LTS'
        version: 'latest'
      }
      osDisk: {
        createOption: 'FromImage'
      }
    }
    osProfile: {
      computerName: 'myLinuxVM'
      adminUsername: adminUsername
      adminPassword: adminPassword
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: nic.id
        }
      ]
    }
  }
}
```

### Step 2: Create an Azure DevOps Pipeline for VM Deployment

1. **Create an Azure DevOps Pipeline:**
   - In Azure DevOps, navigate to your project and select **Pipelines** > **Create Pipeline**.
   - Choose your repository and select **Starter pipeline**.
   - Replace the content of the YAML file with the following:

```yaml
trigger:
- main

pool:
  vmImage: 'ubuntu-latest'

steps:
- task: AzureCLI@2
  inputs:
    azureSubscription: 'YourAzureServiceConnection'
    scriptType: 'bash'
    scriptLocation: 'inlineScript'
    inlineScript: |
      az deployment group create \
        --resource-group rg-devtest-ase-ais \
        --template-file main.bicep \
        --parameters adminPassword=$(adminPassword)
    addSpnToEnvironment: true
```

2. **Save and Run the Pipeline:**
   - Save the pipeline YAML file.
   - Click on **Run** to execute the pipeline.

3. **Provide Necessary Details:**
   - When prompted, provide the necessary details such as `YourAzureServiceConnection` and `adminPassword`.

### Step 3: Set Up the Azure DevOps Self-Hosted Agent

1. **Log in to the VM:**
   - SSH into the newly created VM using the credentials you provided.

```bash
ssh azureuser@<VM_IP_ADDRESS>
```

2. **Install Dependencies:**
   - Install necessary dependencies on the VM.

```bash
sudo apt-get update
sudo apt-get install -y libssl-dev libffi-dev python3-dev build-essential
```

3. **Download and Configure the Agent:**
   - Log in to your Azure DevOps organization.
   - Navigate to **Organization settings** > **Agent pools**.
   - Select the **Default pool**, then **New agent**.
   - Choose **Linux** and download the agent package.
   - Unpack the agent into a directory of your choice.

```bash
mkdir myagent && cd myagent
wget https://vstsagentpackage.azureedge.net/agent/2.193.1/vsts-agent-linux-x64-2.193.1.tar.gz
tar zxvf vsts-agent-linux-x64-2.193.1.tar.gz
```

4. **Configure the Agent:**
   - Run the configuration script and follow the prompts.

```bash
./config.sh
```

   - Provide the server URL, authentication type, and other required details.

5. **Run the Agent:**
   - To run interactively:

```bash
./run.sh
```

   - To run as a service:

```bash
sudo ./svc.sh install
sudo ./svc.sh start
```

6. **Verify the Agent:**
   - Check the status:

```bash
sudo ./svc.sh status
```

### Summary

1. **Create a Bicep template (`main.bicep`) for the VM.**
2. **Create an Azure DevOps pipeline to deploy the VM using the Bicep template.**
3. **SSH into the VM and install necessary dependencies.**
4. **Download, configure, and run the Azure DevOps self-hosted agent on the VM.**

