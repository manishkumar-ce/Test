﻿using System;
using System.Net;
using System.Text;
using Azure.Identity;
using Azure.Messaging.ServiceBus;
using HRIS.Pega.Helpers.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace HRIS.Pega.Helpers

{
    public  class ServiceBusPublisher : IServiceBusPublisher
    {
       
        private readonly ILogger<ServiceBusPublisher> _logger;
        private const string QueueName = "flexible-email-sender";
        public ServiceBusPublisher(ILogger<ServiceBusPublisher> logger)
        {            
            _logger = logger;
        }

        public async Task SendMessageAsync<T>(T message)
        {
            var options = new ServiceBusClientOptions();
            options.TransportType = ServiceBusTransportType.AmqpWebSockets;
            var client = new ServiceBusClient(Environment.GetEnvironmentVariable("ServiceBusConnection__fullyQualifiedNamespace"), new DefaultAzureCredential(), options);
            var sender = client.CreateSender(QueueName);
            var serializedMessage = JsonConvert.SerializeObject(message);
            var serviceBusMessage = new ServiceBusMessage(GetBinaryDate(serializedMessage));
            await sender.SendMessageAsync(serviceBusMessage);
            _logger.LogInformation($"Published message to service bus successfully {QueueName}");
        }

        private byte[] GetBinaryDate(string message)
        {
            return Encoding.UTF8.GetBytes(message);
        }
    

    }
}
  