﻿using System;

namespace HRIS.Pega.Helpers.Interfaces

{
    public interface IServiceBusPublisher
    {

        Task SendMessageAsync<T>(T message);

    

    }
}
  