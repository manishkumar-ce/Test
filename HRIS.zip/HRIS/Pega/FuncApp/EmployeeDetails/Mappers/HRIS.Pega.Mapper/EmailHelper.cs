﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using HRIS.Pega.Models;
using HRIS.Pega.Models.Dayforce;
using DayforcePortfolioDetails = HRIS.Pega.Models.Dayforce.PortfolioDetails;
using PortfolioDetails = HRIS.Pega.Models.Dayforce.PortfolioDetails;
using PositionDetails = HRIS.Pega.Models.PositionDetails;

namespace HRIS.Pega.Helpers
{
    public static class EmailHelper
    {

       public static string ToEmailHtmlContent(this ErrorMessage errorMessage)
        {
            string htmlStyle =
                @"body {font: 14.5px Segoe UI;} table, th , td {border: 1px solid #76A3E5; border-collapse: collapse;} th {background-color: #D1E2FB} th, td {padding: 8px; text-align: left;}";
            var htmlTable = ToHtmlTable(errorMessage);
            var htmlBody = $"<body><table>{htmlTable}</table></body>";
            var html = $"<html><head><style>{htmlStyle}</style></head>{htmlBody}</html>";

            return html;
        }

        public static string ToEmailSubject(this ErrorMessage errorMessage)
        {
            if (!string.IsNullOrWhiteSpace(errorMessage.InterfaceName))
            {

                return $"Error executing {errorMessage.InterfaceName} for {errorMessage.SystemName}";
            }
            else return String.Empty ;


        }

        private static string ToHtmlTable(ErrorMessage errorMessage)
        {

            var tableBuilder = new StringBuilder();
            tableBuilder.Append(ToHtmlTableRow("SourceSystem", errorMessage.SystemName));
            tableBuilder.Append(ToHtmlTableRow("InterfaceName", errorMessage.InterfaceName));
            tableBuilder.Append(ToHtmlTableRow("ErrorDetails", errorMessage.ErrorDetails));
            
            return tableBuilder.ToString();

        }


        private static string ToHtmlTableRow(string fieldName , string fieldValue)
        {

            return $"<tr><td>{fieldName}</td><td><b>{fieldValue}</b></td></tr>";
        }


    }
}
  