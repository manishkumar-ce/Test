﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using HRIS.Pega.Models;
using HRIS.Pega.Models.Dayforce;
using DayforcePortfolioDetails = HRIS.Pega.Models.Dayforce.PortfolioDetails;
using PortfolioDetails = HRIS.Pega.Models.Dayforce.PortfolioDetails;
using PositionDetails = HRIS.Pega.Models.PositionDetails;

namespace HRIS.Pega.Helpers
{
    public static class MappingHelper
    {

        public static EmployeeDetailsApiResponse ToEmpDetailsResponse(this EmployeeDetailsResponse employeeDetailsResponse)
        {
            EmployeeDetailsApiResponse employeeDetailsApiResponse = new EmployeeDetailsApiResponse();
            if (employeeDetailsResponse.Data != null)
            {
                if (employeeDetailsResponse.Data.XRefCode != null)
                {
                    employeeDetailsApiResponse.EmployeeId = employeeDetailsResponse.Data.XRefCode;
                }
                //To be confirmed
                if (employeeDetailsResponse.Data.SSOAccounts != null && employeeDetailsResponse.Data.SSOAccounts.Items != null  && employeeDetailsResponse.Data.SSOAccounts.Items.Count > 0)
                {
                    employeeDetailsApiResponse.NetworkID = employeeDetailsResponse.Data.SSOAccounts.Items[0].LoginName;
                }
                if (employeeDetailsResponse.Data.FirstName != null)
                {
                    employeeDetailsApiResponse.FirstName = employeeDetailsResponse.Data.FirstName;
                }
                if (employeeDetailsResponse.Data.LastName != null)
                {
                    employeeDetailsApiResponse.Surname = employeeDetailsResponse.Data.LastName;
                }
                if (employeeDetailsResponse.Data.CommonName != null)
                {
                    employeeDetailsApiResponse.PreferredFirstName = employeeDetailsResponse.Data.CommonName;
                }
                if (employeeDetailsResponse.Data.PreferredLastName != null)
                {
                    employeeDetailsApiResponse.PreferredLastName = employeeDetailsResponse.Data.PreferredLastName;
                }
               
                if (employeeDetailsResponse.Data.BirthDate != null)
                {
                    employeeDetailsApiResponse.DateOfBirth = employeeDetailsResponse.Data.BirthDate?.ToString("dd/MM/yyyy");
                }
                if (employeeDetailsResponse.Data.HireDate != null)
                {
                    employeeDetailsApiResponse.JoinedDate = employeeDetailsResponse.Data.HireDate?.ToString("dd/MM/yyyy");
                }
                if (employeeDetailsResponse.Data.Addresses != null && employeeDetailsResponse.Data.Addresses.Items.Where(x=> x.ContactInformationType.XRefCode == "PrimaryResidence").Count() > 0) 
                {
                    var primaryAddress = employeeDetailsResponse.Data.Addresses.Items.Where(x =>  x.ContactInformationType.XRefCode == "PrimaryResidence").FirstOrDefault();
                    employeeDetailsApiResponse.EmployeeAddress = new EmployeeAddress();
                    employeeDetailsApiResponse.EmployeeAddress.Line1 = primaryAddress.Address1;
                    employeeDetailsApiResponse.EmployeeAddress.Suburb = primaryAddress.City;
                    employeeDetailsApiResponse.EmployeeAddress.PostCode = primaryAddress.PostalCode;
                    employeeDetailsApiResponse.EmployeeAddress.State = String.IsNullOrWhiteSpace(primaryAddress.State?.XRefCode) ? string.Empty : primaryAddress.State.XRefCode.Contains("-") ? primaryAddress.State?.XRefCode.Split("-").Last() : primaryAddress.State?.XRefCode;
                }
                if (employeeDetailsResponse.Data.Contacts != null && employeeDetailsResponse.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").Count() > 0)
                {
                    var emailAddress = employeeDetailsResponse.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").FirstOrDefault();
                    employeeDetailsApiResponse.EmailId = emailAddress.ElectronicAddress;
                   
                }
                if (employeeDetailsResponse.Data.Contacts != null && employeeDetailsResponse.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessMobile").Count() > 0)
                {
                    var phoneDetails = employeeDetailsResponse.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessMobile").FirstOrDefault();
                    employeeDetailsApiResponse.MobileNumber = phoneDetails.Location.BusinessPhone;

                }

               
                if (employeeDetailsResponse.Data.WorkAssignments != null && employeeDetailsResponse.Data.WorkAssignments.Items.Where(x => x.IsPrimary == true).Count() > 0)
                {
                    var positionDetails = employeeDetailsResponse.Data.WorkAssignments.Items.Where(x => x.IsPrimary == true).FirstOrDefault();
                    var occupancyDetails = employeeDetailsResponse.Data.EmployeeProperties.Items.Where(x => x.EmployeeProperty.XRefCode == "EmployeePropertyXrefCode9198").FirstOrDefault();
                    var peopleLeaderDetails = employeeDetailsResponse.Data.EmployeeProperties.Items.Where(x => x.EmployeeProperty.XRefCode == "EmployeePropertyXrefCode9081").FirstOrDefault();
                    if (positionDetails.PMPositionAssignment != null && positionDetails.PMPositionAssignment.PMPosition != null)
                    {
                        var businessParentList = positionDetails.PMPositionAssignment.PMPosition.BusinessUnit.BusinessUnitParents.Where(x => x.XRefCode != "MWC").ToList().OrderByDescending(y => Convert.ToInt32(y.XRefCode)).ToList();
                        string portFolioId = string.Empty;
                        string portFolioDesc = string.Empty;
                        string departmentId = string.Empty;
                        string departmentDesc = string.Empty;
                        string sectionId = string.Empty;
                        string sectionDescription = string.Empty;
                        string teamId = string.Empty;
                        string teamDescription = string.Empty;
                        DeriveBusinessUnitDetails(positionDetails).TryGetValue("DepartmentId", out departmentId);
                        DeriveBusinessUnitDetails(positionDetails).TryGetValue("DepartmentDesc", out departmentDesc);
                        DeriveBusinessUnitDetails(positionDetails).TryGetValue("PortfolioId", out portFolioId);
                        DeriveBusinessUnitDetails(positionDetails).TryGetValue("PortfolioDesc", out portFolioDesc);
                        DeriveBusinessUnitDetails(positionDetails).TryGetValue("TeamId", out teamId);
                        DeriveBusinessUnitDetails(positionDetails).TryGetValue("TeamDesc", out teamDescription);
                        DeriveBusinessUnitDetails(positionDetails).TryGetValue("SectionId", out sectionId);
                        DeriveBusinessUnitDetails(positionDetails).TryGetValue("SectionDesc", out sectionDescription);

                        employeeDetailsApiResponse.PositionDetails = new PositionDetails
                        {
                            Id = positionDetails.PMPositionAssignment.PMPosition.XRefCode,
                            Desc = positionDetails.PMPositionAssignment.PMPosition.ShortName,
                            StartDate = positionDetails.PMPositionAssignment.EffectiveStart.ToString(),
                            EndDate = positionDetails.PMPositionAssignment.EffectiveEnd.ToString(),
                            HoursPerWeek = "38",
                            OccupancyStatus = new OccupancyStatus
                            {
                                Id = occupancyDetails?.EmployeeProperty?.XRefCode,
                                Desc = occupancyDetails?.EmployeeProperty?.ShortName
                            },
                            PeopleLeaderCategory = new PeopleLeaderCategory
                            {
                                Id = peopleLeaderDetails?.OptionValue?.XRefCode,
                                Desc = peopleLeaderDetails?.OptionValue?.ShortName
                            },
                            EmployeeStatus = new EmployeeStatus
                            {
                                Id = positionDetails.EmploymentStatusReason?.XRefCode,
                                Desc = positionDetails.EmploymentStatusReason?.ShortName
                            },
                            //Grade = new Grade
                            //{
                            //    Id = positionDetails.Position.Job?.PayGrade?.XRefCode,
                            //    Desc = positionDetails.Position.Job?.PayGrade?.ShortName,
                            //},
                            BusinessGroup = new BusinessGroup
                            {
                                Id = departmentId,
                                Desc = departmentDesc
                            },
                            Portfolio = new Portfolio
                            {
                                Id = portFolioId,
                                Desc = portFolioDesc
                            },
                            Team = new Team
                            {
                                Id = teamId,
                                Desc = teamDescription
                            },
                            Section = new Section
                            {
                                Id = sectionId,
                                Desc = sectionDescription
                            },
                            CostCentre = new CostCentre
                            {
                                Id =   !String.IsNullOrWhiteSpace(positionDetails.PMPositionAssignment?.PMPosition?.LedgerCode) ? positionDetails.PMPositionAssignment?.PMPosition?.LedgerCode :  String.IsNullOrWhiteSpace(positionDetails.PMPositionAssignment?.PMPosition?.BusinessUnit.LedgerCode) ? String.Empty: positionDetails.PMPositionAssignment?.PMPosition?.BusinessUnit.LedgerCode
                            },
                            WorkLocation = new WorkLocation
                            {
                                Id = positionDetails?.Location?.XRefCode,
                                Desc = positionDetails?.Location?.ShortName
                            }
                        };

                        
                        if (employeeDetailsResponse.Data.EmploymentStatuses != null && employeeDetailsResponse.Data.EmploymentStatuses.Items.Count() > 0)
                        {
                            var payclassDetails = employeeDetailsResponse.Data.EmploymentStatuses.Items[0];
                            if(employeeDetailsApiResponse.PositionDetails == null)
                            {
                                employeeDetailsApiResponse.PositionDetails = new PositionDetails();

                            }
                            employeeDetailsApiResponse.PositionDetails.EmployeeStatus = new EmployeeStatus
                            {
                                Id = payclassDetails.PayClass.XRefCode,
                                Desc = payclassDetails.PayClass.ShortName,
                            };

                        }

                        if (employeeDetailsResponse.Data.OrgUnitInfos != null && employeeDetailsResponse.Data.OrgUnitInfos.Items.Count()>0)
                        {
                            var orgDetails = employeeDetailsResponse.Data.OrgUnitInfos.Items.Where(x => x.OrgUnitDetail.OrgLevel.XRefCode == "OnSiteDepartment").FirstOrDefault();
                                if (orgDetails != null && orgDetails.OrgUnitDetail != null && orgDetails.OrgUnitDetail.OrgUnitParent != null)
                                {
                                    if (employeeDetailsApiResponse.PositionDetails == null)
                                    {
                                        employeeDetailsApiResponse.PositionDetails = new PositionDetails();

                                    }

                                    employeeDetailsApiResponse.PositionDetails.WorkLocation = new WorkLocation
                                    {
                                        Id = orgDetails.OrgUnitDetail.OrgUnitParent.XRefCode,
                                        Desc = orgDetails.OrgUnitDetail.OrgUnitParent.ShortName
                                    };
                                }

                                
                            

                        }



                        if (employeeDetailsResponse.Data.EmployeeManagers != null)
                        {
                            if (employeeDetailsApiResponse.PositionDetails == null)
                            {
                                employeeDetailsApiResponse.PositionDetails = new PositionDetails();
                            }

                            employeeDetailsApiResponse.PositionDetails.Level1Manager = new Level1Manager();

                            employeeDetailsApiResponse.PositionDetails.Level1Manager.EmployeeId = employeeDetailsResponse.Data.EmployeeManagers.Items[0].ManagerXRefCode;
                            employeeDetailsApiResponse.PositionDetails.Level1Manager.FirstName = employeeDetailsResponse.Data.EmployeeManagers.Items[0].ManagerFirstName;
                            employeeDetailsApiResponse.PositionDetails.Level1Manager.Surname = employeeDetailsResponse.Data.EmployeeManagers.Items[0].ManagerLastName;

                        }
                    }
                }

               

            }


            return employeeDetailsApiResponse;
             
        }

        public static Dictionary<string, string> DeriveBusinessUnitDetails(Item PMAssignment)
        {
            Dictionary<string,string> businessUnitDetails = new Dictionary<string,string>();
            var directBusinessUnit = PMAssignment.PMPositionAssignment.PMPosition.BusinessUnit;
            var parentUnitCounts = PMAssignment.PMPositionAssignment.PMPosition.BusinessUnit.BusinessUnitParents.Count;
            if (parentUnitCounts != 0)
            {
                if (parentUnitCounts == 1 && directBusinessUnit.BusinessUnitParents[0].XRefCode == "MWC")
                {
                    businessUnitDetails.Add("PortfolioId", directBusinessUnit.XRefCode.Substring(0, 2));
                    businessUnitDetails.Add("PortfolioDesc", directBusinessUnit.ShortName);
                    businessUnitDetails.Add("DepartmentId", directBusinessUnit.XRefCode.Substring(0, 3));
                    businessUnitDetails.Add("DepartmentDesc", directBusinessUnit.ShortName);
                    businessUnitDetails.Add("TeamId", directBusinessUnit.XRefCode.Substring(0, 4));
                    businessUnitDetails.Add("TeamDesc", directBusinessUnit.ShortName);
                    businessUnitDetails.Add("SectionId", directBusinessUnit.XRefCode.Substring(0, 5));
                    businessUnitDetails.Add("SectionDesc", directBusinessUnit.ShortName);
                }
                else if (parentUnitCounts == 2 && directBusinessUnit.BusinessUnitParents[1].XRefCode == "MWC")
                {
                    businessUnitDetails.Add("PortfolioId", directBusinessUnit.BusinessUnitParents[0].XRefCode.Substring(0, 2));
                    businessUnitDetails.Add("PortfolioDesc", directBusinessUnit.BusinessUnitParents[0].ShortName);
                    businessUnitDetails.Add("DepartmentId", directBusinessUnit.XRefCode.Substring(0, 3));
                    businessUnitDetails.Add("DepartmentDesc", directBusinessUnit.ShortName);
                    businessUnitDetails.Add("TeamId", directBusinessUnit.XRefCode.Substring(0, 4));
                    businessUnitDetails.Add("TeamDesc", directBusinessUnit.ShortName);
                    businessUnitDetails.Add("SectionId", directBusinessUnit.XRefCode.Substring(0, 5));
                    businessUnitDetails.Add("SectionDesc", directBusinessUnit.ShortName);
                }

                else if (parentUnitCounts == 3 && directBusinessUnit.BusinessUnitParents[2].XRefCode == "MWC")
                {
                    businessUnitDetails.Add("PortfolioId", directBusinessUnit.BusinessUnitParents[1].XRefCode.Substring(0, 2));
                    businessUnitDetails.Add("PortfolioDesc", directBusinessUnit.BusinessUnitParents[1].ShortName);
                    businessUnitDetails.Add("DepartmentId", directBusinessUnit.BusinessUnitParents[0].XRefCode.Substring(0, 3));
                    businessUnitDetails.Add("DepartmentDesc", directBusinessUnit.BusinessUnitParents[0].ShortName);
                    businessUnitDetails.Add("TeamId", directBusinessUnit.XRefCode.Substring(0, 4));
                    businessUnitDetails.Add("TeamDesc", directBusinessUnit.ShortName);
                    businessUnitDetails.Add("SectionId", directBusinessUnit.XRefCode.Substring(0, 5));
                    businessUnitDetails.Add("SectionDesc", directBusinessUnit.ShortName);
                }

                else
                {
                    businessUnitDetails.Add("PortfolioId", directBusinessUnit.BusinessUnitParents[2].XRefCode.Substring(0, 2));
                    businessUnitDetails.Add("PortfolioDesc", directBusinessUnit.BusinessUnitParents[2].ShortName);
                    businessUnitDetails.Add("DepartmentId", directBusinessUnit.BusinessUnitParents[1].XRefCode.Substring(0, 3));
                    businessUnitDetails.Add("DepartmentDesc", directBusinessUnit.BusinessUnitParents[1].ShortName);
                    businessUnitDetails.Add("TeamId", directBusinessUnit.BusinessUnitParents[0].XRefCode.Substring(0, 4));
                    businessUnitDetails.Add("TeamDesc", directBusinessUnit.BusinessUnitParents[0].ShortName);
                    businessUnitDetails.Add("SectionId", directBusinessUnit.XRefCode.Substring(0, 5));
                    businessUnitDetails.Add("SectionDesc", directBusinessUnit.ShortName);
                }
            }

            return businessUnitDetails;
        }

        public static PortfolioResponse ToPortfolioResponse(this PortfolioResponseModel dayforcePortfolioResponse)
        {
            PortfolioResponse portfolioResponse = new PortfolioResponse();
            portfolioResponse.PortfolioDetails = new List<Models.PortfolioDetails>();
            portfolioResponse.PortfolioDetails = dayforcePortfolioResponse.Data.Rows.Select(portfolio => new Models.PortfolioDetails() { EgmPortfolio = portfolio.EgmPortfolio,EmpXrefCode = portfolio.Employee_XRefCode }).ToList();

            return portfolioResponse;

        }

        public static PositionReportResponse ToPostionReportsResponse(this PositionResponseModel dayforcePositionResponse)
        {
            PositionReportResponse positionResponse = new PositionReportResponse();
            positionResponse.PositionReports = new List<PositionReports>();
            positionResponse.PositionReports = dayforcePositionResponse.Data.Rows.Select(position => new Models.PositionReports() { PositionNumber = position.PositionID, PositionTitle = position.PositionTitle, ManagerPositionNumber = position.ParentPosID,PortfolioCode = position.Portfolio, PortfolioDescription = position.PortfolioDescription,
                DepartmentCode = position.Department,DepartmentDescription = position.DepartmentDescription,
              TeamCode = position.Team , TeamDescription = position.TeamDescription, SectionCode = position.Section,SectionDescription = position.SectionDescription,PositionFTE = position.PositionFTE, CostCentre = position.CostCentre, DateCreated = position.DateCreated, DateEnded = position.DateEnded ,LocationCode = position.SiteID, Grade = position.PositionGrade , LocationDescription = position.LocationDescription, EmployeeName = position.EmployeeName, ManagerName = position.ManagerName }).ToList();

            return positionResponse;

        }

    }
}
  