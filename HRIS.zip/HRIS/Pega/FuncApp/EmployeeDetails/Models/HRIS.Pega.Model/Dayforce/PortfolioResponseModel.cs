﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models.Dayforce
{ 


        public class PortfolioResponseModel
        {
            [JsonPropertyName("Data")]
            public PortfolioData Data { get; set; }

            [JsonPropertyName("Paging")]
            public Paging Paging { get; set; }
        }        
        public class PortfolioData
        {
            [JsonPropertyName("XRefCode")]
            public string XRefCode { get; set; }

            [JsonPropertyName("Rows")]
            public List<PortfolioDetails> Rows { get; set; }
        }

        public class Paging
        {
            [JsonPropertyName("Next")]
            public string Next { get; set; }
        }


    public class PortfolioDetails
    {
        [JsonPropertyName("EGMPortfolio")]
        public string EgmPortfolio { get; set; }


        [JsonPropertyName("Employee_XRefCode")]
        public string Employee_XRefCode { get; set; }

        [JsonPropertyName("Employee_FirstName")]
        public string Employee_FirstName { get; set; }

        [JsonPropertyName("Employee_LastName")]
        public string Employee_LastName { get; set; }
    }





}

