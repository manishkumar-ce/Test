﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models.Dayforce
{

    public class EmployeeDetailsResponse
    {
        [JsonPropertyName("Data")]
        public Data Data { get; set; }

        [JsonPropertyName("ProcessResults")]
        public List<ProcessResult> ProcessResults { get; set; }
    }

    // Root myDeserializedClass = JsonSerializer.Deserialize<Root>(myJsonResponse);
    public class AccidentInsuranceHazardCategory
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class AccumulationType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ActiveEmployeeLocation
    {
        [JsonPropertyName("PhysicalLocation")]
        public bool PhysicalLocation { get; set; }

        [JsonPropertyName("BusinessPhone")]
        public string BusinessPhone { get; set; }

        [JsonPropertyName("ContactBusinessPhone")]
        public string ContactBusinessPhone { get; set; }

        [JsonPropertyName("ContactCellPhone")]
        public string ContactCellPhone { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("CountryCode")]
        public string CountryCode { get; set; }

        [JsonPropertyName("OpeningDate")]
        public DateTime? OpeningDate { get; set; }

        [JsonPropertyName("ClosingDate")]
        public DateTime? ClosingDate { get; set; }

        [JsonPropertyName("ComparableLocation")]
        public ComparableLocation ComparableLocation { get; set; }

        [JsonPropertyName("Department")]
        public Department Department { get; set; }

        [JsonPropertyName("Zone")]
        public Zone Zone { get; set; }

        [JsonPropertyName("StartDayOfWeek")]
        public int StartDayOfWeek { get; set; }

        [JsonPropertyName("GeoCity")]
        public GeoCity GeoCity { get; set; }

        [JsonPropertyName("Timezone")]
        public Timezone Timezone { get; set; }

        [JsonPropertyName("County")]
        public string County { get; set; }

        [JsonPropertyName("IsOrgManaged")]
        public bool IsOrgManaged { get; set; }

        [JsonPropertyName("IsMobileOrg")]
        public bool IsMobileOrg { get; set; }

        [JsonPropertyName("PublicName")]
        public string PublicName { get; set; }

        [JsonPropertyName("ClockTransferCode")]
        public string ClockTransferCode { get; set; }

        [JsonPropertyName("ContactEmail")]
        public string ContactEmail { get; set; }

        [JsonPropertyName("ContactName")]
        public string ContactName { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("StateCode")]
        public string StateCode { get; set; }

        [JsonPropertyName("Address")]
        public string Address { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("LegalEntity")]
        public LegalEntity LegalEntity { get; set; }

        [JsonPropertyName("OrgUnitLegalEntities")]
        public OrgUnitLegalEntities OrgUnitLegalEntities { get; set; }

        [JsonPropertyName("OrgUnitParents")]
        public OrgUnitParents OrgUnitParents { get; set; }

        [JsonPropertyName("ChildOrgUnits")]
        public ChildOrgUnits ChildOrgUnits { get; set; }

        [JsonPropertyName("OrgUnitLocationTypes")]
        public OrgUnitLocationTypes OrgUnitLocationTypes { get; set; }

        [JsonPropertyName("OrgLevel")]
        public OrgLevel OrgLevel { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ActiveEmployeePosition
    {
        [JsonPropertyName("AverageDailyHours")]
        public decimal AverageDailyHours { get; set; }

        [JsonPropertyName("ClockTransferCode")]
        public string ClockTransferCode { get; set; }

        [JsonPropertyName("Department")]
        public Department Department { get; set; }

        [JsonPropertyName("Job")]
        public Job Job { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("EmploymentIndicator")]
        public EmploymentIndicator EmploymentIndicator { get; set; }

        [JsonPropertyName("Executive")]
        public bool Executive { get; set; }

        [JsonPropertyName("FTE")]
        public decimal FTE { get; set; }

        [JsonPropertyName("IsNonService")]
        public bool IsNonService { get; set; }

        [JsonPropertyName("IsWCBExempt")]
        public bool IsWCBExempt { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("Officer")]
        public bool Officer { get; set; }

        [JsonPropertyName("PayClass")]
        public PayClass PayClass { get; set; }

        [JsonPropertyName("PayGroup")]
        public PayGroup PayGroup { get; set; }

        [JsonPropertyName("PayType")]
        public PayType PayType { get; set; }

        [JsonPropertyName("PositionTerm")]
        public PositionTerm PositionTerm { get; set; }

        [JsonPropertyName("PPACAFullTime")]
        public bool PPACAFullTime { get; set; }

        [JsonPropertyName("SemiMonthlyBottomHours")]
        public decimal SemiMonthlyBottomHours { get; set; }

        [JsonPropertyName("SemiMonthlyTopHours")]
        public decimal SemiMonthlyTopHours { get; set; }

        [JsonPropertyName("StandardCostRate")]
        public decimal StandardCostRate { get; set; }

        [JsonPropertyName("WeeklyHours")]
        public decimal WeeklyHours { get; set; }

        [JsonPropertyName("DefaultTargetBonus")]
        public decimal DefaultTargetBonus { get; set; }

        [JsonPropertyName("PositionAssignments")]
        public PositionAssignments PositionAssignments { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class AdditionalTaxType
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class Address
    {
        [JsonPropertyName("Address1")]
        public string Address1 { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("Address3")]
        public string Address3 { get; set; }

        [JsonPropertyName("Address4")]
        public string Address4 { get; set; }

        [JsonPropertyName("Address5")]
        public string Address5 { get; set; }

        [JsonPropertyName("Address6")]
        public string Address6 { get; set; }

        [JsonPropertyName("City")]
        public string City { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("Country")]
        public Country Country { get; set; }

        [JsonPropertyName("State")]
        public State State { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Addresses
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class AgreementEndReason
    {
        [JsonPropertyName("IsCompChangeReason")]
        public bool IsCompChangeReason { get; set; }

        [JsonPropertyName("IsLeaveReason")]
        public bool IsLeaveReason { get; set; }

        [JsonPropertyName("IsPositionChangeReason")]
        public bool IsPositionChangeReason { get; set; }

        [JsonPropertyName("IsTerminationReason")]
        public bool IsTerminationReason { get; set; }

        [JsonPropertyName("IsVoluntaryReason")]
        public bool IsVoluntaryReason { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class AgreementReason
    {
        [JsonPropertyName("IsCompChangeReason")]
        public bool IsCompChangeReason { get; set; }

        [JsonPropertyName("IsLeaveReason")]
        public bool IsLeaveReason { get; set; }

        [JsonPropertyName("IsPositionChangeReason")]
        public bool IsPositionChangeReason { get; set; }

        [JsonPropertyName("IsTerminationReason")]
        public bool IsTerminationReason { get; set; }

        [JsonPropertyName("IsVoluntaryReason")]
        public bool IsVoluntaryReason { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class AssignedSexComplianceCode
    {
        [JsonPropertyName("ComplianceCode")]
        public string ComplianceCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class AssignedSexCountryAware
    {
        [JsonPropertyName("AssignedSexComplianceCode")]
        public AssignedSexComplianceCode AssignedSexComplianceCode { get; set; }

        [JsonPropertyName("UserDefinedComplianceCode")]
        public string UserDefinedComplianceCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class AttendancePolicy
    {
        [JsonPropertyName("TrackingBasedOn")]
        public int TrackingBasedOn { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class AUSFederalTaxes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class AUSSuperannuation
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class AUSSuperannuationRules
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class AuthorityType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class AuthorizationAssignments
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class AuthorizationPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Badges
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class BioSensitivityLevel
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class BusinessUnit
    {
        [JsonPropertyName("BusinessUnitGlobalId")]
        public string BusinessUnitGlobalId { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("BusinessUnitParents")]
        public List<BusinessUnitParent> BusinessUnitParents { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class BusinessUnitParent
    {
        [JsonPropertyName("BusinessUnitGlobalId")]
        public string BusinessUnitGlobalId { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class CalculationType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class CANFederalTaxes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class CANStateTaxes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class CANTaxStatuses
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Category
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ChildOrgUnits
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class CitizenshipType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ClockDeviceGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ClockDeviceGroups
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class ComparableLocation
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class CompensationSummary
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class ConfidentialIdentification
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class ConfidentialIdentificationType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ContactInformationType
    {
        [JsonPropertyName("ContactInformationTypeGroup")]
        public ContactInformationTypeGroup ContactInformationTypeGroup { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ContactInformationTypeGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Contacts
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Country
    {
        [JsonPropertyName("Name")]
        public string Name { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Course
    {
        [JsonPropertyName("CourseCode")]
        public string CourseCode { get; set; }

        [JsonPropertyName("CourseType")]
        public CourseType CourseType { get; set; }

        [JsonPropertyName("CourseProvider")]
        public CourseProvider CourseProvider { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class CourseProvider
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Courses
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class CourseType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Culture
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Data
    {
        [JsonPropertyName("AvatarUri")]
        public string AvatarUri { get; set; }

        [JsonPropertyName("BadgeNumber")]
        public string BadgeNumber { get; set; }

        [JsonPropertyName("BioExempt")]
        public bool BioExempt { get; set; }

        [JsonPropertyName("BirthDate")]
        public DateTime? BirthDate { get; set; }

        [JsonPropertyName("BirthCountry")]
        public string BirthCountry { get; set; }

        [JsonPropertyName("BirthState")]
        public string BirthState { get; set; }

        [JsonPropertyName("BirthCity")]
        public string BirthCity { get; set; }

        [JsonPropertyName("ChecksumTimestamp")]
        public DateTime? ChecksumTimestamp { get; set; }

        [JsonPropertyName("ClockSupervisor")]
        public bool ClockSupervisor { get; set; }

        [JsonPropertyName("COBRANotificationSentDate")]
        public DateTime? COBRANotificationSentDate { get; set; }

        [JsonPropertyName("COBRANotificationStatus")]
        public int COBRANotificationStatus { get; set; }

        [JsonPropertyName("Culture")]
        public Culture Culture { get; set; }

        [JsonPropertyName("DateOfDeath")]
        public DateTime? DateOfDeath { get; set; }

        [JsonPropertyName("EligibleForRehire")]
        public string EligibleForRehire { get; set; }

        [JsonPropertyName("EmployeeId")]
        public int EmployeeId { get; set; }

        [JsonPropertyName("EmployeePin")]
        public string EmployeePin { get; set; }

        [JsonPropertyName("EntitlementOverrideDate")]
        public DateTime? EntitlementOverrideDate { get; set; }

        [JsonPropertyName("EstimatedReturnDate")]
        public DateTime? EstimatedReturnDate { get; set; }

        [JsonPropertyName("ExportDate")]
        public DateTime? ExportDate { get; set; }

        [JsonPropertyName("FederatedId")]
        public string FederatedId { get; set; }

        [JsonPropertyName("Gender")]
        public string Gender { get; set; }

        [JsonPropertyName("HireDate")]
        public DateTime? HireDate { get; set; }

        [JsonPropertyName("HomePhone")]
        public string HomePhone { get; set; }

        [JsonPropertyName("IsAboriginal")]
        public string IsAboriginal { get; set; }

        [JsonPropertyName("IsVisibleMinority")]
        public string IsVisibleMinority { get; set; }

        [JsonPropertyName("EligibleForOnDemandPay")]
        public bool EligibleForOnDemandPay { get; set; }

        [JsonPropertyName("EligibleForDFWalletPayCard")]
        public bool EligibleForDFWalletPayCard { get; set; }

        [JsonPropertyName("EmployeeLatestUpdatedTimestamp")]
        public DateTime? EmployeeLatestUpdatedTimestamp { get; set; }

        [JsonPropertyName("LastPayrollNewHireExportDate")]
        public DateTime? LastPayrollNewHireExportDate { get; set; }

        [JsonPropertyName("Nationality")]
        public string Nationality { get; set; }

        [JsonPropertyName("NewHireApprovalDate")]
        public DateTime? NewHireApprovalDate { get; set; }

        [JsonPropertyName("NewHireApproved")]
        public bool NewHireApproved { get; set; }

        [JsonPropertyName("NewHireApprovedBy")]
        public string NewHireApprovedBy { get; set; }

        [JsonPropertyName("OriginalHireDate")]
        public DateTime? OriginalHireDate { get; set; }

        [JsonPropertyName("PhotoExempt")]
        public bool PhotoExempt { get; set; }

        [JsonPropertyName("PPACAOverrideDate")]
        public DateTime? PPACAOverrideDate { get; set; }

        [JsonPropertyName("RegisteredDisabled")]
        public string RegisteredDisabled { get; set; }

        [JsonPropertyName("RequiresExitInterview")]
        public bool RequiresExitInterview { get; set; }

        [JsonPropertyName("SeniorityDate")]
        public DateTime? SeniorityDate { get; set; }

        [JsonPropertyName("SocialSecurityNumber")]
        public string SocialSecurityNumber { get; set; }

        [JsonPropertyName("SSNCountryCode")]
        public string SSNCountryCode { get; set; }

        [JsonPropertyName("SSNExpiryDate")]
        public DateTime? SSNExpiryDate { get; set; }

        [JsonPropertyName("StartDate")]
        public DateTime? StartDate { get; set; }

        [JsonPropertyName("TaxExempt")]
        public bool TaxExempt { get; set; }

        [JsonPropertyName("TaxpayerId")]
        public string TaxpayerId { get; set; }

        [JsonPropertyName("TerminationDate")]
        public DateTime? TerminationDate { get; set; }

        [JsonPropertyName("VeteranSeparationDate")]
        public DateTime? VeteranSeparationDate { get; set; }

        [JsonPropertyName("FirstTimeAccessEmailSentCount")]
        public int FirstTimeAccessEmailSentCount { get; set; }

        [JsonPropertyName("FirstTimeAccessVerificationAttempts")]
        public int FirstTimeAccessVerificationAttempts { get; set; }

        [JsonPropertyName("SendFirstTimeAccessEmail")]
        public bool SendFirstTimeAccessEmail { get; set; }

        [JsonPropertyName("HasManagedEmployee")]
        public bool HasManagedEmployee { get; set; }

        [JsonPropertyName("EmployeeBadge")]
        public EmployeeBadge EmployeeBadge { get; set; }

        [JsonPropertyName("Badges")]
        public Badges Badges { get; set; }

        [JsonPropertyName("PreStartDate")]
        public DateTime? PreStartDate { get; set; }

        [JsonPropertyName("PayrollKey")]
        public string PayrollKey { get; set; }

        [JsonPropertyName("LoginId")]
        public string LoginId { get; set; }

        [JsonPropertyName("HomeOrganization")]
        public HomeOrganization HomeOrganization { get; set; }

        [JsonPropertyName("EmployeeNumber")]
        public string EmployeeNumber { get; set; }

        [JsonPropertyName("EmploymentStatuses")]
        public EmploymentStatuses EmploymentStatuses { get; set; }

        [JsonPropertyName("WorkAssignments")]
        public WorkAssignments WorkAssignments { get; set; }

        [JsonPropertyName("Pronouns")]
        public string Pronouns { get; set; }

        [JsonPropertyName("Contacts")]
        public Contacts Contacts { get; set; }

        [JsonPropertyName("Addresses")]
        public Addresses Addresses { get; set; }

        [JsonPropertyName("Roles")]
        public Roles Roles { get; set; }

        [JsonPropertyName("EmployeeManagers")]
        public EmployeeManagers EmployeeManagers { get; set; }

        [JsonPropertyName("EmployeeWorkAssignmentManagers")]
        public EmployeeWorkAssignmentManagers EmployeeWorkAssignmentManagers { get; set; }

        [JsonPropertyName("CompensationSummary")]
        public CompensationSummary CompensationSummary { get; set; }

        [JsonPropertyName("SSOAccounts")]
        public SSOAccounts SSOAccounts { get; set; }

        [JsonPropertyName("MaritalStatuses")]
        public MaritalStatuses MaritalStatuses { get; set; }

        [JsonPropertyName("Locations")]
        public Locations Locations { get; set; }

        [JsonPropertyName("Religions")]
        public Religions Religions { get; set; }

        [JsonPropertyName("BioSensitivityLevel")]
        public BioSensitivityLevel BioSensitivityLevel { get; set; }

        [JsonPropertyName("CitizenshipType")]
        public CitizenshipType CitizenshipType { get; set; }

        [JsonPropertyName("SchoolYear")]
        public SchoolYear SchoolYear { get; set; }

        [JsonPropertyName("HealthWellnessDetails")]
        public HealthWellnessDetails HealthWellnessDetails { get; set; }

        [JsonPropertyName("Courses")]
        public Courses Courses { get; set; }

        [JsonPropertyName("VolunteerLists")]
        public VolunteerLists VolunteerLists { get; set; }

        [JsonPropertyName("HRIncidents")]
        public HRIncidents HRIncidents { get; set; }

        [JsonPropertyName("Skills")]
        public Skills Skills { get; set; }

        [JsonPropertyName("TrainingPrograms")]
        public TrainingPrograms TrainingPrograms { get; set; }

        [JsonPropertyName("UnionMemberships")]
        public UnionMemberships UnionMemberships { get; set; }

        [JsonPropertyName("EmploymentTypes")]
        public EmploymentTypes EmploymentTypes { get; set; }

        [JsonPropertyName("HighlyCompensatedEmployees")]
        public HighlyCompensatedEmployees HighlyCompensatedEmployees { get; set; }

        [JsonPropertyName("PayGradeRates")]
        public PayGradeRates PayGradeRates { get; set; }

        [JsonPropertyName("DirectDeposits")]
        public DirectDeposits DirectDeposits { get; set; }

        [JsonPropertyName("IRLTaxPAYEExclusionInfo")]
        public IRLTaxPAYEExclusionInfo IRLTaxPAYEExclusionInfo { get; set; }

        [JsonPropertyName("IRLTaxPRSIInfo")]
        public IRLTaxPRSIInfo IRLTaxPRSIInfo { get; set; }

        [JsonPropertyName("IRLTaxRPNInfo")]
        public IRLTaxRPNInfo IRLTaxRPNInfo { get; set; }

        [JsonPropertyName("IRLTaxEWSSInfo")]
        public IRLTaxEWSSInfo IRLTaxEWSSInfo { get; set; }

        [JsonPropertyName("CANFederalTaxes")]
        public CANFederalTaxes CANFederalTaxes { get; set; }

        [JsonPropertyName("CANStateTaxes")]
        public CANStateTaxes CANStateTaxes { get; set; }

        [JsonPropertyName("USFederalTaxes")]
        public USFederalTaxes USFederalTaxes { get; set; }

        [JsonPropertyName("MUSTaxes")]
        public MUSTaxes MUSTaxes { get; set; }

        [JsonPropertyName("AUSFederalTaxes")]
        public AUSFederalTaxes AUSFederalTaxes { get; set; }

        [JsonPropertyName("EmployeePayrollTaxes")]
        public EmployeePayrollTaxes EmployeePayrollTaxes { get; set; }

        [JsonPropertyName("EmployeePayrollTaxParameters")]
        public EmployeePayrollTaxParameters EmployeePayrollTaxParameters { get; set; }

        [JsonPropertyName("USStateTaxes")]
        public USStateTaxes USStateTaxes { get; set; }

        [JsonPropertyName("EmergencyContacts")]
        public EmergencyContacts EmergencyContacts { get; set; }

        [JsonPropertyName("Ethnicities")]
        public Ethnicities Ethnicities { get; set; }

        [JsonPropertyName("Disabilities")]
        public Disabilities Disabilities { get; set; }

        [JsonPropertyName("VeteranStatuses")]
        public VeteranStatuses VeteranStatuses { get; set; }

        [JsonPropertyName("GLSplits")]
        public GLSplits GLSplits { get; set; }

        [JsonPropertyName("EmployeeProperties")]
        public EmployeeProperties EmployeeProperties { get; set; }

        [JsonPropertyName("GlobalProperties")]
        public GlobalProperties GlobalProperties { get; set; }

        [JsonPropertyName("LaborDefaults")]
        public LaborDefaults LaborDefaults { get; set; }

        [JsonPropertyName("DocumentManagementSecurityGroups")]
        public DocumentManagementSecurityGroups DocumentManagementSecurityGroups { get; set; }

        [JsonPropertyName("ClockDeviceGroups")]
        public ClockDeviceGroups ClockDeviceGroups { get; set; }

        [JsonPropertyName("EmployeePayAdjustCodeGroups")]
        public EmployeePayAdjustCodeGroups EmployeePayAdjustCodeGroups { get; set; }

        [JsonPropertyName("UserPayAdjustCodeGroups")]
        public UserPayAdjustCodeGroups UserPayAdjustCodeGroups { get; set; }

        [JsonPropertyName("WorkContracts")]
        public WorkContracts WorkContracts { get; set; }

        [JsonPropertyName("PerformanceRatings")]
        public PerformanceRatings PerformanceRatings { get; set; }

        [JsonPropertyName("EIRates")]
        public EIRates EIRates { get; set; }

        [JsonPropertyName("USTaxStatuses")]
        public USTaxStatuses USTaxStatuses { get; set; }

        [JsonPropertyName("CANTaxStatuses")]
        public CANTaxStatuses CANTaxStatuses { get; set; }

        [JsonPropertyName("OrgUnitInfos")]
        public OrgUnitInfos OrgUnitInfos { get; set; }

        [JsonPropertyName("ManagedEmployees")]
        public ManagedEmployees ManagedEmployees { get; set; }

        [JsonPropertyName("ConfidentialIdentification")]
        public ConfidentialIdentification ConfidentialIdentification { get; set; }

        [JsonPropertyName("EmployeeCertifications")]
        public EmployeeCertifications EmployeeCertifications { get; set; }

        [JsonPropertyName("EmploymentAgreements")]
        public EmploymentAgreements EmploymentAgreements { get; set; }

        [JsonPropertyName("HRPolicies")]
        public HRPolicies HRPolicies { get; set; }

        [JsonPropertyName("AuthorizationAssignments")]
        public AuthorizationAssignments AuthorizationAssignments { get; set; }

        [JsonPropertyName("GenderIdentity")]
        public GenderIdentity GenderIdentity { get; set; }

        [JsonPropertyName("EmployeeAssignedSexAndGenderIdentities")]
        public EmployeeAssignedSexAndGenderIdentities EmployeeAssignedSexAndGenderIdentities { get; set; }

        [JsonPropertyName("OnboardingPolicies")]
        public OnboardingPolicies OnboardingPolicies { get; set; }

        [JsonPropertyName("PayPeriodInformation")]
        public PayPeriodInformation PayPeriodInformation { get; set; }

        [JsonPropertyName("EarningElections")]
        public EarningElections EarningElections { get; set; }

        [JsonPropertyName("DeductionElections")]
        public DeductionElections DeductionElections { get; set; }

        [JsonPropertyName("LastActiveManagers")]
        public LastActiveManagers LastActiveManagers { get; set; }

        [JsonPropertyName("VacBidGroup")]
        public VacBidGroup VacBidGroup { get; set; }

        [JsonPropertyName("DependentsBeneficiaries")]
        public DependentsBeneficiaries DependentsBeneficiaries { get; set; }

        [JsonPropertyName("UKTaxDetails")]
        public UKTaxDetails UKTaxDetails { get; set; }

        [JsonPropertyName("UKStudentLoan")]
        public UKStudentLoan UKStudentLoan { get; set; }

        [JsonPropertyName("UKPostgraduateLoan")]
        public UKPostgraduateLoan UKPostgraduateLoan { get; set; }

        [JsonPropertyName("EmployeeUKIrregularPaymentDetails")]
        public EmployeeUKIrregularPaymentDetails EmployeeUKIrregularPaymentDetails { get; set; }

        [JsonPropertyName("ContinuousEmploymentStartDate")]
        public DateTime? ContinuousEmploymentStartDate { get; set; }

        [JsonPropertyName("LSLEligibilityDate")]
        public DateTime? LSLEligibilityDate { get; set; }

        [JsonPropertyName("UKNIDetails")]
        public UKNIDetails UKNIDetails { get; set; }

        [JsonPropertyName("UserAccount")]
        public UserAccount UserAccount { get; set; }

        [JsonPropertyName("LastNamePrefix")]
        public LastNamePrefix LastNamePrefix { get; set; }

        [JsonPropertyName("LastNamePrefixAtBirth")]
        public LastNamePrefixAtBirth LastNamePrefixAtBirth { get; set; }

        [JsonPropertyName("NameAffix")]
        public NameAffix NameAffix { get; set; }

        [JsonPropertyName("NameAffixAtBirth")]
        public NameAffixAtBirth NameAffixAtBirth { get; set; }

        [JsonPropertyName("ProfessionalTitle")]
        public string ProfessionalTitle { get; set; }

        [JsonPropertyName("AUSSuperannuation")]
        public AUSSuperannuation AUSSuperannuation { get; set; }

        [JsonPropertyName("AUSSuperannuationRules")]
        public AUSSuperannuationRules AUSSuperannuationRules { get; set; }

        [JsonPropertyName("TerminationNoticeDate")]
        public DateTime? TerminationNoticeDate { get; set; }

        [JsonPropertyName("RetirementRequestDate")]
        public DateTime? RetirementRequestDate { get; set; }

        [JsonPropertyName("EmployeeShortTimeWork")]
        public EmployeeShortTimeWork EmployeeShortTimeWork { get; set; }

        [JsonPropertyName("DEUTaxSocialInsurance")]
        public DEUTaxSocialInsurance DEUTaxSocialInsurance { get; set; }

        [JsonPropertyName("DEUEmployeeAccidentInsurance")]
        public DEUEmployeeAccidentInsurance DEUEmployeeAccidentInsurance { get; set; }

        [JsonPropertyName("DEUEmployeeWageTax")]
        public DEUEmployeeWageTax DEUEmployeeWageTax { get; set; }

        [JsonPropertyName("NZLKiwiSaver")]
        public List<NZLKiwiSaver> NZLKiwiSaver { get; set; }

        [JsonPropertyName("UnknownBirthDate")]
        public bool UnknownBirthDate { get; set; }

        [JsonPropertyName("EligibleForPreTaxTips")]
        public bool EligibleForPreTaxTips { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("NewXRefCode")]
        public string NewXRefCode { get; set; }

        [JsonPropertyName("CommonName")]
        public string CommonName { get; set; }

        [JsonPropertyName("DisplayName")]
        public string DisplayName { get; set; }

        [JsonPropertyName("FirstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("LastName")]
        public string LastName { get; set; }

        [JsonPropertyName("Initials")]
        public string Initials { get; set; }

        [JsonPropertyName("MaidenName")]
        public string MaidenName { get; set; }

        [JsonPropertyName("MiddleName")]
        public string MiddleName { get; set; }

        [JsonPropertyName("PreferredLastName")]
        public string PreferredLastName { get; set; }

        [JsonPropertyName("SecondLastName")]
        public string SecondLastName { get; set; }

        [JsonPropertyName("Suffix")]
        public string Suffix { get; set; }

        [JsonPropertyName("Title")]
        public string Title { get; set; }

        [JsonPropertyName("PreviousLastName")]
        public string PreviousLastName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Deduction
    {
        [JsonPropertyName("CalculationType")]
        public CalculationType CalculationType { get; set; }

        [JsonPropertyName("DeductionCode")]
        public DeductionCode DeductionCode { get; set; }

        [JsonPropertyName("DeductionType")]
        public DeductionType DeductionType { get; set; }

        [JsonPropertyName("DisplayName")]
        public string DisplayName { get; set; }

        [JsonPropertyName("DebitJournalNumber")]
        public string DebitJournalNumber { get; set; }

        [JsonPropertyName("CreditJournalNumber")]
        public string CreditJournalNumber { get; set; }

        [JsonPropertyName("IsDecliningBalance")]
        public bool IsDecliningBalance { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DeductionCode
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DeductionElections
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class DeductionLimit
    {
        [JsonPropertyName("LimitAccessType")]
        public LimitAccessType LimitAccessType { get; set; }

        [JsonPropertyName("AccumulationType")]
        public AccumulationType AccumulationType { get; set; }

        [JsonPropertyName("LimitType")]
        public LimitType LimitType { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DeductionParameter
    {
        [JsonPropertyName("ParameterAccessType")]
        public ParameterAccessType ParameterAccessType { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DeductionType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Deparment
    {
        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Department
    {
        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DependentsBeneficiaries
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class DEUEmployeeAccidentInsurance
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class DEUEmployeeWageTax
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class DEUHoursChangeReason
    {
        [JsonPropertyName("ITSGCode")]
        public string ITSGCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DEUSTWParticipationReason
    {
        [JsonPropertyName("DEUSTWParticipationReasonId")]
        public int DEUSTWParticipationReasonId { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DEUTaxSocialInsurance
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class DirectDeposits
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Disabilities
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class DisabilityEvidenceIssuingAgency
    {
        [JsonPropertyName("DisabilityEvidenceIssuingAgencyId")]
        public int DisabilityEvidenceIssuingAgencyId { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DisabilityEvidenceType
    {
        [JsonPropertyName("DisabilityEvidenceTypeId")]
        public int DisabilityEvidenceTypeId { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DisabilityGroup
    {
        [JsonPropertyName("DisabilityGroupId")]
        public int DisabilityGroupId { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DisabilityWorkingTime
    {
        [JsonPropertyName("DisabilityWorkingTimeId")]
        public int DisabilityWorkingTimeId { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Docket
    {
        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DocMgmtSecurityGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class DocumentManagementSecurityGroups
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Earning
    {
        [JsonPropertyName("CalculationType")]
        public CalculationType CalculationType { get; set; }

        [JsonPropertyName("CreditJournalNumber")]
        public string CreditJournalNumber { get; set; }

        [JsonPropertyName("DebitJournalNumber")]
        public string DebitJournalNumber { get; set; }

        [JsonPropertyName("DisplayName")]
        public string DisplayName { get; set; }

        [JsonPropertyName("EarningCode")]
        public EarningCode EarningCode { get; set; }

        [JsonPropertyName("IsDecliningBalance")]
        public bool IsDecliningBalance { get; set; }

        [JsonPropertyName("IsGenerated")]
        public bool IsGenerated { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EarningCode
    {
        [JsonPropertyName("EarningType")]
        public EarningType EarningType { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EarningElections
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EarningGroup
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class EarningLimit
    {
        [JsonPropertyName("LimitAccessType")]
        public LimitAccessType LimitAccessType { get; set; }

        [JsonPropertyName("AccumulationType")]
        public AccumulationType AccumulationType { get; set; }

        [JsonPropertyName("LimitType")]
        public LimitType LimitType { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EarningParameter
    {
        [JsonPropertyName("CodeName")]
        public string CodeName { get; set; }

        [JsonPropertyName("ParameterAccessType")]
        public ParameterAccessType ParameterAccessType { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EarningType
    {
        [JsonPropertyName("CodeName")]
        public string CodeName { get; set; }

        [JsonPropertyName("IsGLAllocatedDebit")]
        public bool IsGLAllocatedDebit { get; set; }

        [JsonPropertyName("IsGLAllocatedCredit")]
        public bool IsGLAllocatedCredit { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EIRates
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class ElectionSchedule
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ElectionStartPayGroup
    {
        [JsonPropertyName("PayFrequency")]
        public PayFrequency PayFrequency { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmergencyContacts
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeAssignedSexAndGenderIdentities
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeBadge
    {
        [JsonPropertyName("BadgeNumber")]
        public string BadgeNumber { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmployeeCertifications
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeDeductionLimits
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeDeductionParameters
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeDefaultLaborMetricsCodes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeEarningLimits
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeEarningParameters
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeEEO
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmployeeGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmployeeLocationAuthorities
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeManagers
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeOccupationalPension
    {
        [JsonPropertyName("PensionStartDate")]
        public DateTime? PensionStartDate { get; set; }

        [JsonPropertyName("PensionProviderXrefCode")]
        public string PensionProviderXrefCode { get; set; }

        [JsonPropertyName("PaymentCompletedBy")]
        public string PaymentCompletedBy { get; set; }

        [JsonPropertyName("MembershipNumber")]
        public string MembershipNumber { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmployeePayAdjustCodeGroups
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeePayrollTaxes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeePayrollTaxParameters
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeePrivateHealthInsurance
    {
        [JsonPropertyName("HealthInsuranceStartDate")]
        public DateTime? HealthInsuranceStartDate { get; set; }

        [JsonPropertyName("PrivateHealthInsuranceXrefCode")]
        public string PrivateHealthInsuranceXrefCode { get; set; }

        [JsonPropertyName("PaymentCompletedByXrefCode")]
        public string PaymentCompletedByXrefCode { get; set; }

        [JsonPropertyName("TotalContributionHealth")]
        public decimal TotalContributionHealth { get; set; }

        [JsonPropertyName("TotalContributionCare")]
        public decimal TotalContributionCare { get; set; }

        [JsonPropertyName("BaseContributionHealth")]
        public decimal BaseContributionHealth { get; set; }

        [JsonPropertyName("BaseContributionCare")]
        public decimal BaseContributionCare { get; set; }

        [JsonPropertyName("MembershipNumber")]
        public string MembershipNumber { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmployeeProperties
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeProperty
    {
        [JsonPropertyName("DataType")]
        public int DataType { get; set; }

        [JsonPropertyName("EmployeeCardinality")]
        public int EmployeeCardinality { get; set; }

        [JsonPropertyName("IsEditable")]
        public bool IsEditable { get; set; }

        [JsonPropertyName("DataTypeParam")]
        public string DataTypeParam { get; set; }

        [JsonPropertyName("GenerateHREvent")]
        public bool GenerateHREvent { get; set; }

        [JsonPropertyName("Sequence")]
        public int Sequence { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmployeeShortTimeWork
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeTrainingProgram
    {
        [JsonPropertyName("TrainingProgram")]
        public TrainingProgram TrainingProgram { get; set; }

        [JsonPropertyName("EnrollmentDate")]
        public DateTime? EnrollmentDate { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmployeeUKIrregularPaymentDetails
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmployeeWorkAssignmentManagers
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmploymentAgreementDetails
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentAgreementDuration
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentAgreementPopulation
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentAgreements
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmploymentAgreementSettlement
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentAgreementTaxRegime
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentAgreementType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentIndicator
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentStatus
    {
        [JsonPropertyName("IsBenefitArrearsEnabled")]
        public bool IsBenefitArrearsEnabled { get; set; }

        [JsonPropertyName("EffectiveStartingPointOfDay")]
        public string EffectiveStartingPointOfDay { get; set; }

        [JsonPropertyName("EmploymentStatusGroup")]
        public EmploymentStatusGroup EmploymentStatusGroup { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentStatuses
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EmploymentStatusGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentStatusReason
    {
        [JsonPropertyName("IsCompChangeReason")]
        public bool IsCompChangeReason { get; set; }

        [JsonPropertyName("IsLeaveReason")]
        public bool IsLeaveReason { get; set; }

        [JsonPropertyName("IsPositionChangeReason")]
        public bool IsPositionChangeReason { get; set; }

        [JsonPropertyName("IsTerminationReason")]
        public bool IsTerminationReason { get; set; }

        [JsonPropertyName("IsVoluntaryReason")]
        public bool IsVoluntaryReason { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EmploymentTypes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class EnrollmentStatus
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class EntitlementPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Ethnicities
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Ethnicity
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class FilingStatus
    {
        [JsonPropertyName("CountryCode")]
        public string CountryCode { get; set; }

        [JsonPropertyName("FederalFilingStatusCode")]
        public string FederalFilingStatusCode { get; set; }

        [JsonPropertyName("CalculationCode")]
        public string CalculationCode { get; set; }

        [JsonPropertyName("PayrollOutput")]
        public string PayrollOutput { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("StateCode")]
        public string StateCode { get; set; }

        [JsonPropertyName("StateFilingStatusCode")]
        public string StateFilingStatusCode { get; set; }
    }

    public class FinancialInstitution
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class FLSAStatus
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class GenderIdentity
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class GenderIdentityCountryAware
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class GeoCity
    {
        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class GlobalProperties
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class GlobalProperty
    {
        [JsonPropertyName("DataType")]
        public int DataType { get; set; }

        [JsonPropertyName("EmployeeCardinality")]
        public int EmployeeCardinality { get; set; }

        [JsonPropertyName("IsEditable")]
        public bool IsEditable { get; set; }

        [JsonPropertyName("DataTypeParam")]
        public string DataTypeParam { get; set; }

        [JsonPropertyName("GenerateHREvent")]
        public bool GenerateHREvent { get; set; }

        [JsonPropertyName("Sequence")]
        public int Sequence { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class GLSplits
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class HealthWellnessDetails
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class HighlyCompensatedEmployees
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class HomeOrganization
    {
        [JsonPropertyName("PhysicalLocation")]
        public bool PhysicalLocation { get; set; }

        [JsonPropertyName("BusinessPhone")]
        public string BusinessPhone { get; set; }

        [JsonPropertyName("ContactBusinessPhone")]
        public string ContactBusinessPhone { get; set; }

        [JsonPropertyName("ContactCellPhone")]
        public string ContactCellPhone { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("CountryCode")]
        public string CountryCode { get; set; }

        [JsonPropertyName("OpeningDate")]
        public DateTime? OpeningDate { get; set; }

        [JsonPropertyName("ClosingDate")]
        public DateTime? ClosingDate { get; set; }

        [JsonPropertyName("ComparableLocation")]
        public ComparableLocation ComparableLocation { get; set; }

        [JsonPropertyName("Department")]
        public Department Department { get; set; }

        [JsonPropertyName("Zone")]
        public Zone Zone { get; set; }

        [JsonPropertyName("StartDayOfWeek")]
        public int StartDayOfWeek { get; set; }

        [JsonPropertyName("GeoCity")]
        public GeoCity GeoCity { get; set; }

        [JsonPropertyName("Timezone")]
        public Timezone Timezone { get; set; }

        [JsonPropertyName("County")]
        public string County { get; set; }

        [JsonPropertyName("IsOrgManaged")]
        public bool IsOrgManaged { get; set; }

        [JsonPropertyName("IsMobileOrg")]
        public bool IsMobileOrg { get; set; }

        [JsonPropertyName("PublicName")]
        public string PublicName { get; set; }

        [JsonPropertyName("ClockTransferCode")]
        public string ClockTransferCode { get; set; }

        [JsonPropertyName("ContactEmail")]
        public string ContactEmail { get; set; }

        [JsonPropertyName("ContactName")]
        public string ContactName { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("StateCode")]
        public string StateCode { get; set; }

        [JsonPropertyName("Address")]
        public string Address { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("LegalEntity")]
        public LegalEntity LegalEntity { get; set; }

        [JsonPropertyName("OrgUnitLegalEntities")]
        public OrgUnitLegalEntities OrgUnitLegalEntities { get; set; }

        [JsonPropertyName("OrgUnitParents")]
        public OrgUnitParents OrgUnitParents { get; set; }

        [JsonPropertyName("ChildOrgUnits")]
        public ChildOrgUnits ChildOrgUnits { get; set; }

        [JsonPropertyName("OrgUnitLocationTypes")]
        public OrgUnitLocationTypes OrgUnitLocationTypes { get; set; }

        [JsonPropertyName("OrgLevel")]
        public OrgLevel OrgLevel { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class HRIncidentAction
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class HRIncidentBodyPart
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class HRIncidentInjury
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class HRIncidentNotes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class HRIncidents
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class HRIncidentType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class HRPolicies
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class HRPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class IRLTaxEWSSInfo
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class IRLTaxPAYEExclusionInfo
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class IRLTaxPRSIInfo
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class IRLTaxRPNInfo
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Item
    {
        [JsonPropertyName("BadgeNumber")]
        public string BadgeNumber { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("Position")]
        public Position Position { get; set; }

        [JsonPropertyName("Location")]
        public Location Location { get; set; }

        [JsonPropertyName("EmploymentIndicator")]
        public EmploymentIndicator EmploymentIndicator { get; set; }

        [JsonPropertyName("EmploymentStatusReason")]
        public EmploymentStatusReason EmploymentStatusReason { get; set; }

        [JsonPropertyName("FlatAmount")]
        public decimal FlatAmount { get; set; }

        [JsonPropertyName("FTE")]
        public decimal FTE { get; set; }

        [JsonPropertyName("IsPAPrimaryWorkSite")]
        public bool IsPAPrimaryWorkSite { get; set; }

        [JsonPropertyName("IsPrimary")]
        public bool IsPrimary { get; set; }

        [JsonPropertyName("OriginalIsPrimary")]
        public bool OriginalIsPrimary { get; set; }

        [JsonPropertyName("OriginalEffectiveStart")]
        public DateTime? OriginalEffectiveStart { get; set; }

        [JsonPropertyName("OriginalEffectiveEnd")]
        public DateTime? OriginalEffectiveEnd { get; set; }

        [JsonPropertyName("IsStatutory")]
        public bool IsStatutory { get; set; }

        [JsonPropertyName("IsVirtual")]
        public bool IsVirtual { get; set; }

        [JsonPropertyName("BusinessTitle")]
        public string BusinessTitle { get; set; }

        [JsonPropertyName("JobSetLevel")]
        public JobSetLevel JobSetLevel { get; set; }

        [JsonPropertyName("LaborPercentage")]
        public decimal LaborPercentage { get; set; }

        [JsonPropertyName("LastModifiedTimeStamp")]
        public DateTime? LastModifiedTimeStamp { get; set; }

        [JsonPropertyName("MultiJSalaryAllocationPercent")]
        public decimal MultiJSalaryAllocationPercent { get; set; }

        [JsonPropertyName("ParticipateInReciprocalTaxCalculation")]
        public bool ParticipateInReciprocalTaxCalculation { get; set; }

        [JsonPropertyName("TelecommuterPercentage")]
        public decimal TelecommuterPercentage { get; set; }

        [JsonPropertyName("IsConvenienceOfEmployee")]
        public bool IsConvenienceOfEmployee { get; set; }

        [JsonPropertyName("EndSecondaryWorkAssignments")]
        public bool EndSecondaryWorkAssignments { get; set; }

        [JsonPropertyName("PositionTerm")]
        public PositionTerm PositionTerm { get; set; }

        [JsonPropertyName("PRBankAccountBranchAddress")]
        public PRBankAccountBranchAddress PRBankAccountBranchAddress { get; set; }

        [JsonPropertyName("WorkLocationOverride")]
        public WorkLocationOverride WorkLocationOverride { get; set; }

        [JsonPropertyName("Rank")]
        public int Rank { get; set; }

        [JsonPropertyName("JobRate")]
        public decimal JobRate { get; set; }

        [JsonPropertyName("TipTypeGroup")]
        public TipTypeGroup TipTypeGroup { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("PMPositionAssignment")]
        public PMPositionAssignment PMPositionAssignment { get; set; }

        [JsonPropertyName("JobClassificationGlobal")]
        public JobClassificationGlobal JobClassificationGlobal { get; set; }

        [JsonPropertyName("IsShiftMarketplace")]
        public bool IsShiftMarketplace { get; set; }

        [JsonPropertyName("ParentOrgUnit")]
        public ParentOrgUnit ParentOrgUnit { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("OrgLevel")]
        public OrgLevel OrgLevel { get; set; }

        [JsonPropertyName("OrgUnitLegalEntities")]
        public OrgUnitLegalEntities OrgUnitLegalEntities { get; set; }

        [JsonPropertyName("OrgUnitParents")]
        public OrgUnitParents OrgUnitParents { get; set; }

        [JsonPropertyName("OrgUnitLocationTypes")]
        public OrgUnitLocationTypes OrgUnitLocationTypes { get; set; }

        [JsonPropertyName("LegalEntity")]
        public LegalEntity LegalEntity { get; set; }

        [JsonPropertyName("LegalEntityWorkSiteState")]
        public LegalEntityWorkSiteState LegalEntityWorkSiteState { get; set; }

        [JsonPropertyName("OverrideCustomerFundingIdentifier")]
        public OverrideCustomerFundingIdentifier OverrideCustomerFundingIdentifier { get; set; }

        [JsonPropertyName("LocationType")]
        public LocationType LocationType { get; set; }

        [JsonPropertyName("PRGLSplitSetDetailMetricCodes")]
        public PRGLSplitSetDetailMetricCodes PRGLSplitSetDetailMetricCodes { get; set; }

        [JsonPropertyName("LaborMetricsCode")]
        public LaborMetricsCode LaborMetricsCode { get; set; }

        [JsonPropertyName("EmployeeProperty")]
        public EmployeeProperty EmployeeProperty { get; set; }

        [JsonPropertyName("BitValue")]
        public bool BitValue { get; set; }

        [JsonPropertyName("NumberValue")]
        public int NumberValue { get; set; }

        [JsonPropertyName("OptionValue")]
        public OptionValue OptionValue { get; set; }

        [JsonPropertyName("StringValue")]
        public string StringValue { get; set; }

        [JsonPropertyName("DateTimeValue")]
        public DateTime? DateTimeValue { get; set; }

        [JsonPropertyName("GlobalProperty")]
        public GlobalProperty GlobalProperty { get; set; }

        [JsonPropertyName("BudgetedHeadCount")]
        public int BudgetedHeadCount { get; set; }

        [JsonPropertyName("PayAdjCode")]
        public PayAdjCode PayAdjCode { get; set; }

        [JsonPropertyName("Project")]
        public Project Project { get; set; }

        [JsonPropertyName("Docket")]
        public Docket Docket { get; set; }

        [JsonPropertyName("EmployeeDefaultLaborMetricsCodes")]
        public EmployeeDefaultLaborMetricsCodes EmployeeDefaultLaborMetricsCodes { get; set; }

        [JsonPropertyName("DocMgmtSecurityGroup")]
        public DocMgmtSecurityGroup DocMgmtSecurityGroup { get; set; }

        [JsonPropertyName("ClockDeviceGroup")]
        public ClockDeviceGroup ClockDeviceGroup { get; set; }

        [JsonPropertyName("PayAdjCodeGroup")]
        public PayAdjCodeGroup PayAdjCodeGroup { get; set; }

        [JsonPropertyName("AverageNumOfDays")]
        public decimal AverageNumOfDays { get; set; }

        [JsonPropertyName("BaseHours")]
        public decimal BaseHours { get; set; }

        [JsonPropertyName("BaseComplementaryHours")]
        public decimal BaseComplementaryHours { get; set; }

        [JsonPropertyName("ContractWorkPercent")]
        public decimal ContractWorkPercent { get; set; }

        [JsonPropertyName("CreateShiftOnHolidays")]
        public bool CreateShiftOnHolidays { get; set; }

        [JsonPropertyName("EndDate")]
        public DateTime? EndDate { get; set; }

        [JsonPropertyName("FullTimeHours")]
        public decimal FullTimeHours { get; set; }

        [JsonPropertyName("StartDate")]
        public DateTime? StartDate { get; set; }

        [JsonPropertyName("WorkContract")]
        public WorkContract WorkContract { get; set; }

        [JsonPropertyName("WorkPatternLengthDays")]
        public decimal WorkPatternLengthDays { get; set; }

        [JsonPropertyName("WorkPatterns")]
        public WorkPatterns WorkPatterns { get; set; }

        [JsonPropertyName("NetHours")]
        public decimal NetHours { get; set; }

        [JsonPropertyName("ShiftTimeBegin")]
        public DateTime? ShiftTimeBegin { get; set; }

        [JsonPropertyName("ShiftTimeEnd")]
        public DateTime? ShiftTimeEnd { get; set; }

        [JsonPropertyName("WorkPatternDayIndex")]
        public decimal WorkPatternDayIndex { get; set; }

        [JsonPropertyName("Deparment")]
        public Deparment Deparment { get; set; }

        [JsonPropertyName("Job")]
        public Job Job { get; set; }

        [JsonPropertyName("ShiftType")]
        public ShiftType ShiftType { get; set; }

        [JsonPropertyName("OrgLocationType")]
        public OrgLocationType OrgLocationType { get; set; }

        [JsonPropertyName("Comments")]
        public string Comments { get; set; }

        [JsonPropertyName("NextReviewDate")]
        public DateTime? NextReviewDate { get; set; }

        [JsonPropertyName("PerformanceCycle")]
        public PerformanceCycle PerformanceCycle { get; set; }

        [JsonPropertyName("PerformanceRatingScale")]
        public PerformanceRatingScale PerformanceRatingScale { get; set; }

        [JsonPropertyName("PerformanceRating")]
        public PerformanceRating PerformanceRating { get; set; }

        [JsonPropertyName("RatingScore")]
        public decimal RatingScore { get; set; }

        [JsonPropertyName("ReviewDate")]
        public DateTime? ReviewDate { get; set; }

        [JsonPropertyName("Reviewer")]
        public Reviewer Reviewer { get; set; }

        [JsonPropertyName("ReviewPeriodStartDate")]
        public DateTime? ReviewPeriodStartDate { get; set; }

        [JsonPropertyName("ReviewPeriodEndDate")]
        public DateTime? ReviewPeriodEndDate { get; set; }

        [JsonPropertyName("RateGroup")]
        public string RateGroup { get; set; }

        [JsonPropertyName("StateCode")]
        public string StateCode { get; set; }

        [JsonPropertyName("TaxPropertyCollection")]
        public TaxPropertyCollection TaxPropertyCollection { get; set; }

        [JsonPropertyName("PropertyCodeName")]
        public string PropertyCodeName { get; set; }

        [JsonPropertyName("PropertyValue")]
        public string PropertyValue { get; set; }

        [JsonPropertyName("ProvinceCode")]
        public string ProvinceCode { get; set; }

        [JsonPropertyName("OrgUnitDetail")]
        public OrgUnitDetail OrgUnitDetail { get; set; }

        [JsonPropertyName("Department")]
        public Department Department { get; set; }

        [JsonPropertyName("TerminationDate")]
        public DateTime? TerminationDate { get; set; }

        [JsonPropertyName("EmploymentStatusGroupXRefCode")]
        public string EmploymentStatusGroupXRefCode { get; set; }

        [JsonPropertyName("ManagerXRefCode")]
        public string ManagerXRefCode { get; set; }

        [JsonPropertyName("ManagerName")]
        public string ManagerName { get; set; }

        [JsonPropertyName("ActiveEmployeePosition")]
        public ActiveEmployeePosition ActiveEmployeePosition { get; set; }

        [JsonPropertyName("ActiveEmployeeLocation")]
        public ActiveEmployeeLocation ActiveEmployeeLocation { get; set; }

        [JsonPropertyName("ConfidentialIdentificationType")]
        public ConfidentialIdentificationType ConfidentialIdentificationType { get; set; }

        [JsonPropertyName("CountryCode")]
        public string CountryCode { get; set; }

        [JsonPropertyName("ExpiryDate")]
        public DateTime? ExpiryDate { get; set; }

        [JsonPropertyName("IDNumber")]
        public string IDNumber { get; set; }

        [JsonPropertyName("PlaceOfIssue")]
        public string PlaceOfIssue { get; set; }

        [JsonPropertyName("IssueDate")]
        public DateTime? IssueDate { get; set; }

        [JsonPropertyName("UseForRTW")]
        public bool UseForRTW { get; set; }

        [JsonPropertyName("RTWDocReview")]
        public string RTWDocReview { get; set; }

        [JsonPropertyName("RTWDocReviewOn")]
        public DateTime? RTWDocReviewOn { get; set; }

        [JsonPropertyName("LMSCertification")]
        public LMSCertification LMSCertification { get; set; }

        [JsonPropertyName("CertificationNumber")]
        public string CertificationNumber { get; set; }

        [JsonPropertyName("Course")]
        public Course Course { get; set; }

        [JsonPropertyName("TrainingProgram")]
        public TrainingProgram TrainingProgram { get; set; }

        [JsonPropertyName("LMSAssignmentMethod")]
        public LMSAssignmentMethod LMSAssignmentMethod { get; set; }

        [JsonPropertyName("LMSCertificationStatus")]
        public LMSCertificationStatus LMSCertificationStatus { get; set; }

        [JsonPropertyName("EmploymentAgreementType")]
        public EmploymentAgreementType EmploymentAgreementType { get; set; }

        [JsonPropertyName("EmploymentAgreementPopulation")]
        public EmploymentAgreementPopulation EmploymentAgreementPopulation { get; set; }

        [JsonPropertyName("EmploymentAgreementDetails")]
        public EmploymentAgreementDetails EmploymentAgreementDetails { get; set; }

        [JsonPropertyName("EmploymentAgreementTaxRegime")]
        public EmploymentAgreementTaxRegime EmploymentAgreementTaxRegime { get; set; }

        [JsonPropertyName("EmploymentAgreementDuration")]
        public EmploymentAgreementDuration EmploymentAgreementDuration { get; set; }

        [JsonPropertyName("EmploymentAgreementSettlement")]
        public EmploymentAgreementSettlement EmploymentAgreementSettlement { get; set; }

        [JsonPropertyName("GovernmentIdentifier")]
        public string GovernmentIdentifier { get; set; }

        [JsonPropertyName("AgreementReason")]
        public AgreementReason AgreementReason { get; set; }

        [JsonPropertyName("AgreementEndReason")]
        public AgreementEndReason AgreementEndReason { get; set; }

        [JsonPropertyName("Country")]
        public Country Country { get; set; }

        [JsonPropertyName("SignOff")]
        public bool SignOff { get; set; }

        [JsonPropertyName("SignOffDate")]
        public DateTime? SignOffDate { get; set; }

        [JsonPropertyName("HRPolicy")]
        public HRPolicy HRPolicy { get; set; }

        [JsonPropertyName("AuthorityType")]
        public AuthorityType AuthorityType { get; set; }

        [JsonPropertyName("AuthorizedPersonnelFirstName")]
        public string AuthorizedPersonnelFirstName { get; set; }

        [JsonPropertyName("AuthorizedPersonnelLastName")]
        public string AuthorizedPersonnelLastName { get; set; }

        [JsonPropertyName("AuthorizedPersonnelMiddleName")]
        public string AuthorizedPersonnelMiddleName { get; set; }

        [JsonPropertyName("AuthorizedPersonnelXrefCode")]
        public string AuthorizedPersonnelXrefCode { get; set; }

        [JsonPropertyName("State")]
        public State State { get; set; }

        [JsonPropertyName("AssignedSexCountryAware")]
        public AssignedSexCountryAware AssignedSexCountryAware { get; set; }

        [JsonPropertyName("GenderIdentityCountryAware")]
        public GenderIdentityCountryAware GenderIdentityCountryAware { get; set; }

        [JsonPropertyName("OnboardingPolicy")]
        public OnboardingPolicy OnboardingPolicy { get; set; }

        [JsonPropertyName("IsInternalHire")]
        public bool IsInternalHire { get; set; }

        [JsonPropertyName("PayGroup")]
        public PayGroup PayGroup { get; set; }

        [JsonPropertyName("PayPeriodStartDate")]
        public DateTime? PayPeriodStartDate { get; set; }

        [JsonPropertyName("PayPeriodEndDate")]
        public DateTime? PayPeriodEndDate { get; set; }

        [JsonPropertyName("OffsetPayPeriodStartDate")]
        public DateTime? OffsetPayPeriodStartDate { get; set; }

        [JsonPropertyName("OffsetPayPeriodEndDate")]
        public DateTime? OffsetPayPeriodEndDate { get; set; }

        [JsonPropertyName("ContinuePaymentOnStatutoryPay")]
        public bool ContinuePaymentOnStatutoryPay { get; set; }

        [JsonPropertyName("IsOptOut")]
        public int IsOptOut { get; set; }

        [JsonPropertyName("Earning")]
        public Earning Earning { get; set; }

        [JsonPropertyName("ElectionSchedule")]
        public ElectionSchedule ElectionSchedule { get; set; }

        [JsonPropertyName("ElectionStartPayGroup")]
        public ElectionStartPayGroup ElectionStartPayGroup { get; set; }

        [JsonPropertyName("ElectionStartPayPeriodStartDate")]
        public DateTime? ElectionStartPayPeriodStartDate { get; set; }

        [JsonPropertyName("IsBlocked")]
        public bool IsBlocked { get; set; }

        [JsonPropertyName("LimitAmount")]
        public decimal LimitAmount { get; set; }

        [JsonPropertyName("LimitPercent")]
        public decimal LimitPercent { get; set; }

        [JsonPropertyName("EmployeeEarningParameters")]
        public EmployeeEarningParameters EmployeeEarningParameters { get; set; }

        [JsonPropertyName("EmployeeEarningLimits")]
        public EmployeeEarningLimits EmployeeEarningLimits { get; set; }

        [JsonPropertyName("EarningParameter")]
        public EarningParameter EarningParameter { get; set; }

        [JsonPropertyName("Value")]
        public decimal Value { get; set; }

        [JsonPropertyName("PayGroupValue")]
        public decimal PayGroupValue { get; set; }

        [JsonPropertyName("EarningLimit")]
        public EarningLimit EarningLimit { get; set; }

        [JsonPropertyName("PayGroupLimitAmount")]
        public decimal PayGroupLimitAmount { get; set; }

        [JsonPropertyName("PayGroupLimitPercent")]
        public decimal PayGroupLimitPercent { get; set; }

        [JsonPropertyName("Deduction")]
        public Deduction Deduction { get; set; }

        [JsonPropertyName("EmployeeDeductionParameters")]
        public EmployeeDeductionParameters EmployeeDeductionParameters { get; set; }

        [JsonPropertyName("EmployeeDeductionLimits")]
        public EmployeeDeductionLimits EmployeeDeductionLimits { get; set; }

        [JsonPropertyName("DeductionParameter")]
        public DeductionParameter DeductionParameter { get; set; }

        [JsonPropertyName("DeductionLimit")]
        public DeductionLimit DeductionLimit { get; set; }

        [JsonPropertyName("ManagerFirstName")]
        public string ManagerFirstName { get; set; }

        [JsonPropertyName("ManagerMiddleName")]
        public string ManagerMiddleName { get; set; }

        [JsonPropertyName("ManagerLastName")]
        public string ManagerLastName { get; set; }

        [JsonPropertyName("ManagerBadgeNumber")]
        public string ManagerBadgeNumber { get; set; }

        [JsonPropertyName("Contacts")]
        public Contacts Contacts { get; set; }

        [JsonPropertyName("DerivationMethod")]
        public int DerivationMethod { get; set; }

        [JsonPropertyName("PersonContactId")]
        public int PersonContactId { get; set; }

        [JsonPropertyName("ContactInformationType")]
        public ContactInformationType ContactInformationType { get; set; }

        [JsonPropertyName("ContactNumber")]
        public string ContactNumber { get; set; }

        [JsonPropertyName("ElectronicAddress")]
        public string ElectronicAddress { get; set; }

        [JsonPropertyName("Extension")]
        public string Extension { get; set; }

        [JsonPropertyName("IsForSystemCommunications")]
        public bool IsForSystemCommunications { get; set; }

        [JsonPropertyName("IsPreferredContactMethod")]
        public bool IsPreferredContactMethod { get; set; }

        [JsonPropertyName("IsUnlistedNumber")]
        public bool IsUnlistedNumber { get; set; }

        [JsonPropertyName("FormattedNumber")]
        public string FormattedNumber { get; set; }

        [JsonPropertyName("IsVerified")]
        public bool IsVerified { get; set; }

        [JsonPropertyName("IsRejected")]
        public bool IsRejected { get; set; }

        [JsonPropertyName("ShowRejectedWarning")]
        public bool ShowRejectedWarning { get; set; }

        [JsonPropertyName("NumberOfVerificationRequests")]
        public int NumberOfVerificationRequests { get; set; }

        [JsonPropertyName("VacBidGroup")]
        public VacBidGroup VacBidGroup { get; set; }

        [JsonPropertyName("FirstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("MiddleName")]
        public string MiddleName { get; set; }

        [JsonPropertyName("LastName")]
        public string LastName { get; set; }

        [JsonPropertyName("BirthDate")]
        public DateTime? BirthDate { get; set; }

        [JsonPropertyName("SocialSecurityNumber")]
        public string SocialSecurityNumber { get; set; }

        [JsonPropertyName("SSNExpiryDate")]
        public DateTime? SSNExpiryDate { get; set; }

        [JsonPropertyName("TobaccoUser")]
        public string TobaccoUser { get; set; }

        [JsonPropertyName("DateLastSmoked")]
        public DateTime? DateLastSmoked { get; set; }

        [JsonPropertyName("IsStudent")]
        public bool IsStudent { get; set; }

        [JsonPropertyName("IsDisabled")]
        public bool IsDisabled { get; set; }

        [JsonPropertyName("SocialSecurityDisabilityAwardDate")]
        public DateTime? SocialSecurityDisabilityAwardDate { get; set; }

        [JsonPropertyName("Gender")]
        public string Gender { get; set; }

        [JsonPropertyName("IsBeneficiary")]
        public bool IsBeneficiary { get; set; }

        [JsonPropertyName("IsDependent")]
        public bool IsDependent { get; set; }

        [JsonPropertyName("IsActiveDependent")]
        public bool IsActiveDependent { get; set; }

        [JsonPropertyName("IsActiveBeneficiary")]
        public bool IsActiveBeneficiary { get; set; }

        [JsonPropertyName("Relationship")]
        public Relationship Relationship { get; set; }

        [JsonPropertyName("MaritalStatus")]
        public MaritalStatus MaritalStatus { get; set; }

        [JsonPropertyName("Addresses")]
        public Addresses Addresses { get; set; }

        [JsonPropertyName("County")]
        public string County { get; set; }

        [JsonPropertyName("Address1")]
        public string Address1 { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("Address3")]
        public string Address3 { get; set; }

        [JsonPropertyName("Address4")]
        public string Address4 { get; set; }

        [JsonPropertyName("Address5")]
        public string Address5 { get; set; }

        [JsonPropertyName("Address6")]
        public string Address6 { get; set; }

        [JsonPropertyName("City")]
        public string City { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("TaxCode")]
        public string TaxCode { get; set; }

        [JsonPropertyName("TaxBasis")]
        public bool TaxBasis { get; set; }

        [JsonPropertyName("PreviousTaxableGrossPaidToDate")]
        public int PreviousTaxableGrossPaidToDate { get; set; }

        [JsonPropertyName("PreviousTaxPaidToDate")]
        public int PreviousTaxPaidToDate { get; set; }

        [JsonPropertyName("StarterDeclaration")]
        public string StarterDeclaration { get; set; }

        [JsonPropertyName("PreviouslyReportedOnFPS")]
        public bool PreviouslyReportedOnFPS { get; set; }

        [JsonPropertyName("ChangeReasonXrefCode")]
        public string ChangeReasonXrefCode { get; set; }

        [JsonPropertyName("LegalEntityXrefCode")]
        public string LegalEntityXrefCode { get; set; }

        [JsonPropertyName("StudentLoanPlanType")]
        public int StudentLoanPlanType { get; set; }

        [JsonPropertyName("IrregularPayments")]
        public bool IrregularPayments { get; set; }

        [JsonPropertyName("NILetterXrefCode")]
        public string NILetterXrefCode { get; set; }

        [JsonPropertyName("DirectorStartDate")]
        public DateTime? DirectorStartDate { get; set; }

        [JsonPropertyName("IsDirector")]
        public bool IsDirector { get; set; }

        [JsonPropertyName("Annual")]
        public bool Annual { get; set; }

        [JsonPropertyName("MembershipNumber")]
        public string MembershipNumber { get; set; }

        [JsonPropertyName("SuperannuationContributionCalcValue")]
        public int SuperannuationContributionCalcValue { get; set; }

        [JsonPropertyName("PayrollPayee")]
        public PayrollPayee PayrollPayee { get; set; }

        [JsonPropertyName("PayrollDeduction")]
        public PayrollDeduction PayrollDeduction { get; set; }

        [JsonPropertyName("SuperannuationContributionType")]
        public SuperannuationContributionType SuperannuationContributionType { get; set; }

        [JsonPropertyName("SuperannuationType")]
        public SuperannuationType SuperannuationType { get; set; }

        [JsonPropertyName("SuperannuationContributionCalculationType")]
        public SuperannuationContributionCalculationType SuperannuationContributionCalculationType { get; set; }

        [JsonPropertyName("ApplyQuarterlyMaxBaseCapForEmployerSuperannuation")]
        public bool ApplyQuarterlyMaxBaseCapForEmployerSuperannuation { get; set; }

        [JsonPropertyName("OverrideMinBaseForEmployerSuperannuation")]
        public bool OverrideMinBaseForEmployerSuperannuation { get; set; }

        [JsonPropertyName("MinimumContributionAmount")]
        public decimal MinimumContributionAmount { get; set; }

        [JsonPropertyName("EmployeeShortTimeWorkId")]
        public int EmployeeShortTimeWorkId { get; set; }

        [JsonPropertyName("ContributionReductionStart")]
        public DateTime? ContributionReductionStart { get; set; }

        [JsonPropertyName("ContributionReductionEnd")]
        public DateTime? ContributionReductionEnd { get; set; }

        [JsonPropertyName("EmploymentChangeDate")]
        public DateTime? EmploymentChangeDate { get; set; }

        [JsonPropertyName("IncreasedRate")]
        public bool IncreasedRate { get; set; }

        [JsonPropertyName("Consent")]
        public bool Consent { get; set; }

        [JsonPropertyName("DEUSTWParticipationReason")]
        public DEUSTWParticipationReason DEUSTWParticipationReason { get; set; }

        [JsonPropertyName("LegalEntityDEUShortTimeWork")]
        public LegalEntityDEUShortTimeWork LegalEntityDEUShortTimeWork { get; set; }

        [JsonPropertyName("PublicHealthInsuranceXrefCode")]
        public string PublicHealthInsuranceXrefCode { get; set; }

        [JsonPropertyName("LevyHealthInsuranceProviderXrefCode")]
        public string LevyHealthInsuranceProviderXrefCode { get; set; }

        [JsonPropertyName("HighestSchoolEducationXrefCode")]
        public string HighestSchoolEducationXrefCode { get; set; }

        [JsonPropertyName("HighestProfessionalEducationXrefCode")]
        public string HighestProfessionalEducationXrefCode { get; set; }

        [JsonPropertyName("RelationToEmployerXrefCode")]
        public string RelationToEmployerXrefCode { get; set; }

        [JsonPropertyName("IsContractor")]
        public bool IsContractor { get; set; }

        [JsonPropertyName("MainlySelfEmployed")]
        public bool MainlySelfEmployed { get; set; }

        [JsonPropertyName("PensionTypeXrefCode")]
        public string PensionTypeXrefCode { get; set; }

        [JsonPropertyName("PensionStartDate")]
        public DateTime? PensionStartDate { get; set; }

        [JsonPropertyName("ExemptFromPensionInsurance")]
        public bool ExemptFromPensionInsurance { get; set; }

        [JsonPropertyName("ExemptionFormSubmissionDate")]
        public DateTime? ExemptionFormSubmissionDate { get; set; }

        [JsonPropertyName("WaivePensionInsuranceExemption")]
        public bool WaivePensionInsuranceExemption { get; set; }

        [JsonPropertyName("WaiverFormSubmissionDate")]
        public DateTime? WaiverFormSubmissionDate { get; set; }

        [JsonPropertyName("IsParentLegalGuardian")]
        public bool IsParentLegalGuardian { get; set; }

        [JsonPropertyName("NumberOfEntitledChildren")]
        public string NumberOfEntitledChildren { get; set; }

        [JsonPropertyName("ContractTypeXrefCode")]
        public string ContractTypeXrefCode { get; set; }

        [JsonPropertyName("LevyXrefCode")]
        public string LevyXrefCode { get; set; }

        [JsonPropertyName("IsMidijob")]
        public bool IsMidijob { get; set; }

        [JsonPropertyName("IsSeasonalEmployee")]
        public bool IsSeasonalEmployee { get; set; }

        [JsonPropertyName("EmployeeGroupXrefCode")]
        public string EmployeeGroupXrefCode { get; set; }

        [JsonPropertyName("HealthInsuranceXrefCode")]
        public string HealthInsuranceXrefCode { get; set; }

        [JsonPropertyName("PensionInsuranceXrefCode")]
        public string PensionInsuranceXrefCode { get; set; }

        [JsonPropertyName("UnemploymentInsuranceXrefCode")]
        public string UnemploymentInsuranceXrefCode { get; set; }

        [JsonPropertyName("CareInsuranceXrefCode")]
        public string CareInsuranceXrefCode { get; set; }

        [JsonPropertyName("CalculationBasisXrefCode")]
        public string CalculationBasisXrefCode { get; set; }

        [JsonPropertyName("EntitledToSickBenefit")]
        public bool EntitledToSickBenefit { get; set; }

        [JsonPropertyName("EmployeeOccupationalPension")]
        public EmployeeOccupationalPension EmployeeOccupationalPension { get; set; }

        [JsonPropertyName("EmployeePrivateHealthInsurance")]
        public EmployeePrivateHealthInsurance EmployeePrivateHealthInsurance { get; set; }

        [JsonPropertyName("MainEmploymentWithMultipleMiniJobs")]
        public bool MainEmploymentWithMultipleMiniJobs { get; set; }

        [JsonPropertyName("AgriTotalContributionHealth")]
        public decimal AgriTotalContributionHealth { get; set; }

        [JsonPropertyName("AgriTotalContributionRate")]
        public decimal AgriTotalContributionRate { get; set; }

        [JsonPropertyName("AdjustmentAllowanceForMiningWorkersPriorToPension")]
        public bool AdjustmentAllowanceForMiningWorkersPriorToPension { get; set; }

        [JsonPropertyName("BUFDI")]
        public bool BUFDI { get; set; }

        [JsonPropertyName("HealthInsuranceProviderXrefCode")]
        public string HealthInsuranceProviderXrefCode { get; set; }

        [JsonPropertyName("HealthInsuranceTypeXrefCode")]
        public string HealthInsuranceTypeXrefCode { get; set; }

        [JsonPropertyName("DisregardLowerMiniJobThreshold")]
        public bool DisregardLowerMiniJobThreshold { get; set; }

        [JsonPropertyName("PIN")]
        public int PIN { get; set; }

        [JsonPropertyName("IsExempt")]
        public bool IsExempt { get; set; }

        [JsonPropertyName("AccidentInsuranceHazardCategory")]
        public AccidentInsuranceHazardCategory AccidentInsuranceHazardCategory { get; set; }

        [JsonPropertyName("PRDEUAccidentInsuranceProvider_BBNR_UV")]
        public string PRDEUAccidentInsuranceProviderBBNRUV { get; set; }

        [JsonPropertyName("CategoryNumber")]
        public string CategoryNumber { get; set; }

        [JsonPropertyName("Percentage")]
        public decimal Percentage { get; set; }

        [JsonPropertyName("ReferenceDate")]
        public DateTime? ReferenceDate { get; set; }

        [JsonPropertyName("EmploymentTypeCodeName")]
        public string EmploymentTypeCodeName { get; set; }

        [JsonPropertyName("ElectronicDataTransfer")]
        public bool ElectronicDataTransfer { get; set; }

        [JsonPropertyName("TaxClass")]
        public string TaxClass { get; set; }

        [JsonPropertyName("Factor")]
        public decimal Factor { get; set; }

        [JsonPropertyName("ChildAllowance")]
        public decimal ChildAllowance { get; set; }

        [JsonPropertyName("DenominationCodeName")]
        public string DenominationCodeName { get; set; }

        [JsonPropertyName("TaxExemption")]
        public bool TaxExemption { get; set; }

        [JsonPropertyName("RequestedAnnualAllowance")]
        public decimal RequestedAnnualAllowance { get; set; }

        [JsonPropertyName("AnnualAllowance")]
        public decimal AnnualAllowance { get; set; }

        [JsonPropertyName("MonthlyAllowance")]
        public decimal MonthlyAllowance { get; set; }

        [JsonPropertyName("SpouseDenominationCodeName")]
        public string SpouseDenominationCodeName { get; set; }

        [JsonPropertyName("OptOutYearEndWageTaxAdjustment")]
        public bool OptOutYearEndWageTaxAdjustment { get; set; }

        [JsonPropertyName("IsManualInput")]
        public bool IsManualInput { get; set; }

        [JsonPropertyName("PersonAddressId")]
        public int PersonAddressId { get; set; }

        [JsonPropertyName("IsPayrollMailing")]
        public bool IsPayrollMailing { get; set; }

        [JsonPropertyName("DisplayOnTaxForm")]
        public bool DisplayOnTaxForm { get; set; }

        [JsonPropertyName("DisplayOnEarningStatement")]
        public bool DisplayOnEarningStatement { get; set; }

        [JsonPropertyName("IsDefault")]
        public bool IsDefault { get; set; }

        [JsonPropertyName("Role")]
        public Role Role { get; set; }

        [JsonPropertyName("IsPrestartRole")]
        public bool IsPrestartRole { get; set; }

        [JsonPropertyName("EmployeeNumber")]
        public string EmployeeNumber { get; set; }

        [JsonPropertyName("PayGrade")]
        public PayGrade PayGrade { get; set; }

        [JsonPropertyName("PayType")]
        public PayType PayType { get; set; }

        [JsonPropertyName("PayClass")]
        public PayClass PayClass { get; set; }

        [JsonPropertyName("AlternateRate")]
        public decimal AlternateRate { get; set; }

        [JsonPropertyName("AverageDailyHours")]
        public decimal AverageDailyHours { get; set; }

        [JsonPropertyName("AverageOvertimeRate")]
        public decimal AverageOvertimeRate { get; set; }

        [JsonPropertyName("BaseRate")]
        public decimal BaseRate { get; set; }

        [JsonPropertyName("BaseRateManuallySet")]
        public bool BaseRateManuallySet { get; set; }

        [JsonPropertyName("BaseSalary")]
        public decimal BaseSalary { get; set; }

        [JsonPropertyName("DailyRate")]
        public decimal DailyRate { get; set; }

        [JsonPropertyName("NormalWeeklyHours")]
        public decimal NormalWeeklyHours { get; set; }

        [JsonPropertyName("NormalSemiMonthlyHoursTop")]
        public decimal NormalSemiMonthlyHoursTop { get; set; }

        [JsonPropertyName("NormalSemiMonthlyHoursBottom")]
        public decimal NormalSemiMonthlyHoursBottom { get; set; }

        [JsonPropertyName("LastPayEditDate")]
        public DateTime? LastPayEditDate { get; set; }

        [JsonPropertyName("VacationRate")]
        public decimal VacationRate { get; set; }

        [JsonPropertyName("MinimumRate")]
        public decimal MinimumRate { get; set; }

        [JsonPropertyName("ControlRate")]
        public decimal ControlRate { get; set; }

        [JsonPropertyName("MaximumRate")]
        public decimal MaximumRate { get; set; }

        [JsonPropertyName("RateMidPoint")]
        public decimal RateMidPoint { get; set; }

        [JsonPropertyName("MinimumSalary")]
        public decimal MinimumSalary { get; set; }

        [JsonPropertyName("ControlSalary")]
        public decimal ControlSalary { get; set; }

        [JsonPropertyName("MaximumSalary")]
        public decimal MaximumSalary { get; set; }

        [JsonPropertyName("SalaryMidPoint")]
        public decimal SalaryMidPoint { get; set; }

        [JsonPropertyName("CompRatio")]
        public decimal CompRatio { get; set; }

        [JsonPropertyName("ChangePercent")]
        public decimal ChangePercent { get; set; }

        [JsonPropertyName("ChangeValue")]
        public decimal ChangeValue { get; set; }

        [JsonPropertyName("PreviousBaseSalary")]
        public decimal PreviousBaseSalary { get; set; }

        [JsonPropertyName("PreviousBaseRate")]
        public decimal PreviousBaseRate { get; set; }

        [JsonPropertyName("PayPolicy")]
        public PayPolicy PayPolicy { get; set; }

        [JsonPropertyName("RatePolicy")]
        public RatePolicy RatePolicy { get; set; }

        [JsonPropertyName("LoginName")]
        public string LoginName { get; set; }

        [JsonPropertyName("EmployeeLocationAuthorities")]
        public EmployeeLocationAuthorities EmployeeLocationAuthorities { get; set; }

        [JsonPropertyName("Religion")]
        public Religion Religion { get; set; }

        [JsonPropertyName("CompletionDate")]
        public DateTime? CompletionDate { get; set; }

        [JsonPropertyName("CertificationExpiryDate")]
        public DateTime? CertificationExpiryDate { get; set; }

        [JsonPropertyName("EmployeeTrainingProgram")]
        public EmployeeTrainingProgram EmployeeTrainingProgram { get; set; }

        [JsonPropertyName("Comment")]
        public string Comment { get; set; }

        [JsonPropertyName("Score")]
        public string Score { get; set; }

        [JsonPropertyName("PassFail")]
        public string PassFail { get; set; }

        [JsonPropertyName("Credits")]
        public string Credits { get; set; }

        [JsonPropertyName("Cost")]
        public decimal Cost { get; set; }

        [JsonPropertyName("CostCurrencyCode")]
        public string CostCurrencyCode { get; set; }

        [JsonPropertyName("EnrollmentStatus")]
        public EnrollmentStatus EnrollmentStatus { get; set; }

        [JsonPropertyName("TimeSpent")]
        public int TimeSpent { get; set; }

        [JsonPropertyName("VolunteerList")]
        public VolunteerList VolunteerList { get; set; }

        [JsonPropertyName("EmployeeComplainantXRefCode")]
        public string EmployeeComplainantXRefCode { get; set; }

        [JsonPropertyName("HRIncidentNotes")]
        public HRIncidentNotes HRIncidentNotes { get; set; }

        [JsonPropertyName("OrgUnit")]
        public OrgUnit OrgUnit { get; set; }

        [JsonPropertyName("HRIncidentState")]
        public string HRIncidentState { get; set; }

        [JsonPropertyName("OpenDate")]
        public DateTime? OpenDate { get; set; }

        [JsonPropertyName("HRIncidentAction")]
        public HRIncidentAction HRIncidentAction { get; set; }

        [JsonPropertyName("AssignedToUserXRefCode")]
        public string AssignedToUserXRefCode { get; set; }

        [JsonPropertyName("HRIncidentType")]
        public HRIncidentType HRIncidentType { get; set; }

        [JsonPropertyName("ClosedDate")]
        public DateTime? ClosedDate { get; set; }

        [JsonPropertyName("HRIncidentDate")]
        public DateTime? HRIncidentDate { get; set; }

        [JsonPropertyName("HRIncidentBeganWork")]
        public DateTime? HRIncidentBeganWork { get; set; }

        [JsonPropertyName("HRIncidentEventTime")]
        public DateTime? HRIncidentEventTime { get; set; }

        [JsonPropertyName("SafetyHealthType")]
        public SafetyHealthType SafetyHealthType { get; set; }

        [JsonPropertyName("HRIncidentInjury")]
        public HRIncidentInjury HRIncidentInjury { get; set; }

        [JsonPropertyName("HRIncidentBodyPart")]
        public HRIncidentBodyPart HRIncidentBodyPart { get; set; }

        [JsonPropertyName("Died")]
        public bool Died { get; set; }

        [JsonPropertyName("HRIncidentArea")]
        public string HRIncidentArea { get; set; }

        [JsonPropertyName("TaskBeingPerformed")]
        public string TaskBeingPerformed { get; set; }

        [JsonPropertyName("CausedObject")]
        public string CausedObject { get; set; }

        [JsonPropertyName("CausedAction")]
        public string CausedAction { get; set; }

        [JsonPropertyName("PrivacyCase")]
        public bool PrivacyCase { get; set; }

        [JsonPropertyName("DoctorName")]
        public string DoctorName { get; set; }

        [JsonPropertyName("EmergencyRoom")]
        public bool EmergencyRoom { get; set; }

        [JsonPropertyName("HospitalOvernight")]
        public bool HospitalOvernight { get; set; }

        [JsonPropertyName("Hospital")]
        public string Hospital { get; set; }

        [JsonPropertyName("HospitalStreet")]
        public string HospitalStreet { get; set; }

        [JsonPropertyName("HospitalCity")]
        public string HospitalCity { get; set; }

        [JsonPropertyName("HospitalStateCode")]
        public string HospitalStateCode { get; set; }

        [JsonPropertyName("HospitalZip")]
        public string HospitalZip { get; set; }

        [JsonPropertyName("DateReturnToWork")]
        public DateTime? DateReturnToWork { get; set; }

        [JsonPropertyName("DaysLost")]
        public decimal DaysLost { get; set; }

        [JsonPropertyName("DaysRestricted")]
        public decimal DaysRestricted { get; set; }

        [JsonPropertyName("DateDied")]
        public DateTime? DateDied { get; set; }

        [JsonPropertyName("QuestionableClaim")]
        public bool QuestionableClaim { get; set; }

        [JsonPropertyName("IsDaysLost")]
        public bool IsDaysLost { get; set; }

        [JsonPropertyName("WCBCaseNumber")]
        public string WCBCaseNumber { get; set; }

        [JsonPropertyName("DateAdded")]
        public DateTime? DateAdded { get; set; }

        [JsonPropertyName("Notes")]
        public string Notes { get; set; }

        [JsonPropertyName("Skill")]
        public Skill Skill { get; set; }

        [JsonPropertyName("SkillLevel")]
        public SkillLevel SkillLevel { get; set; }

        [JsonPropertyName("LastAssignedBy")]
        public string LastAssignedBy { get; set; }

        [JsonPropertyName("EnrollmentDate")]
        public DateTime? EnrollmentDate { get; set; }

        [JsonPropertyName("UnionMembershipDate")]
        public DateTime? UnionMembershipDate { get; set; }

        [JsonPropertyName("Union")]
        public Union Union { get; set; }

        [JsonPropertyName("EmploymentType")]
        public EmploymentType EmploymentType { get; set; }

        [JsonPropertyName("TaxPayerId")]
        public string TaxPayerId { get; set; }

        [JsonPropertyName("DBAName")]
        public string DBAName { get; set; }

        [JsonPropertyName("GamingProfitsDistributions")]
        public bool GamingProfitsDistributions { get; set; }

        [JsonPropertyName("IR35")]
        public bool IR35 { get; set; }

        [JsonPropertyName("PensionType")]
        public PensionType PensionType { get; set; }

        [JsonPropertyName("ContractorTaxFormType")]
        public string ContractorTaxFormType { get; set; }

        [JsonPropertyName("IsHCE")]
        public bool IsHCE { get; set; }

        [JsonPropertyName("WorkAssignmentEffectiveStart")]
        public DateTime? WorkAssignmentEffectiveStart { get; set; }

        [JsonPropertyName("WorkAssignmentEffectiveEnd")]
        public DateTime? WorkAssignmentEffectiveEnd { get; set; }

        [JsonPropertyName("AccountNumber")]
        public string AccountNumber { get; set; }

        [JsonPropertyName("BankName")]
        public string BankName { get; set; }

        [JsonPropertyName("BankNumber")]
        public string BankNumber { get; set; }

        [JsonPropertyName("BuildingSocietyNumber")]
        public string BuildingSocietyNumber { get; set; }

        [JsonPropertyName("DepositNumber")]
        public decimal DepositNumber { get; set; }

        [JsonPropertyName("DepositValue")]
        public decimal DepositValue { get; set; }

        [JsonPropertyName("PayMethod")]
        public PayMethod PayMethod { get; set; }

        [JsonPropertyName("IsDeleted")]
        public bool IsDeleted { get; set; }

        [JsonPropertyName("IsPercentage")]
        public bool IsPercentage { get; set; }

        [JsonPropertyName("IsRemainder")]
        public bool IsRemainder { get; set; }

        [JsonPropertyName("IsSpecialDisbursementAccount")]
        public bool IsSpecialDisbursementAccount { get; set; }

        [JsonPropertyName("IsMultiSourceAccount")]
        public bool IsMultiSourceAccount { get; set; }

        [JsonPropertyName("IsAccountVerified")]
        public int IsAccountVerified { get; set; }

        [JsonPropertyName("IsBankNameOverride")]
        public bool IsBankNameOverride { get; set; }

        [JsonPropertyName("NumberOfPreNoteDays")]
        public decimal NumberOfPreNoteDays { get; set; }

        [JsonPropertyName("PrenoteFileRunPayDate")]
        public DateTime? PrenoteFileRunPayDate { get; set; }

        [JsonPropertyName("PrenoteFileSentOn")]
        public DateTime? PrenoteFileSentOn { get; set; }

        [JsonPropertyName("RequiresPreNote")]
        public bool RequiresPreNote { get; set; }

        [JsonPropertyName("RoutingTransitNumber")]
        public string RoutingTransitNumber { get; set; }

        [JsonPropertyName("PayCardType")]
        public string PayCardType { get; set; }

        [JsonPropertyName("FinancialInstitution")]
        public FinancialInstitution FinancialInstitution { get; set; }

        [JsonPropertyName("AccountHolder")]
        public string AccountHolder { get; set; }

        [JsonPropertyName("ExclusionOrder")]
        public bool ExclusionOrder { get; set; }

        [JsonPropertyName("PRSIClassXrefCode")]
        public string PRSIClassXrefCode { get; set; }

        [JsonPropertyName("CommunityEmployment")]
        public bool CommunityEmployment { get; set; }

        [JsonPropertyName("PRSIExempt")]
        public bool PRSIExempt { get; set; }

        [JsonPropertyName("PRSIExemptReasonXrefCode")]
        public string PRSIExemptReasonXrefCode { get; set; }

        [JsonPropertyName("PrsiClass")]
        public PrsiClass PrsiClass { get; set; }

        [JsonPropertyName("PrsiExemptReason")]
        public PrsiExemptReason PrsiExemptReason { get; set; }

        [JsonPropertyName("CompanyDirector")]
        public string CompanyDirector { get; set; }

        [JsonPropertyName("EmploymentCessationDate")]
        public DateTime? EmploymentCessationDate { get; set; }

        [JsonPropertyName("InReceiptOfSpc")]
        public bool InReceiptOfSpc { get; set; }

        [JsonPropertyName("TaxYear")]
        public int TaxYear { get; set; }

        [JsonPropertyName("RpnNumber")]
        public string RpnNumber { get; set; }

        [JsonPropertyName("EmployeePpsn")]
        public string EmployeePpsn { get; set; }

        [JsonPropertyName("EmploymentID")]
        public string EmploymentID { get; set; }

        [JsonPropertyName("RpnIssueDate")]
        public DateTime? RpnIssueDate { get; set; }

        [JsonPropertyName("EmployerReference")]
        public string EmployerReference { get; set; }

        [JsonPropertyName("FamilyName")]
        public string FamilyName { get; set; }

        [JsonPropertyName("PreviousEmployeePPSN")]
        public string PreviousEmployeePPSN { get; set; }

        [JsonPropertyName("IncomeTaxCalculationBasis")]
        public string IncomeTaxCalculationBasis { get; set; }

        [JsonPropertyName("YearlyTaxCredits")]
        public decimal YearlyTaxCredits { get; set; }

        [JsonPropertyName("PayForIncomeTaxToDate")]
        public decimal PayForIncomeTaxToDate { get; set; }

        [JsonPropertyName("IncomeTaxDeductedToDate")]
        public decimal IncomeTaxDeductedToDate { get; set; }

        [JsonPropertyName("UscStatus")]
        public string UscStatus { get; set; }

        [JsonPropertyName("PayForUSCToDate")]
        public decimal PayForUSCToDate { get; set; }

        [JsonPropertyName("UscDeductedToDate")]
        public decimal UscDeductedToDate { get; set; }

        [JsonPropertyName("LptToDeduct")]
        public decimal LptToDeduct { get; set; }

        [JsonPropertyName("TaxRatePercent1")]
        public decimal TaxRatePercent1 { get; set; }

        [JsonPropertyName("YearlyRateCutOff1")]
        public decimal YearlyRateCutOff1 { get; set; }

        [JsonPropertyName("TaxRatePercent2")]
        public decimal TaxRatePercent2 { get; set; }

        [JsonPropertyName("UscRatePercent1")]
        public decimal UscRatePercent1 { get; set; }

        [JsonPropertyName("YearlyUSCRateCutOff1")]
        public decimal YearlyUSCRateCutOff1 { get; set; }

        [JsonPropertyName("UscRatePercent2")]
        public decimal UscRatePercent2 { get; set; }

        [JsonPropertyName("YearlyUSCRateCutOff2")]
        public decimal YearlyUSCRateCutOff2 { get; set; }

        [JsonPropertyName("UscRatePercent3")]
        public decimal UscRatePercent3 { get; set; }

        [JsonPropertyName("YearlyUSCRateCutOff3")]
        public decimal YearlyUSCRateCutOff3 { get; set; }

        [JsonPropertyName("UscRatePercent4")]
        public decimal UscRatePercent4 { get; set; }

        [JsonPropertyName("IsEWSSEligible")]
        public bool IsEWSSEligible { get; set; }

        [JsonPropertyName("TotalClaimAmount")]
        public decimal TotalClaimAmount { get; set; }

        [JsonPropertyName("IsNonResident")]
        public bool IsNonResident { get; set; }

        [JsonPropertyName("MultipleEmployer")]
        public bool MultipleEmployer { get; set; }

        [JsonPropertyName("IncomeLessThanClaim")]
        public bool IncomeLessThanClaim { get; set; }

        [JsonPropertyName("DistrictTaxDeduction")]
        public decimal DistrictTaxDeduction { get; set; }

        [JsonPropertyName("AuthorizedTaxCredits")]
        public decimal AuthorizedTaxCredits { get; set; }

        [JsonPropertyName("EstimatedExpense")]
        public decimal EstimatedExpense { get; set; }

        [JsonPropertyName("EstimatedRemuneration")]
        public decimal EstimatedRemuneration { get; set; }

        [JsonPropertyName("AdditionalAmount")]
        public decimal AdditionalAmount { get; set; }

        [JsonPropertyName("PrescribedAreaDeduction")]
        public decimal PrescribedAreaDeduction { get; set; }

        [JsonPropertyName("NonResidentCountry")]
        public NonResidentCountry NonResidentCountry { get; set; }

        [JsonPropertyName("MaintenanceDeduction")]
        public decimal MaintenanceDeduction { get; set; }

        [JsonPropertyName("QuebecDevelopmentFunds")]
        public decimal QuebecDevelopmentFunds { get; set; }

        [JsonPropertyName("LabourSponsoredFunds")]
        public decimal LabourSponsoredFunds { get; set; }

        [JsonPropertyName("HasQuebecHealthContributionExemption")]
        public bool HasQuebecHealthContributionExemption { get; set; }

        [JsonPropertyName("FilingStatus")]
        public FilingStatus FilingStatus { get; set; }

        [JsonPropertyName("Allowances")]
        public decimal Allowances { get; set; }

        [JsonPropertyName("IsTaxExempt")]
        public bool IsTaxExempt { get; set; }

        [JsonPropertyName("IsLocked")]
        public bool IsLocked { get; set; }

        [JsonPropertyName("TwoJobs")]
        public bool TwoJobs { get; set; }

        [JsonPropertyName("DependentTaxCredit")]
        public decimal DependentTaxCredit { get; set; }

        [JsonPropertyName("OtherIncome")]
        public decimal OtherIncome { get; set; }

        [JsonPropertyName("Deductions")]
        public decimal Deductions { get; set; }

        [JsonPropertyName("TotalW2IncomeAndAdditionalPension")]
        public decimal TotalW2IncomeAndAdditionalPension { get; set; }

        [JsonPropertyName("WithholdingPercentage")]
        public decimal WithholdingPercentage { get; set; }

        [JsonPropertyName("STSLDebt")]
        public bool STSLDebt { get; set; }

        [JsonPropertyName("ClaimTaxFreeThreshold")]
        public bool ClaimTaxFreeThreshold { get; set; }

        [JsonPropertyName("AmountClaimedforTaxOffset")]
        public decimal AmountClaimedforTaxOffset { get; set; }

        [JsonPropertyName("MedicareLevyReductionClaimed")]
        public bool MedicareLevyReductionClaimed { get; set; }

        [JsonPropertyName("Spouse")]
        public bool Spouse { get; set; }

        [JsonPropertyName("CombineWeeklyTotalIncomelessthanTableA")]
        public bool CombineWeeklyTotalIncomelessthanTableA { get; set; }

        [JsonPropertyName("NumberofDependentChildren")]
        public decimal NumberofDependentChildren { get; set; }

        [JsonPropertyName("SeniorAndPensionersTaxOffset")]
        public bool SeniorAndPensionersTaxOffset { get; set; }

        [JsonPropertyName("PayBasis")]
        public string PayBasis { get; set; }

        [JsonPropertyName("ClaimingZoneOverseasorCarerOffset")]
        public bool ClaimingZoneOverseasorCarerOffset { get; set; }

        [JsonPropertyName("ApplyMedicareForWorkingHolidayMaker")]
        public bool ApplyMedicareForWorkingHolidayMaker { get; set; }

        [JsonPropertyName("WithholdingVariationAmount")]
        public decimal WithholdingVariationAmount { get; set; }

        [JsonPropertyName("DoesWithholdingVariationIncludeSTSLDebt")]
        public bool DoesWithholdingVariationIncludeSTSLDebt { get; set; }

        [JsonPropertyName("IsUpwardVariation")]
        public bool IsUpwardVariation { get; set; }

        [JsonPropertyName("TFNExemptionReason")]
        public TFNExemptionReason TFNExemptionReason { get; set; }

        [JsonPropertyName("ResidentCode")]
        public ResidentCode ResidentCode { get; set; }

        [JsonPropertyName("MedicareLevyExemptionType")]
        public MedicareLevyExemptionType MedicareLevyExemptionType { get; set; }

        [JsonPropertyName("WithholdingVariationType")]
        public WithholdingVariationType WithholdingVariationType { get; set; }

        [JsonPropertyName("WithholdingVariationAmountType")]
        public WithholdingVariationAmountType WithholdingVariationAmountType { get; set; }

        [JsonPropertyName("EarningGroup")]
        public EarningGroup EarningGroup { get; set; }

        [JsonPropertyName("AdditionalTaxType")]
        public AdditionalTaxType AdditionalTaxType { get; set; }

        [JsonPropertyName("FlatComissionerInstalmentRate")]
        public decimal FlatComissionerInstalmentRate { get; set; }

        [JsonPropertyName("IsContractorSuperLiabilityOnly")]
        public bool IsContractorSuperLiabilityOnly { get; set; }

        [JsonPropertyName("TaxAuthority")]
        public string TaxAuthority { get; set; }

        [JsonPropertyName("TaxType")]
        public string TaxType { get; set; }

        [JsonPropertyName("Name")]
        public Name Name { get; set; }

        [JsonPropertyName("EmployeeTax")]
        public bool EmployeeTax { get; set; }

        [JsonPropertyName("EmployerTax")]
        public bool EmployerTax { get; set; }

        [JsonPropertyName("ManuallyAddedTax")]
        public bool ManuallyAddedTax { get; set; }

        [JsonPropertyName("TaxAuthorityInstance")]
        public string TaxAuthorityInstance { get; set; }

        [JsonPropertyName("ExemptTaxOnlyUpdateWages")]
        public bool ExemptTaxOnlyUpdateWages { get; set; }

        [JsonPropertyName("ExemptTaxAndTaxableWages")]
        public bool ExemptTaxAndTaxableWages { get; set; }

        [JsonPropertyName("InactivateTax")]
        public bool InactivateTax { get; set; }

        [JsonPropertyName("OverrideParameters")]
        public List<OverrideParameter> OverrideParameters { get; set; }

        [JsonPropertyName("StateFilingStatusDisplayName")]
        public string StateFilingStatusDisplayName { get; set; }

        [JsonPropertyName("DependentAllowances")]
        public decimal DependentAllowances { get; set; }

        [JsonPropertyName("PersonalAllowances")]
        public decimal PersonalAllowances { get; set; }

        [JsonPropertyName("AdditionalAllowances")]
        public decimal AdditionalAllowances { get; set; }

        [JsonPropertyName("AlternateCalculationCode")]
        public string AlternateCalculationCode { get; set; }

        [JsonPropertyName("AlternateCalculationCodeDisplayName")]
        public string AlternateCalculationCodeDisplayName { get; set; }

        [JsonPropertyName("ExemptionAmount")]
        public decimal ExemptionAmount { get; set; }

        [JsonPropertyName("AdditionalTaxPercent")]
        public decimal AdditionalTaxPercent { get; set; }

        [JsonPropertyName("AdditionalExemptionAmount")]
        public decimal AdditionalExemptionAmount { get; set; }

        [JsonPropertyName("PRYoungEntrepreneurExemptionOptOut")]
        public bool PRYoungEntrepreneurExemptionOptOut { get; set; }

        [JsonPropertyName("AdoptionDependents")]
        public decimal AdoptionDependents { get; set; }

        [JsonPropertyName("Ethnicity")]
        public Ethnicity Ethnicity { get; set; }

        [JsonPropertyName("ManagerEthnicity")]
        public ManagerEthnicity ManagerEthnicity { get; set; }

        [JsonPropertyName("EvidenceNumber")]
        public string EvidenceNumber { get; set; }

        [JsonPropertyName("DisabilityEvidenceIssuingAgencyLocation")]
        public string DisabilityEvidenceIssuingAgencyLocation { get; set; }

        [JsonPropertyName("ValidFrom")]
        public DateTime? ValidFrom { get; set; }

        [JsonPropertyName("DisabilityEvidenceIssuingAgency")]
        public DisabilityEvidenceIssuingAgency DisabilityEvidenceIssuingAgency { get; set; }

        [JsonPropertyName("DisabilityEvidenceType")]
        public DisabilityEvidenceType DisabilityEvidenceType { get; set; }

        [JsonPropertyName("DisabilityWorkingTime")]
        public DisabilityWorkingTime DisabilityWorkingTime { get; set; }

        [JsonPropertyName("DisabilityGroup")]
        public DisabilityGroup DisabilityGroup { get; set; }

        [JsonPropertyName("IsVevraa")]
        public bool IsVevraa { get; set; }

        [JsonPropertyName("VeteransStatus")]
        public VeteransStatus VeteransStatus { get; set; }

        [JsonPropertyName("EmployeeEmploymentStatusId")]
        public int EmployeeEmploymentStatusId { get; set; }

        [JsonPropertyName("EmploymentStatus")]
        public EmploymentStatus EmploymentStatus { get; set; }

        [JsonPropertyName("EmploymentStatusGroup")]
        public EmploymentStatusGroup EmploymentStatusGroup { get; set; }

        [JsonPropertyName("PayTypeGroup")]
        public PayTypeGroup PayTypeGroup { get; set; }

        [JsonPropertyName("PunchPolicy")]
        public PunchPolicy PunchPolicy { get; set; }

        [JsonPropertyName("PayHolidayGroup")]
        public PayHolidayGroup PayHolidayGroup { get; set; }

        [JsonPropertyName("EmployeeGroup")]
        public EmployeeGroup EmployeeGroup { get; set; }

        [JsonPropertyName("EntitlementPolicy")]
        public EntitlementPolicy EntitlementPolicy { get; set; }

        [JsonPropertyName("ShiftRotation")]
        public ShiftRotation ShiftRotation { get; set; }

        [JsonPropertyName("ShiftRotationDayOffset")]
        public decimal ShiftRotationDayOffset { get; set; }

        [JsonPropertyName("ShiftRotationStartDate")]
        public DateTime? ShiftRotationStartDate { get; set; }

        [JsonPropertyName("CreateShiftRotationShift")]
        public bool CreateShiftRotationShift { get; set; }

        [JsonPropertyName("TimeOffPolicy")]
        public TimeOffPolicy TimeOffPolicy { get; set; }

        [JsonPropertyName("ShiftTradePolicy")]
        public ShiftTradePolicy ShiftTradePolicy { get; set; }

        [JsonPropertyName("AttendancePolicy")]
        public AttendancePolicy AttendancePolicy { get; set; }

        [JsonPropertyName("SchedulePolicy")]
        public SchedulePolicy SchedulePolicy { get; set; }

        [JsonPropertyName("OvertimeGroup")]
        public OvertimeGroup OvertimeGroup { get; set; }

        [JsonPropertyName("PayrollPolicy")]
        public PayrollPolicy PayrollPolicy { get; set; }

        [JsonPropertyName("JobStepPolicy")]
        public JobStepPolicy JobStepPolicy { get; set; }

        [JsonPropertyName("PeriodicSalary")]
        public decimal PeriodicSalary { get; set; }

        [JsonPropertyName("DEUHoursChangeReason")]
        public DEUHoursChangeReason DEUHoursChangeReason { get; set; }

        [JsonPropertyName("ScheduleChangePolicy")]
        public ScheduleChangePolicy ScheduleChangePolicy { get; set; }

        [JsonPropertyName("AuthorizationPolicy")]
        public AuthorizationPolicy AuthorizationPolicy { get; set; }

        [JsonPropertyName("WorkContractPremiumPolicy")]
        public WorkContractPremiumPolicy WorkContractPremiumPolicy { get; set; }

        [JsonPropertyName("TargetBonus")]
        public decimal TargetBonus { get; set; }

        [JsonPropertyName("MonthlyHours")]
        public decimal MonthlyHours { get; set; }

        [JsonPropertyName("OriginalEmploymentStatus")]
        public OriginalEmploymentStatus OriginalEmploymentStatus { get; set; }

        [JsonPropertyName("PRGLSplitSetDetails")]
        public PRGLSplitSetDetails PRGLSplitSetDetails { get; set; }
    }

    public class Job
    {
        [JsonPropertyName("EmployeeEEO")]
        public EmployeeEEO EmployeeEEO { get; set; }

        [JsonPropertyName("IsUnionJob")]
        public bool IsUnionJob { get; set; }

        [JsonPropertyName("JobQualifications")]
        public string JobQualifications { get; set; }

        [JsonPropertyName("JobRank")]
        public decimal JobRank { get; set; }

        [JsonPropertyName("JobSOC")]
        public JobSOC JobSOC { get; set; }

        [JsonPropertyName("JobUDFString1")]
        public string JobUDFString1 { get; set; }

        [JsonPropertyName("JobUDFString2")]
        public string JobUDFString2 { get; set; }

        [JsonPropertyName("JobUDFString3")]
        public string JobUDFString3 { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("NOC")]
        public string NOC { get; set; }

        [JsonPropertyName("JobClassification")]
        public JobClassification JobClassification { get; set; }

        [JsonPropertyName("JobFunction")]
        public JobFunction JobFunction { get; set; }

        [JsonPropertyName("PayGrade")]
        public PayGrade PayGrade { get; set; }

        [JsonPropertyName("Union")]
        public Union Union { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("FLSAStatus")]
        public FLSAStatus FLSAStatus { get; set; }

        [JsonPropertyName("JobFamily")]
        public JobFamily JobFamily { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class JobClassification
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class JobClassificationGlobal
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class JobFamily
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class JobFunction
    {
        [JsonPropertyName("Level")]
        public int Level { get; set; }

        [JsonPropertyName("UsableForExternalPosting")]
        public bool UsableForExternalPosting { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class JobSet
    {
        [JsonPropertyName("Grade")]
        public int Grade { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class JobSetLevel
    {
        [JsonPropertyName("JobSet")]
        public JobSet JobSet { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class JobSOC
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class JobStepPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LaborDefaults
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class LaborMetricsCode
    {
        [JsonPropertyName("LaborMetricsType")]
        public LaborMetricsType LaborMetricsType { get; set; }

        [JsonPropertyName("ClockTransferCode")]
        public string ClockTransferCode { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LaborMetricsType
    {
        [JsonPropertyName("ClockTransferCode")]
        public string ClockTransferCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LastActiveManagers
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class LastNamePrefix
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LastNamePrefixAtBirth
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LegalEntity
    {
        [JsonPropertyName("Country")]
        public Country Country { get; set; }

        [JsonPropertyName("LegalEntityAddress")]
        public LegalEntityAddress LegalEntityAddress { get; set; }

        [JsonPropertyName("LegalIdNumber")]
        public string LegalIdNumber { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LegalEntityAddress
    {
        [JsonPropertyName("Address1")]
        public string Address1 { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("Address3")]
        public string Address3 { get; set; }

        [JsonPropertyName("Address4")]
        public string Address4 { get; set; }

        [JsonPropertyName("Address5")]
        public string Address5 { get; set; }

        [JsonPropertyName("Address6")]
        public string Address6 { get; set; }

        [JsonPropertyName("City")]
        public string City { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("Country")]
        public Country Country { get; set; }

        [JsonPropertyName("State")]
        public State State { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LegalEntityDEUShortTimeWork
    {
        [JsonPropertyName("LegalEntityDEUShortTimeWorkID")]
        public int LegalEntityDEUShortTimeWorkID { get; set; }

        [JsonPropertyName("StoppageNumber")]
        public string StoppageNumber { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LegalEntityWorkSiteState
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LimitAccessType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LimitType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LMSAssignmentMethod
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LMSCertification
    {
        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("ExpirationUnit")]
        public string ExpirationUnit { get; set; }

        [JsonPropertyName("ExpirationValue")]
        public int ExpirationValue { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LMSCertificationStatus
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Location
    {
        [JsonPropertyName("PhysicalLocation")]
        public bool PhysicalLocation { get; set; }

        [JsonPropertyName("BusinessPhone")]
        public string BusinessPhone { get; set; }

        [JsonPropertyName("ContactBusinessPhone")]
        public string ContactBusinessPhone { get; set; }

        [JsonPropertyName("ContactCellPhone")]
        public string ContactCellPhone { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("CountryCode")]
        public string CountryCode { get; set; }

        [JsonPropertyName("OpeningDate")]
        public DateTime? OpeningDate { get; set; }

        [JsonPropertyName("ClosingDate")]
        public DateTime? ClosingDate { get; set; }

        [JsonPropertyName("ComparableLocation")]
        public ComparableLocation ComparableLocation { get; set; }

        [JsonPropertyName("Department")]
        public Department Department { get; set; }

        [JsonPropertyName("Zone")]
        public Zone Zone { get; set; }

        [JsonPropertyName("StartDayOfWeek")]
        public int StartDayOfWeek { get; set; }

        [JsonPropertyName("GeoCity")]
        public GeoCity GeoCity { get; set; }

        [JsonPropertyName("Timezone")]
        public Timezone Timezone { get; set; }

        [JsonPropertyName("County")]
        public string County { get; set; }

        [JsonPropertyName("IsOrgManaged")]
        public bool IsOrgManaged { get; set; }

        [JsonPropertyName("IsMobileOrg")]
        public bool IsMobileOrg { get; set; }

        [JsonPropertyName("PublicName")]
        public string PublicName { get; set; }

        [JsonPropertyName("ClockTransferCode")]
        public string ClockTransferCode { get; set; }

        [JsonPropertyName("ContactEmail")]
        public string ContactEmail { get; set; }

        [JsonPropertyName("ContactName")]
        public string ContactName { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("StateCode")]
        public string StateCode { get; set; }

        [JsonPropertyName("Address")]
        public string Address { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("LegalEntity")]
        public LegalEntity LegalEntity { get; set; }

        [JsonPropertyName("OrgUnitLegalEntities")]
        public OrgUnitLegalEntities OrgUnitLegalEntities { get; set; }

        [JsonPropertyName("OrgUnitParents")]
        public OrgUnitParents OrgUnitParents { get; set; }

        [JsonPropertyName("ChildOrgUnits")]
        public ChildOrgUnits ChildOrgUnits { get; set; }

        [JsonPropertyName("OrgUnitLocationTypes")]
        public OrgUnitLocationTypes OrgUnitLocationTypes { get; set; }

        [JsonPropertyName("OrgLevel")]
        public OrgLevel OrgLevel { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class LocationAddress
    {
        [JsonPropertyName("Address1")]
        public string Address1 { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("State")]
        public State State { get; set; }

        [JsonPropertyName("Country")]
        public Country Country { get; set; }

        [JsonPropertyName("City")]
        public string City { get; set; }

        [JsonPropertyName("County")]
        public string County { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Locations
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class LocationType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ManagedEmployees
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class ManagerEthnicity
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class MaritalStatus
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class MaritalStatuses
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class MedicareLevyExemptionType
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class MUSTaxes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Name
    {
        [JsonPropertyName("TaxName")]
        public string TaxName { get; set; }

        [JsonPropertyName("Description")]
        public string Description { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }

    public class NameAffix
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class NameAffixAtBirth
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class NonResidentCountry
    {
        [JsonPropertyName("Name")]
        public string Name { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class NZLKiwiSaver
    {
    }

    public class OnboardingPolicies
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class OnboardingPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OptionValue
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OrgLevel
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OrgLocationType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OrgUnit
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("Address")]
        public Address Address { get; set; }

        [JsonPropertyName("TaxLocationAddress")]
        public TaxLocationAddress TaxLocationAddress { get; set; }

        [JsonPropertyName("ChildSortOrder")]
        public int ChildSortOrder { get; set; }

        [JsonPropertyName("IsPhysicalLocation")]
        public bool IsPhysicalLocation { get; set; }

        [JsonPropertyName("IsPrimary")]
        public bool IsPrimary { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("ParentSortOrder")]
        public int ParentSortOrder { get; set; }

        [JsonPropertyName("OrgLevel")]
        public OrgLevel OrgLevel { get; set; }

        [JsonPropertyName("Timezone")]
        public Timezone Timezone { get; set; }

        [JsonPropertyName("OrgUnitParent")]
        public OrgUnitParent OrgUnitParent { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OrgUnitDetail
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("Address")]
        public Address Address { get; set; }

        [JsonPropertyName("TaxLocationAddress")]
        public TaxLocationAddress TaxLocationAddress { get; set; }

        [JsonPropertyName("ChildSortOrder")]
        public int ChildSortOrder { get; set; }

        [JsonPropertyName("IsPhysicalLocation")]
        public bool IsPhysicalLocation { get; set; }

        [JsonPropertyName("IsPrimary")]
        public bool IsPrimary { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("ParentSortOrder")]
        public int ParentSortOrder { get; set; }

        [JsonPropertyName("OrgLevel")]
        public OrgLevel OrgLevel { get; set; }

        [JsonPropertyName("Timezone")]
        public Timezone Timezone { get; set; }

        [JsonPropertyName("OrgUnitParent")]
        public OrgUnitParent OrgUnitParent { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OrgUnitInfos
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class OrgUnitLegalEntities
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class OrgUnitLocationTypes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class OrgUnitParent
    {
        [JsonPropertyName("ParentOrgUnit")]
        public ParentOrgUnit ParentOrgUnit { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OrgUnitParents
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class OriginalEmploymentStatus
    {
        [JsonPropertyName("IsBenefitArrearsEnabled")]
        public bool IsBenefitArrearsEnabled { get; set; }

        [JsonPropertyName("EffectiveStartingPointOfDay")]
        public string EffectiveStartingPointOfDay { get; set; }

        [JsonPropertyName("EmploymentStatusGroup")]
        public EmploymentStatusGroup EmploymentStatusGroup { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OverrideCustomerFundingIdentifier
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OverrideParameter
    {
        [JsonPropertyName("Name")]
        public Name Name { get; set; }

        [JsonPropertyName("Value")]
        public string Value { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class OvertimeGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ParameterAccessType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ParentOrgUnit
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class PayAdjCode
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayAdjCodeGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayClass
    {
        [JsonPropertyName("SortOrder")]
        public int SortOrder { get; set; }

        [JsonPropertyName("DefaultNormalWeeklyHours")]
        public int DefaultNormalWeeklyHours { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("PayClassGroup")]
        public PayClassGroup PayClassGroup { get; set; }

        [JsonPropertyName("PayClassFrequency")]
        public PayClassFrequency PayClassFrequency { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayClassFrequency
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayClassGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayFrequency
    {
        [JsonPropertyName("PayFrequencyType")]
        public string PayFrequencyType { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayGrade
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayGradeRates
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class PayGroup
    {
        [JsonPropertyName("PayFrequency")]
        public PayFrequency PayFrequency { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayHolidayGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PaymentMethod
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayMethod
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayPeriodInformation
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class PayPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayrollDeduction
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class PayrollPayee
    {
        [JsonPropertyName("IsActive")]
        public bool IsActive { get; set; }

        [JsonPropertyName("IsDeductionPayee")]
        public bool IsDeductionPayee { get; set; }

        [JsonPropertyName("ABN")]
        public string ABN { get; set; }

        [JsonPropertyName("USI")]
        public string USI { get; set; }

        [JsonPropertyName("ESA")]
        public string ESA { get; set; }

        [JsonPropertyName("AddressLine1")]
        public string AddressLine1 { get; set; }

        [JsonPropertyName("AddressLine2")]
        public string AddressLine2 { get; set; }

        [JsonPropertyName("AddressLine3")]
        public string AddressLine3 { get; set; }

        [JsonPropertyName("City")]
        public string City { get; set; }

        [JsonPropertyName("State")]
        public string State { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("CountryCode")]
        public string CountryCode { get; set; }

        [JsonPropertyName("Category")]
        public Category Category { get; set; }

        [JsonPropertyName("PaymentMethod")]
        public PaymentMethod PaymentMethod { get; set; }

        [JsonPropertyName("AccountNumber")]
        public string AccountNumber { get; set; }

        [JsonPropertyName("BSBCode")]
        public string BSBCode { get; set; }

        [JsonPropertyName("CombineEmployees")]
        public bool CombineEmployees { get; set; }

        [JsonPropertyName("CombineEarningsandDeductions")]
        public bool CombineEarningsandDeductions { get; set; }

        [JsonPropertyName("ShowEmployeeDetails")]
        public bool ShowEmployeeDetails { get; set; }

        [JsonPropertyName("AllowNegativeAmounts")]
        public bool AllowNegativeAmounts { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class PayrollPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayType
    {
        [JsonPropertyName("MaximumRate")]
        public int MaximumRate { get; set; }

        [JsonPropertyName("MaximumSalary")]
        public int MaximumSalary { get; set; }

        [JsonPropertyName("SortOrder")]
        public int SortOrder { get; set; }

        [JsonPropertyName("HidePayOnTimesheet")]
        public bool HidePayOnTimesheet { get; set; }

        [JsonPropertyName("IsPayrollAutoPay")]
        public bool IsPayrollAutoPay { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("PayTypeGroup")]
        public PayTypeGroup PayTypeGroup { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PayTypeGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PensionType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PerformanceCycle
    {
        [JsonPropertyName("CycleStartDate")]
        public DateTime? CycleStartDate { get; set; }

        [JsonPropertyName("CycleEndDate")]
        public DateTime? CycleEndDate { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PerformanceRating
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PerformanceRatings
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class PerformanceRatingScale
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PMPosition
    {
        [JsonPropertyName("PositionGlobalId")]
        public string PositionGlobalId { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("Number")]
        public string Number { get; set; }

        [JsonPropertyName("FTE")]
        public decimal FTE { get; set; }

        [JsonPropertyName("BusinessUnit")]
        public BusinessUnit BusinessUnit { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PMPositionAssignment
    {
        [JsonPropertyName("PositionAssignmentGlobalId")]
        public string PositionAssignmentGlobalId { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("IsPrimary")]
        public bool IsPrimary { get; set; }

        [JsonPropertyName("IsInterim")]
        public bool IsInterim { get; set; }

        [JsonPropertyName("PMPosition")]
        public PMPosition PMPosition { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Position
    {
        [JsonPropertyName("AverageDailyHours")]
        public decimal AverageDailyHours { get; set; }

        [JsonPropertyName("ClockTransferCode")]
        public string ClockTransferCode { get; set; }

        [JsonPropertyName("Department")]
        public Department Department { get; set; }

        [JsonPropertyName("Job")]
        public Job Job { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("EmploymentIndicator")]
        public EmploymentIndicator EmploymentIndicator { get; set; }

        [JsonPropertyName("Executive")]
        public bool Executive { get; set; }

        [JsonPropertyName("FTE")]
        public decimal FTE { get; set; }

        [JsonPropertyName("IsNonService")]
        public bool IsNonService { get; set; }

        [JsonPropertyName("IsWCBExempt")]
        public bool IsWCBExempt { get; set; }

        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("Officer")]
        public bool Officer { get; set; }

        [JsonPropertyName("PayClass")]
        public PayClass PayClass { get; set; }

        [JsonPropertyName("PayGroup")]
        public PayGroup PayGroup { get; set; }

        [JsonPropertyName("PayType")]
        public PayType PayType { get; set; }

        [JsonPropertyName("PositionTerm")]
        public PositionTerm PositionTerm { get; set; }

        [JsonPropertyName("PPACAFullTime")]
        public bool PPACAFullTime { get; set; }

        [JsonPropertyName("SemiMonthlyBottomHours")]
        public decimal SemiMonthlyBottomHours { get; set; }

        [JsonPropertyName("SemiMonthlyTopHours")]
        public decimal SemiMonthlyTopHours { get; set; }

        [JsonPropertyName("StandardCostRate")]
        public decimal StandardCostRate { get; set; }

        [JsonPropertyName("WeeklyHours")]
        public decimal WeeklyHours { get; set; }

        [JsonPropertyName("DefaultTargetBonus")]
        public decimal DefaultTargetBonus { get; set; }

        [JsonPropertyName("PositionAssignments")]
        public PositionAssignments PositionAssignments { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PositionAssignments
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class PositionTerm
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PRBankAccountBranchAddress
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PRGLSplitSetDetailMetricCodes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class PRGLSplitSetDetails
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class ProcessResult
    {
        [JsonPropertyName("Code")]
        public string Code { get; set; }

        [JsonPropertyName("Context")]
        public string Context { get; set; }

        [JsonPropertyName("Level")]
        public string Level { get; set; }

        [JsonPropertyName("Message")]
        public string Message { get; set; }
    }

    public class Project
    {
        [JsonPropertyName("LedgerCode")]
        public string LedgerCode { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PrsiClass
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PrsiExemptReason
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class PunchPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class RatePolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Relationship
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Religion
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Religions
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class ResidentCode
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class Reviewer
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("NewXRefCode")]
        public string NewXRefCode { get; set; }

        [JsonPropertyName("CommonName")]
        public string CommonName { get; set; }

        [JsonPropertyName("DisplayName")]
        public string DisplayName { get; set; }

        [JsonPropertyName("FirstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("LastName")]
        public string LastName { get; set; }

        [JsonPropertyName("Initials")]
        public string Initials { get; set; }

        [JsonPropertyName("MaidenName")]
        public string MaidenName { get; set; }

        [JsonPropertyName("MiddleName")]
        public string MiddleName { get; set; }

        [JsonPropertyName("PreferredLastName")]
        public string PreferredLastName { get; set; }

        [JsonPropertyName("SecondLastName")]
        public string SecondLastName { get; set; }

        [JsonPropertyName("Suffix")]
        public string Suffix { get; set; }

        [JsonPropertyName("Title")]
        public string Title { get; set; }

        [JsonPropertyName("PreviousLastName")]
        public string PreviousLastName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Role
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Roles
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

   

    public class SafetyHealthType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ScheduleChangePolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class SchedulePolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class SchoolYear
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ShiftRotation
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ShiftTradePolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class ShiftType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Skill
    {
        [JsonPropertyName("SkillType")]
        public SkillType SkillType { get; set; }

        [JsonPropertyName("SkillLevel")]
        public List<SkillLevel> SkillLevel { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class SkillLevel
    {
        [JsonPropertyName("RankOrder")]
        public int RankOrder { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Skills
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class SkillType
    {
        [JsonPropertyName("IsWFM")]
        public bool IsWFM { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class SSOAccounts
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class State
    {
        [JsonPropertyName("Name")]
        public string Name { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class SuperannuationContributionCalculationType
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class SuperannuationContributionType
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class SuperannuationType
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class TaxLocationAddress
    {
        [JsonPropertyName("Address1")]
        public string Address1 { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("State")]
        public State State { get; set; }

        [JsonPropertyName("Country")]
        public Country Country { get; set; }

        [JsonPropertyName("City")]
        public string City { get; set; }

        [JsonPropertyName("County")]
        public string County { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class TaxPropertyCollection
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class TFNExemptionReason
    {
        [JsonPropertyName("PayrollShortName")]
        public string PayrollShortName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class TimeOffPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class Timezone
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class TipTypeGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class TrainingProgram
    {
        [JsonPropertyName("TrainingProgramCode")]
        public string TrainingProgramCode { get; set; }

        [JsonPropertyName("TrainingProgramCourse")]
        public List<TrainingProgramCourse> TrainingProgramCourse { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class TrainingProgramCourse
    {
        [JsonPropertyName("Course")]
        public Course Course { get; set; }

        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class TrainingPrograms
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class UKNIDetails
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class UKPostgraduateLoan
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class UKStudentLoan
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class UKTaxDetails
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Union
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class UnionMemberships
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class UserAccount
    {
        [JsonPropertyName("AllowNativeAuthentication")]
        public bool AllowNativeAuthentication { get; set; }

        [JsonPropertyName("Display24HourTime")]
        public bool Display24HourTime { get; set; }

        [JsonPropertyName("IsApproved")]
        public bool IsApproved { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class UserPayAdjustCodeGroups
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class USFederalTaxes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class USStateTaxes
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class USTaxStatuses
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class VacBidGroup
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class VeteransStatus
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class VeteranStatuses
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class VolunteerList
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class VolunteerLists
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class WithholdingVariationAmountType
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class WithholdingVariationType
    {
        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }
    }

    public class WorkAssignments
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class WorkContract
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class WorkContractPremiumPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class WorkContracts
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class WorkLocationOverride
    {
        [JsonPropertyName("County")]
        public string County { get; set; }

        [JsonPropertyName("Description")]
        public string Description { get; set; }

        [JsonPropertyName("LocationName")]
        public string LocationName { get; set; }

        [JsonPropertyName("LocationAddress")]
        public LocationAddress LocationAddress { get; set; }

        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }

    public class WorkPatterns
    {
        [JsonPropertyName("Items")]
        public List<Item> Items { get; set; }
    }

    public class Zone
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("ShortName")]
        public string ShortName { get; set; }

        [JsonPropertyName("LongName")]
        public string LongName { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }
    }



}

