﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models.Dayforce
{

    public class PositionResponseModel
    {
        [JsonPropertyName("Data")]
        public PositionData Data { get; set; }

        [JsonPropertyName("Paging")]
        public PositionPaging Paging { get; set; }
    }

    public class PositionData
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("Rows")]
        public List<Row> Rows { get; set; }
    }

    public class PositionPaging
    {
        [JsonPropertyName("Next")]
        public string Next { get; set; }
    }

   

    public class Row
    {
        [JsonPropertyName("PositionID")]
        public string PositionID { get; set; }

        [JsonPropertyName("PositionTitle")]
        public string PositionTitle { get; set; }

        [JsonPropertyName("ParentPosID")]
        public string ParentPosID { get; set; }

        [JsonPropertyName("EmployeeName")]
        public string EmployeeName { get; set; }

        [JsonPropertyName("ManagerName")]
        public string ManagerName { get; set; }

        [JsonPropertyName("DateCreated")]
        public DateTime DateCreated { get; set; }

        [JsonPropertyName("DateEnded")]
        public DateTime? DateEnded { get; set; }

        [JsonPropertyName("Portfolio")]
        public string Portfolio { get; set; }

        [JsonPropertyName("PortfolioDescription")]
        public string PortfolioDescription { get; set; }

        [JsonPropertyName("Department")]
        public string Department { get; set; }

        [JsonPropertyName("DepartmentDescription")]
        public string DepartmentDescription { get; set; }

        [JsonPropertyName("Team")]
        public string Team { get; set; }

        [JsonPropertyName("TeamDescription")]
        public string TeamDescription { get; set; }

        [JsonPropertyName("Section")]
        public string Section { get; set; }

        [JsonPropertyName("SectionDescription")]
        public string SectionDescription { get; set; }

        [JsonPropertyName("SiteID")]
        public string SiteID { get; set; }

        [JsonPropertyName("LocationDescription")]
        public string LocationDescription { get; set; }

        [JsonPropertyName("CostCentre")]
        public string CostCentre { get; set; }

        [JsonPropertyName("PositionPaygrade")]
        public string PositionPaygrade { get; set; }

        [JsonPropertyName("PositionFTE")]
        public string PositionFTE { get; set; }

        [JsonPropertyName("EngineeringRegistration")]
        public string EngineeringRegistration { get; set; }

        [JsonPropertyName("SOCI")]
        public string SOCI { get; set; }

        [JsonPropertyName("PositionGrade")]
        public string PositionGrade { get; set; }
    }



}

