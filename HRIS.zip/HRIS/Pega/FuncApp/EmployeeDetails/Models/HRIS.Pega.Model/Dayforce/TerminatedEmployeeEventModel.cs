﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models.Dayforce
{
    public class TerminatedEmployeeEventModel
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("LastModifiedTimestamp")]
        public DateTime? LastModifiedTimestamp { get; set; }

        [JsonPropertyName("EmployeeNumber")]
        public string EmployeeNumber { get; set; }

        [JsonPropertyName("AverageDailyHours")]
        public int? AverageDailyHours { get; set; }

        [JsonPropertyName("AverageOvertimeRate")]
        public int?  AverageOvertimeRate { get; set; }

        [JsonPropertyName("BaseRate")]
        public double? BaseRate { get; set; }

        [JsonPropertyName("PeriodicSalary")]
        public int? PeriodicSalary { get; set; }

        [JsonPropertyName("DailyRate")]
        public int? DailyRate { get; set; }

        [JsonPropertyName("NormalSemiMonthlyHoursTop")]
        public int? NormalSemiMonthlyHoursTop { get; set; }

        [JsonPropertyName("NormalSemiMonthlyHoursBottom")]
        public int? NormalSemiMonthlyHoursBottom { get; set; }

        [JsonPropertyName("AlternateRate")]
        public int? AlternateRate { get; set; }

        [JsonPropertyName("BaseRateManuallySet")]
        public bool? BaseRateManuallySet { get; set; }

        [JsonPropertyName("BaseSalary")]
        public double? BaseSalary { get; set; }

        [JsonPropertyName("CreateShiftRotationShift")]
        public bool? CreateShiftRotationShift { get; set; }

        [JsonPropertyName("LastPayEditDate")]
        public DateTime? LastPayEditDate { get; set; }

        [JsonPropertyName("NormalWeeklyHours")]
        public double? NormalWeeklyHours { get; set; }

        [JsonPropertyName("ShiftRotationDayOffset")]
        public int? ShiftRotationDayOffset { get; set; }

        [JsonPropertyName("ShiftRotationStartDate")]
        public DateTime? ShiftRotationStartDate { get; set; }

        [JsonPropertyName("TargetBonus")]
        public int? TargetBonus { get; set; }

        [JsonPropertyName("VacationRate")]
        public int? VacationRate { get; set; }

        [JsonPropertyName("EntityState")]
        public string? EntityState { get; set; }

        [JsonPropertyName("EmployeeId")]
        public int? EmployeeId { get; set; }

        [JsonPropertyName("EmployeeXRefCode")]
        public string? EmployeeXRefCode { get; set; }

        [JsonPropertyName("EmploymentStatusReason")]
        public TerminatedEmploymentStatusReason? EmploymentStatusReason { get; set; }

        [JsonPropertyName("EmploymentStatus")]
        public EmploymentStatus? EmploymentStatus { get; set; }

        [JsonPropertyName("PayType")]
        public PayType? PayType { get; set; }

        [JsonPropertyName("PayGroup")]
        public TerminatedPayGroup? PayGroup { get; set; }

        [JsonPropertyName("PayClass")]
        public TerminatedPayClass? PayClass { get; set; }

        [JsonPropertyName("PunchPolicy")]
        public PunchPolicy? PunchPolicy { get; set; }

        [JsonPropertyName("PayPolicy")]
        public PayPolicy? PayPolicy { get; set; }

        [JsonPropertyName("PayHolidayGroup")]
        public TerminatedPayHolidayGroup? PayHolidayGroup { get; set; }

        [JsonPropertyName("EmployeeGroup")]
        public EmployeeGroup? EmployeeGroup { get; set; }

        [JsonPropertyName("EntitlementPolicy")]
        public TerminatedEntitlementPolicy? EntitlementPolicy { get; set; }

        [JsonPropertyName("ShiftRotation")]
        public ShiftRotation? ShiftRotation { get; set; }

        [JsonPropertyName("TimeOffPolicy")]
        public TimeOffPolicy? TimeOffPolicy { get; set; }

        [JsonPropertyName("ShiftTradePolicy")]
        public ShiftTradePolicy? ShiftTradePolicy { get; set; }

        [JsonPropertyName("AttendancePolicy")]
        public TerminatedEmployeeAttendancePolicy? AttendancePolicy { get; set; }

        [JsonPropertyName("SchedulePolicy")]
        public SchedulePolicy? SchedulePolicy { get; set; }

        [JsonPropertyName("OvertimeGroup")]
        public TerminatedOvertimeGroup? OvertimeGroup { get; set; }

        [JsonPropertyName("PayrollPolicy")]
        public PayrollPolicy? PayrollPolicy { get; set; }

        [JsonPropertyName("JobStepPolicy")]
        public TerminatedJobStepPolicy? JobStepPolicy { get; set; }

        [JsonPropertyName("ScheduleChangePolicy")]
        public ScheduleChangePolicy? ScheduleChangePolicy { get; set; }

        [JsonPropertyName("AuthorizationPolicy")]
        public AuthorizationPolicy? AuthorizationPolicy { get; set; }

        [JsonPropertyName("WorkContractPremiumPolicy")]
        public WorkContractPremiumPolicy? WorkContractPremiumPolicy { get; set; }
    }
    public class TerminatedEmployeeAttendancePolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }    

    public class TerminatedEmploymentStatusReason
    {
        [JsonPropertyName("XRefCode")]
        public object XRefCode { get; set; }
    }

    public class TerminatedEntitlementPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }

    public class TerminatedJobStepPolicy
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }

    public class TerminatedOvertimeGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }

    public class TerminatedPayClass
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }

    public class TerminatedPayFrequency
    {
    }

    public class TerminatedPayGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }

        [JsonPropertyName("PayFrequency")]
        public TerminatedPayFrequency? PayFrequency { get; set; }
    }

    public class TerminatedPayHolidayGroup
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }


}

