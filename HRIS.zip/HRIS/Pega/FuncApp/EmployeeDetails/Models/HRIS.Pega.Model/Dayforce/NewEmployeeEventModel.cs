﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models.Dayforce
{
    // Root myDeserializedClass = JsonSerializer.Deserialize<Root>(myJsonResponse);
    public class NewEmployeeAddress
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("Address1")]
        public string Address1 { get; set; }

        [JsonPropertyName("Address2")]
        public string Address2 { get; set; }

        [JsonPropertyName("County")]
        public string County { get; set; }

        [JsonPropertyName("City")]
        public string City { get; set; }

        [JsonPropertyName("PostalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("State")]
        public State State { get; set; }

        [JsonPropertyName("Country")]
        public NewEmployeeCountry Country { get; set; }
    }

    public class Contact
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("ContactNumber")]
        public string ContactNumber { get; set; }

        [JsonPropertyName("ElectronicAddress")]
        public string ElectronicAddress { get; set; }

        [JsonPropertyName("ContactInformationType")]
        public NewEmpContactInformationType ContactInformationType { get; set; }
    }

    public class NewEmpContactInformationType
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }

    public class NewEmployeeCountry
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }

    public class NewEmployeeCulture
    {
        [JsonPropertyName("XRefCode")]
        public string XRefCode { get; set; }
    }




    public class NewRole
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("IsDefault")]
        public bool IsDefault { get; set; }

        [JsonPropertyName("IsPrestartRole")]
        public object IsPrestartRole { get; set; }

        [JsonPropertyName("Role")]
        public Role NewEmployeeRole { get; set; }
    }

    public class NewEmployeeEventModel
    {
        [JsonPropertyName("EntityState")]
        public string EntityState { get; set; }

        [JsonPropertyName("HireDate")]
        public DateTime? HireDate { get; set; }

        [JsonPropertyName("BirthDate")]
        public DateTime? BirthDate { get; set; }

        [JsonPropertyName("EmployeeNumber")]
        public string EmployeeNumber { get; set; }

        [JsonPropertyName("EmployeeId")]
        public int EmployeeId { get; set; }

        [JsonPropertyName("FirstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("LastName")]
        public string LastName { get; set; }

        [JsonPropertyName("BirthCountry")]
        public object BirthCountry { get; set; }

        [JsonPropertyName("Gender")]
        public string Gender { get; set; }

        [JsonPropertyName("HomePhone")]
        public object HomePhone { get; set; }

        [JsonPropertyName("SocialSecurityNumber")]
        public object SocialSecurityNumber { get; set; }

        [JsonPropertyName("SSNExpiryDate")]
        public object SSNExpiryDate { get; set; }

        [JsonPropertyName("SendFirstTimeAccessEmail")]
        public bool SendFirstTimeAccessEmail { get; set; }

        [JsonPropertyName("MiddleName")]
        public object MiddleName { get; set; }

        [JsonPropertyName("EmployeeXRefCode")]
        public string EmployeeXRefCode { get; set; }

        [JsonPropertyName("OnboardingDate")]
        public object OnboardingDate { get; set; }

        [JsonPropertyName("WorkAssignments")]
        public List<WorkAssignment> WorkAssignments { get; set; }

        [JsonPropertyName("EmploymentStatuses")]
        public List<NewDataEmploymentStatus> EmploymentStatuses { get; set; }

        [JsonPropertyName("Culture")]
        public NewEmployeeCulture Culture { get; set; }

        [JsonPropertyName("CitizenshipType")]
        public CitizenshipType CitizenshipType { get; set; }

        [JsonPropertyName("Addresses")]
        public List<NewEmployeeAddress> Addresses { get; set; }

        [JsonPropertyName("ConfidentialIdentification")]
        public List<object> ConfidentialIdentification { get; set; }

        [JsonPropertyName("Contacts")]
        public List<Contact> Contacts { get; set; }

        [JsonPropertyName("EmergencyContacts")]
        public List<object> EmergencyContacts { get; set; }

        [JsonPropertyName("EmployeeWorkAssignmentManagers")]
        public List<object> EmployeeWorkAssignmentManagers { get; set; }

        [JsonPropertyName("MaritalStatuses")]
        public List<object> MaritalStatuses { get; set; }

        [JsonPropertyName("OnboardingPolicies")]
        public List<object> OnboardingPolicies { get; set; }

        [JsonPropertyName("Roles")]
        public List<NewRole> Roles { get; set; }

        [JsonPropertyName("WorkContracts")]
        public List<object> WorkContracts { get; set; }
    }

    public class NewDataEmploymentStatus
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("BaseRate")]
        public double BaseRate { get; set; }

        [JsonPropertyName("DailyRate")]
        public object DailyRate { get; set; }

        [JsonPropertyName("NormalSemiMonthlyHoursTop")]
        public object NormalSemiMonthlyHoursTop { get; set; }

        [JsonPropertyName("NormalSemiMonthlyHoursBottom")]
        public object NormalSemiMonthlyHoursBottom { get; set; }

        [JsonPropertyName("BaseSalary")]
        public double BaseSalary { get; set; }

        [JsonPropertyName("NormalWeeklyHours")]
        public object NormalWeeklyHours { get; set; }

        [JsonPropertyName("EmploymentStatus")]
        public EmploymentStatus NewEmploymentStatus { get; set; }

        [JsonPropertyName("PayType")]
        public PayType PayType { get; set; }

        [JsonPropertyName("PayClass")]
        public PayClass PayClass { get; set; }

        [JsonPropertyName("PunchPolicy")]
        public PunchPolicy PunchPolicy { get; set; }

        [JsonPropertyName("PayPolicy")]
        public PayPolicy PayPolicy { get; set; }

        [JsonPropertyName("PayHolidayGroup")]
        public PayHolidayGroup PayHolidayGroup { get; set; }

        [JsonPropertyName("ShiftTradePolicy")]
        public ShiftTradePolicy ShiftTradePolicy { get; set; }

        [JsonPropertyName("SchedulePolicy")]
        public SchedulePolicy SchedulePolicy { get; set; }

        [JsonPropertyName("OvertimeGroup")]
        public OvertimeGroup OvertimeGroup { get; set; }

        [JsonPropertyName("PayrollPolicy")]
        public PayrollPolicy PayrollPolicy { get; set; }

        [JsonPropertyName("ScheduleChangePolicy")]
        public ScheduleChangePolicy ScheduleChangePolicy { get; set; }

        [JsonPropertyName("AuthorizationPolicy")]
        public AuthorizationPolicy AuthorizationPolicy { get; set; }
    }



    public class WorkAssignment
    {
        [JsonPropertyName("EffectiveStart")]
        public DateTime? EffectiveStart { get; set; }

        [JsonPropertyName("EffectiveEnd")]
        public DateTime? EffectiveEnd { get; set; }

        [JsonPropertyName("Position")]
        public Position Position { get; set; }

        [JsonPropertyName("Location")]
        public Location Location { get; set; }
    }




}

