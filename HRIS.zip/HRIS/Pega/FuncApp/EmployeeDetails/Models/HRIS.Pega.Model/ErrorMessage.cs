﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models
{
  
        public class ErrorMessage
        {
         [JsonPropertyName("interfaceName")]
         public string InterfaceName { get; set; }

        [JsonPropertyName("errorDetails")]
        public string ErrorDetails { get; set; }

        [JsonPropertyName("systemName")]
        public string SystemName { get; set; }

        [JsonPropertyName("subject")]
        public string Subject { get; set; }

        [JsonPropertyName("recipientEmailAddress")]
        public string RecipientEmailAddress { get; set; }
       }

    

   


}

