﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace HRIS.Pega.Models
{
    public class BusinessGroup
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
        public string Desc { get; set; } = string.Empty;
    }

    public class Portfolio
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
        public string Desc { get; set; } = string.Empty;
    }




    public class CostCentre
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
        public string Desc { get; set; } = string.Empty;
    }

    public class EmployeeAddress
    {
        [JsonPropertyName("line1")]
        public string Line1 { get; set; } = string.Empty;

        [JsonPropertyName("suburb")]
        public string Suburb { get; set; } = string.Empty;

        [JsonPropertyName("state")]
        public string State { get; set; } = string.Empty;

        [JsonPropertyName("postCode")]
        public string PostCode { get; set; } = string.Empty;
    }

    public class EmployeeStatus
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
        public string Desc { get; set; } = string.Empty;
    }

        public class Funding
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class Grade
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class JobSuccessProfile
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class LeadershipTier
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class LeaveGroup
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class Level1Manager
        {
            [JsonPropertyName("positionID")]
            public string PositionID { get; set; } = string.Empty;
        [JsonPropertyName("positionDesc")]
            public string PositionDesc { get; set; } = string.Empty;
        
        [JsonPropertyName("employeeId")]
            public string EmployeeId { get; set; } = string.Empty;
        [JsonPropertyName("firstName")]
            public string FirstName { get; set; } = string.Empty;
        [JsonPropertyName("surname")]
            public string Surname { get; set; } = string.Empty;
        [JsonPropertyName("emailId")]
            public string EmailId { get; set; } = string.Empty;
    }

        public class Level2Manager
        {

            [JsonPropertyName("positionID")]
            public string PositionID { get; set; } = string.Empty;

        [JsonPropertyName("positionDesc")]
            public string PositionDesc { get; set; } = string.Empty;       

        [JsonPropertyName("employeeId")]
            public string EmployeeId { get; set; } = string.Empty;

        [JsonPropertyName("firstName")]
            public string FirstName { get; set; } = string.Empty;

        [JsonPropertyName("surname")]
            public string Surname { get; set; } = string.Empty;

        [JsonPropertyName("emailId")]
            public string EmailId { get; set; } = string.Empty;
    }

        public class EGMDetails
        {

            [JsonPropertyName("positionID")]
            public string PositionID { get; set; } = string.Empty;

        [JsonPropertyName("positionDesc")]
            public string PositionDesc { get; set; } = string.Empty;

        [JsonPropertyName("occupancyStatus")]
            public OccupancyStatus OccupancyStatus { get; set; } 

        [JsonPropertyName("employeeId")]
            public string EmployeeId { get; set; } = string.Empty;

        [JsonPropertyName("firstName")]
            public string FirstName { get; set; } = string.Empty;

        [JsonPropertyName("surname")]
            public string Surname { get; set; } = string.Empty;

        [JsonPropertyName("emailId")]
            public string EmailId { get; set; } = string.Empty;
    }


    public class EGMManager
    {

        [JsonPropertyName("positionID")]
        public string PositionID { get; set; } = string.Empty;

        [JsonPropertyName("positionDesc")]
        public string PositionDesc { get; set; } = string.Empty;

        [JsonPropertyName("occupancyStatus")]
        public OccupancyStatus OccupancyStatus { get; set; }

        [JsonPropertyName("employeeId")]
        public string EmployeeId { get; set; } = string.Empty;

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; } = string.Empty;

        [JsonPropertyName("surname")]
        public string Surname { get; set; } = string.Empty;

        [JsonPropertyName("emailId")]
        public string EmailId { get; set; } = string.Empty;
    }

    public class OccupancyStatus
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class PeopleLeaderCategory
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class PositionDetails
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;

        [JsonPropertyName("startDate")]
            public string StartDate { get; set; } = string.Empty;

        [JsonPropertyName("endDate")]
            public string EndDate { get; set; } = string.Empty;

        [JsonPropertyName("employeeStatus")]
            public EmployeeStatus EmployeeStatus { get; set; } 

            [JsonPropertyName("occupancyStatus")]
            public OccupancyStatus OccupancyStatus { get; set; }
            //[JsonPropertyName("grade")]
            //public Grade Grade { get; set; } 

            [JsonPropertyName("businessGroup")]
            public BusinessGroup BusinessGroup { get; set; }

            [JsonPropertyName("portfolio")]
            public Portfolio Portfolio { get; set; }
           [JsonPropertyName("team")]
            public Team Team { get; set; }
            [JsonPropertyName("section")]
            public Section Section { get; set; }
            [JsonPropertyName("peopleLeaderCategory")]
            public PeopleLeaderCategory PeopleLeaderCategory { get; set; }
            [JsonPropertyName("workLocation")]
            public WorkLocation WorkLocation { get; set; }
            [JsonPropertyName("costCentre")]
            public CostCentre CostCentre { get; set; }
            
            [JsonPropertyName("hoursPerWeek")]
            public string HoursPerWeek { get; set; } = string.Empty;
        [JsonPropertyName("level1Manager")]
            public Level1Manager Level1Manager { get; set; }
            
            [JsonPropertyName("level2Manager")]
            public Level2Manager Level2Manager { get; set; }

           
    }

        public class Reason
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class EmployeeDetailsApiResponse
        {
            [JsonPropertyName("employeeId")]
            public string EmployeeId { get; set; } = string.Empty;

        [JsonPropertyName("networkID")]
            public string NetworkID { get; set; } = string.Empty;

        [JsonPropertyName("firstName")]
            public string FirstName { get; set; } = string.Empty;
        [JsonPropertyName("surname")]
            public string Surname { get; set; } = string.Empty;      

        [JsonPropertyName("preferredFirstName")]
            public string PreferredFirstName { get; set; } = string.Empty;

        [JsonPropertyName("preferredLastName")]
            public string PreferredLastName { get; set; } = string.Empty;

        [JsonPropertyName("dateOfBirth")]
            public string DateOfBirth { get; set; } = string.Empty;

        [JsonPropertyName("joinedDate")]
            public string JoinedDate { get; set; } = string.Empty;

        [JsonPropertyName("employeeAddress")]
            public EmployeeAddress EmployeeAddress { get; set; } 

        [JsonPropertyName("emailId")]
            public string EmailId { get; set; } = string.Empty;

        [JsonPropertyName("mobileNumber")]
            public string MobileNumber { get; set; } = string.Empty;

        [JsonPropertyName("positionDetails")]
            public PositionDetails PositionDetails { get; set; }
        }

        public class Section
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class Team
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class WithInPlan
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }

        public class WorkLocation
        {
            [JsonPropertyName("id")]
            public string Id { get; set; } = string.Empty;
        [JsonPropertyName("desc")]
            public string Desc { get; set; } = string.Empty;
    }


    


}

