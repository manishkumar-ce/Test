﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models
{
  
        public class ErrorHandlerMessage
        {       

        [JsonPropertyName("subject")]
        public string Subject { get; set; }

        [JsonPropertyName("htmlBody")]
        public string HtmlBody { get; set; }

        [JsonPropertyName("recipientAddress")]
        public string RecipientAddress { get; set; }
    }

    


   


}

