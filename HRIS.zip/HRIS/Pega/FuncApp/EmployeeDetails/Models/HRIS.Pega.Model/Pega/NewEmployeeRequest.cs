﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace HRIS.Pega.Models.Pega
{
    public class NewEmployeeRequest
    {
        [JsonPropertyName("event")]
        public string Event { get; set; }

        [JsonPropertyName("employeeDetails")]
        public EmployeeDetails EmployeeDetails { get; set; }
    }

    public class AddressDetails
    {
        [JsonPropertyName("line1")]
        public string Line1 { get; set; }

        [JsonPropertyName("suburb")]
        public string Suburb { get; set; }

        [JsonPropertyName("postCode")]
        public string PostCode { get; set; }

        [JsonPropertyName("state")]
        public string State { get; set; }
    }

    public class EmployeeDetails
    {
        [JsonPropertyName("employeeId")]
        public string EmployeeID { get; set; }

        [JsonPropertyName("networkID")]
        public string NetworkID { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("surname")]
        public string LastName { get; set; }

        [JsonPropertyName("preferredName")]
        public string PreferredName { get; set; }

        [JsonPropertyName("emailId")]
        public string EmailID { get; set; }

        [JsonPropertyName("mobileNumber")]
        public string MobileNumber { get; set; }

        [JsonPropertyName("dateOfBirth")]
        public string DateOfBirth { get; set; }

        [JsonPropertyName("joinedDate")]
        public string JoinedDate { get; set; }

        [JsonPropertyName("addressDetails")]
        public AddressDetails AddressDetails { get; set; }

        [JsonPropertyName("positionDetails")]
        public PositionDetails PositionDetails { get; set; }

        [JsonPropertyName("HeaderDetails")]
        public HeaderDetails HeaderDetails { get; set; }
    }

    public class HeaderDetails
    {
        [JsonPropertyName("BusinessReferenceID")]
        public string BusinessReferenceID { get; set; }

        [JsonPropertyName("InterfaceHeader")]
        public string InterfaceHeader { get; set; }

        [JsonPropertyName("InterfaceName")]
        public string InterfaceName { get; set; }

        [JsonPropertyName("InterfaceVersion")]
        public string InterfaceVersion { get; set; }

        [JsonPropertyName("MessageType")]
        public string MessageType { get; set; }

        [JsonPropertyName("SourceInformation")]
        public string SourceInformation { get; set; }

        [JsonPropertyName("SourceSystemID")]
        public string SourceSystemID { get; set; }

        [JsonPropertyName("Timestamp")]
        public string Timestamp { get; set; }
    }

    public class PositionDetails
    {
        [JsonPropertyName("id")]
        public string PositionID { get; set; }

        [JsonPropertyName("desc")]
        public string Desc { get; set; }
    }

   


}

