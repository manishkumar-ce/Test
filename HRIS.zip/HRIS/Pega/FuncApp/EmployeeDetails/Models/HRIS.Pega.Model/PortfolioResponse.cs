﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models
{
  
        public class PortfolioResponse
        {
            [JsonPropertyName("portfolioDetails")]
            public List<PortfolioDetails> PortfolioDetails { get; set; }

        }


    public class PortfolioDetails
    {
        [JsonPropertyName("portfolio")]
        public string EgmPortfolio { get; set; }


        [JsonPropertyName("empRefCode")]
        public string EmpXrefCode { get; set; }
     
    }





}

