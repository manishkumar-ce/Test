﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRIS.Pega.Models
{
  
        public class PositionReportResponse
        {
            [JsonPropertyName("positionReports")]
            public List<PositionReports> PositionReports { get; set; }

        }


    public class PositionReports
    {
        [JsonPropertyName("positionNumber")]
        public string PositionNumber { get; set; } = "";


        [JsonPropertyName("positionTitle")]
        public string PositionTitle { get; set; } = "";

        [JsonPropertyName("managerPositionNumber")]
        public string ManagerPositionNumber { get; set; } = "";

        [JsonPropertyName("employeeName")]
        
        public string EmployeeName { get; set; } = "";

        [JsonPropertyName("managerName")]
        public string ManagerName { get; set; } = "";

        [JsonPropertyName("statusDescription")]
        public string StatusDescription { get; set; } = "";

        [JsonPropertyName("portfolioCode")]
        public string PortfolioCode { get; set; } = "";

        [JsonPropertyName("portfolioDescription")]
        public string PortfolioDescription { get; set; } = "";

        [JsonPropertyName("departmentCode")]
        public string DepartmentCode { get; set; } = "";

        [JsonPropertyName("departmentDescription")]
        public string DepartmentDescription { get; set; } = "";

        [JsonPropertyName("teamCode")]
        public string TeamCode { get; set; } = "";

        [JsonPropertyName("teamDescription")]
        public string TeamDescription { get; set; } = "";

        [JsonPropertyName("sectionCode")]
        public string SectionCode { get; set; } = "";

        [JsonPropertyName("sectionDescription")]
        public string SectionDescription { get; set; } = "";

        [JsonPropertyName("locationCode")]
        public string LocationCode { get; set; } = "";

        [JsonPropertyName("locationDescription")]
        public string LocationDescription { get; set; } = "";

        [JsonPropertyName("costCentre")]
        public string CostCentre { get; set; } = "";

        [JsonPropertyName("positionFTE")]
        public string PositionFTE { get; set; } = "";

        [JsonPropertyName("executiveAssistant")]
        public string ExecutiveAssistant { get; set; } = "";

        [JsonPropertyName("engineeringRegistration")]
        public string EngineeringRegistration { get; set; } = "";

        [JsonPropertyName("soci")]
        public string SOCI { get; set; } = "";

        [JsonPropertyName("anzscoCode")]
        public string AnzscoCode { get; set; } = "";

        [JsonPropertyName("grade")]
        public string Grade { get; set; } = "";


        [JsonPropertyName("dateCreated")]
        public DateTime? DateCreated { get; set; }

        [JsonPropertyName("dateEnded")]
        public DateTime? DateEnded { get; set; }


    }





}

