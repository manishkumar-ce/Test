using System.Net;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using HRIS.Pega.Helpers.Interfaces;
using HRIS.Pega.Models;
using HRIS.Pega.Models.Dayforce;
using HRIS.Pega.Models.Pega;
using HRIS.Pega.Helpers;
using HRIS.Pega.Repository.Http.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;


namespace HRIS.Pega.FunApp
{
    public class NewEmployees
    {
        private readonly ILogger<NewEmployees> _logger;
        private readonly IRestApiRepository _restApiRepository;
        private readonly IServiceBusPublisher _serviceBusPublisher;

        public NewEmployees(ILogger<NewEmployees> logger, IRestApiRepository restApiRepository, IServiceBusPublisher serviceBusPublisher)
        {
            _logger = logger;
            _restApiRepository = restApiRepository;
            _serviceBusPublisher = serviceBusPublisher; 
        }


        [Function(nameof(NewEmployees))]
        [EventGridOutput(TopicEndpointUri = "NewEmployeeEventGridTopicUriSetting", TopicKeySetting = "NewEmployeeEventGridTopicKeySetting")]
        public async Task Run([EventGridTrigger] string data)
        {
            try
            {
                _logger.LogInformation($"New employee data event first message : {data} ");
                var input = JsonSerializer.Deserialize<MyEvent>(data);
                _logger.LogInformation("Started processing new employee details");
                JsonSerializerOptions options = new JsonSerializerOptions();
                options.WriteIndented = true;
                options.Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                _logger.LogInformation($"New employee data event message : {JsonSerializer.Serialize(input, options)} ");
                var newEmployeeEvent = input.Data;
                if (ValidateInput(newEmployeeEvent))
                {
                    if (IsEmployeePermanent(newEmployeeEvent))
                    {
                        if (!String.IsNullOrWhiteSpace(newEmployeeEvent.EmployeeXRefCode))
                        {
                            await Task.Delay(30000);
                            var res = await _restApiRepository.GetEmployeeDetails(newEmployeeEvent.EmployeeXRefCode, "WorkAssignments,Contacts,OrgUnitInfos,SSOAccounts");
                            if (res.StatusCode == HttpStatusCode.OK)
                            {

                                var content = await res.Content.ReadAsStringAsync();

                                var employeeDetails = JsonSerializer.Deserialize<EmployeeDetailsResponse>(content);
                                var pegaEmployeeDetails = await MapToNewEmployees(employeeDetails);

                                if (pegaEmployeeDetails.EmployeeDetails.NetworkID != null && pegaEmployeeDetails.EmployeeDetails.EmployeeID != null && pegaEmployeeDetails.EmployeeDetails.EmailID != null)
                                {

                                    string requestPayload = JsonSerializer.Serialize(pegaEmployeeDetails, options);
                                    _logger.LogInformation($"Payload to pega : {requestPayload}");
                                    res = await _restApiRepository.PostPegaEmployee(requestPayload);
                                    if (!(res.StatusCode == System.Net.HttpStatusCode.OK))
                                    {
                                        _logger.LogError($"Sending new employee details to pega failed {res.Content.ReadAsStringAsync()}");
                                        throw new Exception($"Sending new employee details to pega failed {res.Content.ReadAsStringAsync().Result}");
                                        
                                    }

                                    _logger.LogInformation("Completed processing new employee details");
                                }
                                else
                                {
                                    _logger.LogInformation($"Skipping the processing of the employee : {data}");
                                }
                            }
                            else
                            {
                                _logger.LogError($"Could not fetch details for the new employee {res.Content.ReadAsStringAsync()}");
                            }
                                
                        }
                    }
                    else
                    {
                        _logger.LogInformation($"Employee is not a permanent employee {newEmployeeEvent.EmployeeXRefCode}");

                    }
                }
                else
                {
                    _logger.LogError($"Invalid input");
                }


            }

            catch (Exception ex)
            {
                _logger.LogError($"Error in Pega : NewEmployees. Details : {ex.Message}");
                await SendErrorHandlerEvent(ex);

            }


        }

        private async Task SendErrorHandlerEvent(Exception ex)
        {
            ErrorMessage message = new ErrorMessage();
            message.ErrorDetails = ex.Message;
            message.InterfaceName = "New Employee Details";
            message.SystemName = "Pega";
            var errorHandlerMessage = new ErrorHandlerMessage();
            errorHandlerMessage.HtmlBody = message.ToEmailHtmlContent();
            errorHandlerMessage.Subject = message.ToEmailSubject();
            errorHandlerMessage.RecipientAddress = Environment.GetEnvironmentVariable("RecipientEmail");
            await _serviceBusPublisher.SendMessageAsync(errorHandlerMessage);
        }

        private static bool IsEmployeePermanent(NewEmployeeEventModel newEmployeeEvent)
        {
            return (newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "FP" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "LF" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "PP" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "FS" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "CAS" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "LP" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "FTC");
        }

        private static bool ValidateInput(NewEmployeeEventModel newEmployeeEvent)
        {
            return newEmployeeEvent.EmploymentStatuses != null && newEmployeeEvent.EmploymentStatuses?.Count > 0 && !String.IsNullOrWhiteSpace(newEmployeeEvent.EmploymentStatuses[0].PayClass.XRefCode);
        }

        private static async Task<NewEmployeeRequest> MapToNewEmployees(EmployeeDetailsResponse? employeeDetails)
        {          

            NewEmployeeRequest newEmployeeRequest = new NewEmployeeRequest();

            newEmployeeRequest.Event = "Hire";
            newEmployeeRequest.EmployeeDetails = new HRIS.Pega.Models.Pega.EmployeeDetails();
            newEmployeeRequest.EmployeeDetails.EmployeeID = employeeDetails.Data.XRefCode;
            if (employeeDetails.Data.SSOAccounts != null && !string.IsNullOrWhiteSpace(employeeDetails.Data.SSOAccounts.Items[0]?.LoginName))
            {
                newEmployeeRequest.EmployeeDetails.NetworkID = employeeDetails.Data.SSOAccounts.Items[0].LoginName;
            }
            newEmployeeRequest.EmployeeDetails.FirstName = employeeDetails.Data.FirstName;
            newEmployeeRequest.EmployeeDetails.LastName = employeeDetails.Data.LastName;
            newEmployeeRequest.EmployeeDetails.PreferredName = employeeDetails.Data.FirstName;
            newEmployeeRequest.EmployeeDetails.DateOfBirth = employeeDetails.Data.BirthDate?.ToString("dd/MM/yyyy");
            newEmployeeRequest.EmployeeDetails.JoinedDate = employeeDetails.Data.HireDate?.ToString("dd/MM/yyyy");
            if (employeeDetails.Data.Contacts != null && employeeDetails.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").Count() > 0)
            {
                var emailAddress = employeeDetails.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").FirstOrDefault();
                newEmployeeRequest.EmployeeDetails.EmailID = emailAddress.ElectronicAddress;

            }
            if (employeeDetails.Data.Contacts != null && employeeDetails.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessMobile").Count() > 0)
            {
                var phoneDetails = employeeDetails.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessMobile").FirstOrDefault();
                newEmployeeRequest.EmployeeDetails.MobileNumber = phoneDetails.Location.BusinessPhone;

            }
            if (employeeDetails.Data.Addresses != null && employeeDetails.Data.Addresses.Items.Where(x => x.ContactInformationType.XRefCode == "PrimaryResidence").Count() > 0)
            {
                var primaryAddress = employeeDetails.Data.Addresses.Items.Where(x => x.ContactInformationType.XRefCode == "PrimaryResidence").FirstOrDefault();
                newEmployeeRequest.EmployeeDetails.AddressDetails.Line1 = primaryAddress.Address1;
                newEmployeeRequest.EmployeeDetails.AddressDetails.Suburb = primaryAddress.City;
                newEmployeeRequest.EmployeeDetails.AddressDetails.PostCode = primaryAddress.PostalCode;
                newEmployeeRequest.EmployeeDetails.AddressDetails.State = primaryAddress.State.XRefCode;
            }           
         
          
            if (employeeDetails.Data.WorkAssignments != null && employeeDetails.Data.WorkAssignments.Items.Where(x => x.IsPrimary == true).Count() > 0)
            {
                var positionDetails = employeeDetails.Data.WorkAssignments.Items.Where(x => x.IsPrimary == true).FirstOrDefault();
                if (positionDetails != null && positionDetails.PMPositionAssignment?.PMPosition != null)
                {
                    newEmployeeRequest.EmployeeDetails.PositionDetails = new HRIS.Pega.Models.Pega.PositionDetails
                    {
                        PositionID = positionDetails.PMPositionAssignment.PMPosition.XRefCode,
                        Desc = positionDetails.PMPositionAssignment.PMPosition.ShortName,
                    };
                }

            }
            newEmployeeRequest.EmployeeDetails.HeaderDetails = new HeaderDetails();
            newEmployeeRequest.EmployeeDetails.HeaderDetails.SourceSystemID = "Dayforce";
            newEmployeeRequest.EmployeeDetails.HeaderDetails.BusinessReferenceID = "ID";
            newEmployeeRequest.EmployeeDetails.HeaderDetails.InterfaceHeader = "Header";
            newEmployeeRequest.EmployeeDetails.HeaderDetails.InterfaceName = "INT243";
            newEmployeeRequest.EmployeeDetails.HeaderDetails.InterfaceVersion = "V1";
            newEmployeeRequest.EmployeeDetails.HeaderDetails.MessageType = "NewHire";
            newEmployeeRequest.EmployeeDetails.HeaderDetails.SourceInformation = "Dayforce";
            newEmployeeRequest.EmployeeDetails.HeaderDetails.SourceSystemID = "Dayforce";
            newEmployeeRequest.EmployeeDetails.HeaderDetails.Timestamp = DateTime.UtcNow.ToString("dd/MM/yyyy");


            return newEmployeeRequest;
        }
    }

    public class MyEvent
    {
         [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("topic")]
        public string Topic { get; set; }

        [JsonPropertyName("subject")]
        public string Subject { get; set; }

        [JsonPropertyName("eventType")]
        public string EventType { get; set; }

        [JsonPropertyName("eventTime")]
        public string EventTime { get; set; }

         [JsonPropertyName("data")]
        public NewEmployeeEventModel Data { get; set; }
        // [JsonPropertyName("dataVersion")]
        public string DataVersion { get; set; }
    }

   

}
