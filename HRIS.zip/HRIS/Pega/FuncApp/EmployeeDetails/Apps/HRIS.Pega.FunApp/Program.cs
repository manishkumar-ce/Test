using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using HRIS.Pega.FunApp;


var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices(services =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();
        services.ConfigureApplicationServices();


    })
    .ConfigureLogging(loggingBuiler => loggingBuiler.Services.ConfigureLoggingRules())
    .Build();

host.Run();