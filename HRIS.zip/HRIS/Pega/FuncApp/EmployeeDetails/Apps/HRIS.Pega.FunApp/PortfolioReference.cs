using System.Net;
using HRIS.Pega.Helpers;
using HRIS.Pega.Helpers.Interfaces;
using HRIS.Pega.Models;
using HRIS.Pega.Models.Dayforce;
using HRIS.Pega.Repository.Http.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.VisualBasic;
using Newtonsoft.Json;


namespace HRIS.Pega.FunApp

{
    public class PortfolioReference
    {
        private readonly ILogger<PortfolioReference> _logger;
        private readonly IRestApiRepository _restApiRepository;
        private readonly IServiceBusPublisher _serviceBusPublisher;

        public PortfolioReference(ILogger<PortfolioReference> logger, IRestApiRepository restApiRepository, IServiceBusPublisher serviceBusPublisher)
        {
            _logger = logger;
            _restApiRepository = restApiRepository;
            _serviceBusPublisher = serviceBusPublisher;
        }

        [Function("PortfolioReference")]
        public  async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = "portfolios")] HttpRequest req)
        {
            try
            {
                _logger.LogInformation("Started processing get portfolio reference");
               
                var res = await _restApiRepository.GetPortfolioDetails();
                if (res.StatusCode == HttpStatusCode.NotFound || res.StatusCode == HttpStatusCode.BadRequest)
                {
                    new BadRequestObjectResult($"Error Fetching Data from Dayforce . {res.Content.ReadAsStringAsync()}");
                }
                if (res.StatusCode != HttpStatusCode.OK)
                {
                    //await SendErrorHandlerEvent(res.Content.ReadAsStringAsync().Result);
                    return new StatusCodeResult((int)HttpStatusCode.InternalServerError);

                }
                var content = await res.Content.ReadAsStringAsync();

                var portfolioResponse = JsonConvert.DeserializeObject<PortfolioResponseModel>(content);

                var apiResponse = portfolioResponse.ToPortfolioResponse();
                return (ActionResult)new OkObjectResult(apiResponse);
            }

            catch (Exception ex)
            {
                _logger.LogError($"Error while fetching portfolio details : {ex.Message}");
                await SendErrorHandlerEvent(ex.Message);
                return new StatusCodeResult((int)HttpStatusCode.InternalServerError);
            }

               
        }

        private async Task SendErrorHandlerEvent(string errorMessage)
        {
            ErrorMessage message = new ErrorMessage();
            message.ErrorDetails = errorMessage;
            message.InterfaceName = "Get Portfolio Reference Details";
            message.SystemName = "Pega";
            var errorHandlerMessage = new ErrorHandlerMessage();
            errorHandlerMessage.HtmlBody = message.ToEmailHtmlContent();
            errorHandlerMessage.Subject = message.ToEmailSubject();
            errorHandlerMessage.RecipientAddress = Environment.GetEnvironmentVariable("RecipientEmail");
            await _serviceBusPublisher.SendMessageAsync(errorHandlerMessage);
        }
    }
}
