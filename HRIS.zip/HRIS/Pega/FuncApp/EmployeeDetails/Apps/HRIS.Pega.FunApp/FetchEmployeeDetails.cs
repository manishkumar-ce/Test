using System.Net;
using HRIS.Pega.Helpers;
using HRIS.Pega.Helpers.Interfaces;
using HRIS.Pega.Models;
using HRIS.Pega.Models.Dayforce;
using HRIS.Pega.Repository.Http.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;


namespace HRS.Pega.FunApp

{
    public class FetchEmployeeDetails
    {
        private readonly ILogger<FetchEmployeeDetails> _logger;
        private readonly IRestApiRepository _restApiRepository;
        private readonly IServiceBusPublisher _serviceBusPublisher;
        public FetchEmployeeDetails(ILogger<FetchEmployeeDetails>  logger , IRestApiRepository restApiRepository, IServiceBusPublisher serviceBusPublisher)
        {
            _logger = logger;
            _restApiRepository = restApiRepository;
            _serviceBusPublisher = serviceBusPublisher;
        }
        [Function("FetchEmployeeDetails")]
        public  async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = "employees/{id}")] HttpRequest req)
        {
            try
            {
                _logger.LogInformation("FetchEmployeeDetails started processing");

                object empId = string.Empty;
                req.RouteValues.TryGetValue("id",out empId);

                if(string.IsNullOrWhiteSpace(empId.ToString()))
                {
                    throw new BadHttpRequestException("Provide an employee xrefcode");
                }

                var res = await _restApiRepository.GetEmployeeDetails(empId.ToString(), Environment.GetEnvironmentVariable("ExpandParams"));
                var content = await res.Content.ReadAsStringAsync();

                if(res.StatusCode == HttpStatusCode.NotFound || res.StatusCode == HttpStatusCode.BadRequest)
                {
                    return new BadRequestObjectResult("Employee Not Found");
                }
                if(res.StatusCode != HttpStatusCode.OK)
                {
                    await SendErrorHandlerEvent(res.Content.ReadAsStringAsync().Result);
                    return new StatusCodeResult((int)HttpStatusCode.InternalServerError);

                }
                var empResponse = JsonConvert.DeserializeObject<EmployeeDetailsResponse>(content);

                var apiResponse = empResponse.ToEmpDetailsResponse();

                if (!String.IsNullOrEmpty(apiResponse.PositionDetails?.Level1Manager?.EmployeeId))
                {
                    res = await _restApiRepository.GetEmployeeDetails(apiResponse.PositionDetails.Level1Manager.EmployeeId, "Contacts,WorkAssignments,EmployeeManagers");
                    
                    if (res.StatusCode == HttpStatusCode.OK)
                    {
                        content = await res.Content.ReadAsStringAsync();

                        var managerEmpResponse = JsonConvert.DeserializeObject<EmployeeDetailsResponse>(content);
                        if (managerEmpResponse.Data.Contacts != null && managerEmpResponse.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").Count() > 0)
                        {
                            var emailAddress = managerEmpResponse.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").FirstOrDefault();
                            apiResponse.PositionDetails.Level1Manager.EmailId = emailAddress.ElectronicAddress;

                        }
                        var positionDetails = managerEmpResponse.Data.WorkAssignments.Items.Where(x => x.IsPrimary == true).FirstOrDefault();
                        apiResponse.PositionDetails.Level2Manager = new Level2Manager
                        {

                            EmailId = managerEmpResponse.Data.EmployeeManagers.Items[0].ElectronicAddress,
                            FirstName = managerEmpResponse.Data.EmployeeManagers.Items[0].ManagerFirstName,
                            EmployeeId = managerEmpResponse.Data.EmployeeManagers.Items[0].ManagerXRefCode,
                            Surname = managerEmpResponse.Data.EmployeeManagers.Items[0].ManagerLastName,

                        };

                        apiResponse.PositionDetails.Level1Manager.PositionID = positionDetails.PMPositionAssignment.PMPosition.XRefCode;
                        apiResponse.PositionDetails.Level1Manager.PositionDesc = positionDetails.PMPositionAssignment.PMPosition.ShortName;
                    }
                    else
                    {
                        _logger.LogWarning("Employee Level1 manager details not found");
                    }

                    if (apiResponse.PositionDetails?.Level2Manager != null && !String.IsNullOrEmpty(apiResponse.PositionDetails.Level2Manager.EmployeeId))
                    {
                        res = await _restApiRepository.GetEmployeeDetails(apiResponse.PositionDetails.Level2Manager.EmployeeId, "Contacts,WorkAssignments,EmployeeManagers");
                        if (res.StatusCode == HttpStatusCode.NotFound || res.StatusCode == HttpStatusCode.BadRequest)
                        {
                            new BadRequestObjectResult($"Error Fetching Data from Dayforce . {res.Content.ReadAsStringAsync()}");
                        }
                        if (res.StatusCode != HttpStatusCode.OK)
                        {
                            return new StatusCodeResult((int)HttpStatusCode.InternalServerError);

                        }
                        content = await res.Content.ReadAsStringAsync();

                        var managerL2EmpResponse = JsonConvert.DeserializeObject<EmployeeDetailsResponse>(content);
                        if (managerL2EmpResponse.Data.Contacts != null && managerL2EmpResponse.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").Count() > 0)
                        {
                            var emailAddress = managerL2EmpResponse.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").FirstOrDefault();
                            apiResponse.PositionDetails.Level2Manager.EmailId = emailAddress.ElectronicAddress;

                        }
                        var positionDetails = managerL2EmpResponse.Data.WorkAssignments.Items.Where(x => x.IsPrimary == true).FirstOrDefault();

                        apiResponse.PositionDetails.Level2Manager.PositionID = positionDetails.PMPositionAssignment.PMPosition.XRefCode;
                        apiResponse.PositionDetails.Level2Manager.PositionDesc = positionDetails.PMPositionAssignment.PMPosition.ShortName;
                    }
                    else
                    {
                        _logger.LogWarning("Employee Level2 manager details not found");
                    }
                }

                return empId != null
                    ? (ActionResult)new OkObjectResult(apiResponse)
                    : new BadRequestObjectResult("Please pass a empID on the query string or in the request body");
            }
            catch (Exception ex)
            {
                await SendErrorHandlerEvent(ex.Message);
                return new StatusCodeResult((int)HttpStatusCode.InternalServerError);
            }

        }

        private async Task SendErrorHandlerEvent(string exceptionMessage)
        {
            ErrorMessage message = new ErrorMessage();
            message.ErrorDetails = exceptionMessage;
            message.InterfaceName = "Get Employee Details";
            message.SystemName = "Pega";
            var errorHandlerMessage = new ErrorHandlerMessage();
            errorHandlerMessage.HtmlBody = message.ToEmailHtmlContent();
            errorHandlerMessage.Subject = message.ToEmailSubject();
            errorHandlerMessage.RecipientAddress = Environment.GetEnvironmentVariable("RecipientEmail");
            await _serviceBusPublisher.SendMessageAsync(errorHandlerMessage);
        }
    }
}
