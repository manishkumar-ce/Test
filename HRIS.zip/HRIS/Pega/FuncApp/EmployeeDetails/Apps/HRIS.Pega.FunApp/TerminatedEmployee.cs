using System.Net;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using HRIS.Pega.Helpers.Interfaces;
using HRIS.Pega.Models;
using HRIS.Pega.Models.Dayforce;
using HRIS.Pega.Models.Pega;
using HRIS.Pega.Helpers;
using HRIS.Pega.Repository.Http.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;


namespace HRIS.Pega.FunApp
{
    public class TerminatedEmployee
    {
        private readonly ILogger<TerminatedEmployee> _logger;
        private readonly IRestApiRepository _restApiRepository;
        private readonly IServiceBusPublisher _serviceBusPublisher;

        public TerminatedEmployee(ILogger<TerminatedEmployee> logger, IRestApiRepository restApiRepository, IServiceBusPublisher serviceBusPublisher)
        {
            _logger = logger;
            _restApiRepository = restApiRepository;
            _serviceBusPublisher = serviceBusPublisher;
        }


        [Function(nameof(TerminatedEmployee))]
        [EventGridOutput(TopicEndpointUri = "EmployeeStatusChangeEventGridTopicUriSetting", TopicKeySetting = "EmployeeStatusChangeEventGridTopicKeySetting")]
        public async Task Run([EventGridTrigger] string data)
        {
            try
            {
                _logger.LogInformation($"Terminated employee data event first message : {data} ");
                var input = JsonSerializer.Deserialize<TerminatedEvent>(data);
                _logger.LogInformation("Started processing terminated employee details");
                JsonSerializerOptions options = new JsonSerializerOptions();
                options.WriteIndented = true;
                options.Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                _logger.LogInformation($"Terminated employee data event message : {JsonSerializer.Serialize(input, options)} ");
                var terminatedEmployeeEvent = input.Data;
                if (IsTerminatedEmployee(terminatedEmployeeEvent))
                {

                    if (!String.IsNullOrWhiteSpace(terminatedEmployeeEvent.EmployeeXRefCode))
                    {
                        var res = await _restApiRepository.GetEmployeeDetails(terminatedEmployeeEvent.EmployeeXRefCode, "WorkAssignments,Contacts,OrgUnitInfos,SSOAccounts");
                        if (res.StatusCode == HttpStatusCode.OK)
                        {

                            var content = await res.Content.ReadAsStringAsync();

                            var employeeDetails = JsonSerializer.Deserialize<EmployeeDetailsResponse>(content);
                            var pegaEmployeeDetails = await MapToTerminatedEmployees(employeeDetails);

                            if (pegaEmployeeDetails.EmployeeDetails.NetworkID != null && pegaEmployeeDetails.EmployeeDetails.EmployeeID != null && pegaEmployeeDetails.EmployeeDetails.EmailID != null)
                            {

                                string requestPayload = JsonSerializer.Serialize(pegaEmployeeDetails, options);
                                _logger.LogInformation($"Payload to pega : {requestPayload}");
                                res = await _restApiRepository.PostPegaEmployee(requestPayload);
                                if (!(res.StatusCode == System.Net.HttpStatusCode.OK))
                                {
                                    throw new Exception($"Sending terminated employee details to pega failed {res.Content.ReadAsStringAsync().Result}");
                                    
                                }

                                _logger.LogInformation("Completed processing terminated employee details");
                            }
                            else
                            {
                                _logger.LogInformation($"Skipping the processing of the employee : {data}");
                            }
                        }
                        else
                        {
                            _logger.LogError($"Could not fetch details for the new employee {res.Content.ReadAsStringAsync()}");
                        }

                    }
                    else
                    {
                        _logger.LogError($"Ignoring the employment status updates");
                    }

                }
                else
                {
                    _logger.LogError($"Ignoring processing of the employee since status doesnt match as TERMINATED for the employee {terminatedEmployeeEvent.EmployeeXRefCode}");
                }



            }

            catch (Exception ex)
            {
                _logger.LogError($"Error in Pega : Terminated Employees. Details : {ex.Message}");
                await SendErrorHandlerEvent(ex);

            }


        }

        private async Task SendErrorHandlerEvent(Exception ex)
        {
            ErrorMessage message = new ErrorMessage();
            message.ErrorDetails = ex.Message;
            message.InterfaceName = "Terminate Employee Event Handler";
            message.SystemName = "Pega";
            var errorHandlerMessage = new ErrorHandlerMessage();
            errorHandlerMessage.HtmlBody = message.ToEmailHtmlContent();
            errorHandlerMessage.Subject = message.ToEmailSubject();
            errorHandlerMessage.RecipientAddress = Environment.GetEnvironmentVariable("RecipientEmail");
            await _serviceBusPublisher.SendMessageAsync(errorHandlerMessage);
        }

        private static bool IsEmployeePermanent(NewEmployeeEventModel newEmployeeEvent)
        {
            return (newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "FP" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "LF" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "PP" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "FS" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "CAS" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "LP" || newEmployeeEvent.EmploymentStatuses[0].PayClass?.XRefCode == "FTC");
        }

        private static bool IsTerminatedEmployee(TerminatedEmployeeEventModel terminatedEmployeeEvent)
        {
            if (terminatedEmployeeEvent.EmploymentStatus.XRefCode == "TERMINATED")
            {
                return true;
            }
            //else if (terminatedEmployeeEvent.EffectiveEnd != null && terminatedEmployeeEvent.EffectiveEnd.Value <= DateTime.UtcNow)
            //{
            //    return true;
            //}
            else { return false; }

        }

       

        private static async Task<NewEmployeeRequest> MapToTerminatedEmployees(EmployeeDetailsResponse? employeeDetails)
        {

            NewEmployeeRequest terminatedEmployeeRequest = new NewEmployeeRequest();

            terminatedEmployeeRequest.Event = "Offboard";
            terminatedEmployeeRequest.EmployeeDetails = new HRIS.Pega.Models.Pega.EmployeeDetails();
            terminatedEmployeeRequest.EmployeeDetails.EmployeeID = employeeDetails.Data.XRefCode;
            if (employeeDetails.Data.SSOAccounts != null && !string.IsNullOrWhiteSpace(employeeDetails.Data.SSOAccounts.Items[0]?.LoginName))
            {
                terminatedEmployeeRequest.EmployeeDetails.NetworkID = employeeDetails.Data.SSOAccounts.Items[0].LoginName;
            }
            terminatedEmployeeRequest.EmployeeDetails.FirstName = employeeDetails.Data.FirstName;
            terminatedEmployeeRequest.EmployeeDetails.LastName = employeeDetails.Data.LastName;
            terminatedEmployeeRequest.EmployeeDetails.PreferredName = employeeDetails.Data.FirstName;
            terminatedEmployeeRequest.EmployeeDetails.DateOfBirth = employeeDetails.Data.BirthDate?.ToString("dd/MM/yyyy");
            terminatedEmployeeRequest.EmployeeDetails.JoinedDate = employeeDetails.Data.HireDate?.ToString("dd/MM/yyyy");
            if (employeeDetails.Data.Contacts != null && employeeDetails.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").Count() > 0)
            {
                var emailAddress = employeeDetails.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessEmail").FirstOrDefault();
                terminatedEmployeeRequest.EmployeeDetails.EmailID = emailAddress.ElectronicAddress;

            }
            if (employeeDetails.Data.Contacts != null && employeeDetails.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessMobile").Count() > 0)
            {
                var phoneDetails = employeeDetails.Data.Contacts.Items.Where(x => x.ContactInformationType.XRefCode == "BusinessMobile").FirstOrDefault();
                terminatedEmployeeRequest.EmployeeDetails.MobileNumber = phoneDetails.Location.BusinessPhone;

            }
            if (employeeDetails.Data.Addresses != null && employeeDetails.Data.Addresses.Items.Where(x => x.ContactInformationType.XRefCode == "PrimaryResidence").Count() > 0)
            {
                var primaryAddress = employeeDetails.Data.Addresses.Items.Where(x => x.ContactInformationType.XRefCode == "PrimaryResidence").FirstOrDefault();
                terminatedEmployeeRequest.EmployeeDetails.AddressDetails.Line1 = primaryAddress.Address1;
                terminatedEmployeeRequest.EmployeeDetails.AddressDetails.Suburb = primaryAddress.City;
                terminatedEmployeeRequest.EmployeeDetails.AddressDetails.PostCode = primaryAddress.PostalCode;
                terminatedEmployeeRequest.EmployeeDetails.AddressDetails.State = primaryAddress.State.XRefCode;
            }


            if (employeeDetails.Data.WorkAssignments != null && employeeDetails.Data.WorkAssignments.Items.Where(x => x.IsPrimary == true).Count() > 0)
            {
                var positionDetails = employeeDetails.Data.WorkAssignments.Items.Where(x => x.IsPrimary == true).FirstOrDefault();
                if (positionDetails != null && positionDetails.PMPositionAssignment?.PMPosition != null)
                {
                    terminatedEmployeeRequest.EmployeeDetails.PositionDetails = new HRIS.Pega.Models.Pega.PositionDetails
                    {
                        PositionID = positionDetails.PMPositionAssignment.PMPosition.XRefCode,
                        Desc = positionDetails.PMPositionAssignment.PMPosition.ShortName,
                    };
                }

            }
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails = new HeaderDetails();
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.SourceSystemID = "Dayforce";
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.BusinessReferenceID = "ID";
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.InterfaceHeader = "Header";
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.InterfaceName = "INT243";
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.InterfaceVersion = "V1";
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.MessageType = "Offboard";
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.SourceInformation = "Dayforce";
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.SourceSystemID = "Dayforce";
            terminatedEmployeeRequest.EmployeeDetails.HeaderDetails.Timestamp = DateTime.UtcNow.ToString("dd/MM/yyyy");


            return terminatedEmployeeRequest;
        }

    }
    

    public class TerminatedEvent
    {
         [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("topic")]
        public string Topic { get; set; }

        [JsonPropertyName("subject")]
        public string Subject { get; set; }

        [JsonPropertyName("eventType")]
        public string EventType { get; set; }

        [JsonPropertyName("eventTime")]
        public string EventTime { get; set; }

         [JsonPropertyName("data")]
        public TerminatedEmployeeEventModel Data { get; set; }
        // [JsonPropertyName("dataVersion")]
        public string DataVersion { get; set; }
    }

   

}
