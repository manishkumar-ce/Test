using System.Net;
using HRIS.Pega.Helpers;
using HRIS.Pega.Helpers.Interfaces;
using HRIS.Pega.Models;
using HRIS.Pega.Models.Dayforce;
using HRIS.Pega.Repository.Http.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.VisualBasic;
using Newtonsoft.Json;


namespace HRIS.Pega.FunApp

{
    public class PositionReports
    {
        private readonly ILogger<PositionReports> _logger;
        private readonly IRestApiRepository _restApiRepository;
        private readonly IServiceBusPublisher _serviceBusPublisher;

        public PositionReports(ILogger<PositionReports> logger, IRestApiRepository restApiRepository, IServiceBusPublisher serviceBusPublisher)
        {
            _logger = logger;
            _restApiRepository = restApiRepository;
            _serviceBusPublisher = serviceBusPublisher;
        }

        [Function("PositionReports")]
        public  async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = "positions")] HttpRequest req)
        {
            try
            {
                _logger.LogInformation("Started processing get position repots");
               
                var res = await _restApiRepository.GetPositionDetails();
                if (res.StatusCode == HttpStatusCode.NotFound || res.StatusCode == HttpStatusCode.BadRequest)
                {
                    new BadRequestObjectResult($"Error Fetching Data from Dayforce . {res.Content.ReadAsStringAsync()}");
                }
                if (res.StatusCode != HttpStatusCode.OK)
                {
                    //await SendErrorHandlerEvent(res.Content.ReadAsStringAsync().Result);
                    return new StatusCodeResult((int)HttpStatusCode.InternalServerError);

                }
                var content = await res.Content.ReadAsStringAsync();

                var positionResponse = JsonConvert.DeserializeObject<PositionResponseModel>(content);

                var apiResponse = positionResponse.ToPostionReportsResponse();
                return (ActionResult)new OkObjectResult(apiResponse);
            }

            catch (Exception ex)
            {
                _logger.LogError($"Error while fetching position details : {ex.Message}");
                await SendErrorHandlerEvent(ex.Message);
                return new StatusCodeResult((int)HttpStatusCode.InternalServerError);
            }

               
        }

        private async Task SendErrorHandlerEvent(string errorMessage)
        {
            ErrorMessage message = new ErrorMessage();
            message.ErrorDetails = errorMessage;
            message.InterfaceName = "Get Positions Report";
            message.SystemName = "Pega";
            var errorHandlerMessage = new ErrorHandlerMessage();
            errorHandlerMessage.HtmlBody = message.ToEmailHtmlContent();
            errorHandlerMessage.Subject = message.ToEmailSubject();
            errorHandlerMessage.RecipientAddress = Environment.GetEnvironmentVariable("RecipientEmail");
            await _serviceBusPublisher.SendMessageAsync(errorHandlerMessage);
        }
    }
}
