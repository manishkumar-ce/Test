using HRIS.Pega.Helpers;
using HRIS.Pega.Helpers.Interfaces;
using HRIS.Pega.Repository.Http;
using HRIS.Pega.Repository.Http.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.ApplicationInsights;



namespace  HRIS.Pega.FunApp
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection ConfigureLoggingRules(this IServiceCollection services)
        {
            string appInsightLoggerProviderName = typeof(ApplicationInsightsLoggerProvider).FullName;
            services.Configure<LoggerFilterOptions>(options =>
            {


                var defaultRule = options.Rules.FirstOrDefault(rule => rule.ProviderName == appInsightLoggerProviderName);
                if (defaultRule != null)
                {
                    options.Rules.Remove(defaultRule);
                }
                var loggingRule = new LoggerFilterRule(appInsightLoggerProviderName, null, LogLevel.Information, null);
                options.Rules.Add(loggingRule);
            });

            return services;

        }

        public static IServiceCollection ConfigureApplicationServices(this IServiceCollection services)
        {
            services.AddApplicationInsightsTelemetryWorkerService();
            services.ConfigureFunctionsApplicationInsights();
            RegisterServices(services);
            //RegisterServiceBusClient(services);
            RegisterApiClient(services);
            return services;
            
        }

        static void RegisterServices(IServiceCollection services)
        {
            services.AddScoped<IServiceBusPublisher, ServiceBusPublisher>();
            services.AddScoped<IRestApiRepository, RestApiRepository>();

        }

        static void RegisterServiceBusClient(IServiceCollection services)
        {
            services.AddAzureClients(azureClientsFactoryBuilder =>
            {

                var serviceBusNamespace = Environment.GetEnvironmentVariable("ServiceBusConnection__fullyQualifiedNamespace");
                azureClientsFactoryBuilder.AddServiceBusClientWithNamespace(serviceBusNamespace)
                .ConfigureOptions(options =>
                {

                    options.RetryOptions.Mode = Azure.Messaging.ServiceBus.ServiceBusRetryMode.Exponential;
                    options.RetryOptions.Delay = TimeSpan.FromMilliseconds(50);
                    options.RetryOptions.MaxDelay = TimeSpan.FromSeconds(2);
                    options.RetryOptions.MaxRetries = 5;
                }).WithName("AISServiceBusClient");

            });

        }

        static void RegisterApiClient(IServiceCollection services)
        {

            var apiClientName = "ApiClient";
            var apimBaseUrl = Environment.GetEnvironmentVariable("APIMbaseUrl");
            
            if (string.IsNullOrEmpty(apimBaseUrl))
            {
                throw new Exception("Apim base url is null or empty");
            }
           
            services.AddHttpClient(apiClientName, httpClient =>
            {

                httpClient.BaseAddress = new Uri(apimBaseUrl);
                httpClient.DefaultRequestHeaders.Add("ocp-apim-subscription-key", Environment.GetEnvironmentVariable("ApimSubscriptionKey"));

            })
                .SetHandlerLifetime(TimeSpan.FromSeconds(5))               
                .AddStandardResilienceHandler(options =>
             {
                 options.TotalRequestTimeout.Timeout = TimeSpan.FromSeconds(120);
                 options.AttemptTimeout.Timeout = TimeSpan.FromSeconds(60);
                 options.CircuitBreaker.SamplingDuration = TimeSpan.FromSeconds(120);
             });
        }


    }
}
