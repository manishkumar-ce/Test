﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using HRIS.Pega.Repository.Http.Interfaces;
using Microsoft.Extensions.Logging;

namespace HRIS.Pega.Repository.Http
{
    public class RestApiRepository : IRestApiRepository
    {
        private readonly ILogger<IRestApiRepository> _logger;
        private readonly string _logSource;
        private readonly HttpClient _httpClient;

        public RestApiRepository (IHttpClientFactory httpClient, ILogger<IRestApiRepository> logger)
        {
            _httpClient = httpClient.CreateClient("ApiClient");
            _logger = logger;
        }

        public async Task<HttpResponseMessage> GetEmployeeDetails(String xRefCode, string expandQuery)
        {
            try
            {
                _logger.LogInformation($"Started processing GetEmployeeDetails for employee xrefCode {xRefCode}");
                var response = new HttpResponseMessage();
                var url = $"api/v1/dayforce/employees/{xRefCode}?expand={expandQuery}";
                response = await _httpClient.GetAsync(url);


                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;

            }

        }
        public async Task<HttpResponseMessage> GetPortfolioDetails()
        {
            try
            {
                _logger.LogInformation("Started processing GetPortfolioDetails");
                var response = new HttpResponseMessage();
                var url = "api/v1/dayforce/references/portfolios";
                response = await _httpClient.GetAsync(url);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;

            }
        }

        public async Task<HttpResponseMessage> PostPegaEmployee( string newEmployeeRequest)
        {

            try
            {
                _logger.LogInformation("Started processing PostPegaNewEmployee");
                var response = new HttpResponseMessage();
                var url = "api/v1/pega/employees";
                var httpContent = new StringContent(newEmployeeRequest, Encoding.UTF8, "application/json");
                response = await _httpClient.PostAsync(url, httpContent);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;

            }
        }


        public async Task<HttpResponseMessage> GetPositionDetails()
        {
            try
            {
                _logger.LogInformation("Started processing GetPositionDetails");
                var response = new HttpResponseMessage();
                var url = "api/v1/dayforce/reports/positions";
                response = await _httpClient.GetAsync(url);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;

            }
        }

        
    }
}
