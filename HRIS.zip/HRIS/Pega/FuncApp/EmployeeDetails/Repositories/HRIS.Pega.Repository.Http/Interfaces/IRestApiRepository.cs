﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRIS.Pega.Repository.Http.Interfaces
{
    public interface IRestApiRepository
    {

        Task<HttpResponseMessage> GetEmployeeDetails(String xRefCode, string expandQuery);
        Task<HttpResponseMessage> GetPortfolioDetails();

        Task<HttpResponseMessage> PostPegaEmployee(string newEmployeeRequest);

        

        Task<HttpResponseMessage> GetPositionDetails();

    }
}
