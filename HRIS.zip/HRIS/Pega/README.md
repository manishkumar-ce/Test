# Introduction 
This solution contains workflows/functions fulfilling Pega integration #271 , #243, #278.

# API references
https://developers.dayforce.com/
