
> **Note on Deployment Modes**: The deployment mode used in the Bicep files is **incremental**. This means that during deployment, resources that exist in the resource group but are not specified in the Bicep file will remain unchanged. Only the resources defined in the Bicep file will be added or updated. This mode is useful for ensuring that existing resources are not 
inadvertently deleted.


### Directory Structure

```plaintext
HRIS/
├── modules/
├── resource-groups/
│   ├── main.bicep
│   ├── parameters.json
├── pipelines/
│   ├── azure-pipelines.yml
│   ├── templates/
│   │   ├── build-template.yml
│   │   ├── deploy-template.yml
├── .gitignore
├── README.md
└── azuredeploy.bicep
```

### Explanations

#### [`modules/`]
- **Purpose**: This directory is intended for reusable Bicep modules. Each module can represent a specific Azure resource or a set of related resources.
- **Usage**: Create subdirectories for each module (e.g., `network`, `compute`, `storage`) and include `main.bicep`, `variables.bicep`, and `outputs.bicep` files as needed.

#### `resource-groups/`
- **Purpose**: Contains Bicep files and parameters for resource group configurations.
- **Files**:
  - `main.bicep`: Defines the resource group. The `targetScope` is set to `subscription` to allow resource group creation.
  - `parameters.json`: Contains parameter values for the Bicep file. This can be used to pass environment-specific values.

#### [`pipelines/`]
- **Purpose**: Contains Azure Pipelines YAML files and templates for CI/CD.
- **Files**:
  - `azure-pipelines.yml`: Main pipeline configuration file. Defines the stages and jobs for building and deploying the infrastructure.
  - `templates/`: Contains reusable pipeline templates.
    - `build-template.yml`: Template for the build stage. Typically includes steps for validating and linting Bicep files.
    - [`deploy-template.yml`]: Template for the deploy stage. Uses Azure CLI to deploy the Bicep files. The [`environment`] parameter is passed from the pipeline.

#### `.gitignore`
- **Purpose**: Specifies files and directories to be ignored by Git.
- **Usage**: Add patterns for files and directories that should not be tracked by version control, such as state files, logs, and temporary files.

#### [`README.md`]
- **Purpose**: Provides documentation for the project.
- **Usage**: Include information about the project, directory structure, usage instructions, and any other relevant details.

#### `azuredeploy.bicep`
- **Purpose**: The main Bicep file for deploying the infrastructure.
- **Usage**: This file can include or reference other Bicep modules and files to define the complete infrastructure.

### Example Files

#### `resource-groups/main.bicep`
```bicep
targetScope = 'subscription'

param environment string

resource rg 'Microsoft.Resources/resourceGroups@2021-04-01' = {
  name: 'rg-HRIS-${environment}'
  location: 'australiaeast'
  tags: {
    environment: environment
  }
}
```

#### `resource-groups/parameters.json`
```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "environment": {
      "value": "devtest"
    }
  }
}
```

#### [`pipelines/azure-pipelines.yml`]
```yaml
trigger:
- main

pool:
  vmImage: 'ubuntu-latest'

variables:
  - name: environment
    value: 'devtest'  # Default value, can be overridden

stages:
- stage: Build
  jobs:
  - job: Build
    steps:
    - template: templates/build-template.yml

- stage: Deploy
  jobs:
  - job: Deploy
    steps:
    - template: templates/deploy-template.yml
      parameters:
        environment: $(environment)
```

#### `pipelines/templates/build-template.yml`
```yaml
steps:
- script: echo "Building the project..."
  displayName: 'Build Project'
```

#### [`pipelines/templates/deploy-template.yml`]
```yaml
parameters:
  - name: environment
    type: string

steps:
- script: |
    az deployment group create \
      --resource-group rg-HRIS-$(environment) \
      --template-file resource-groups/main.bicep \
      --parameters environment=$(environment)
  displayName: 'Deploy Infrastructure'
```

