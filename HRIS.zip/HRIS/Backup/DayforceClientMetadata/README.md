# Introduction 
HRIS is the Human Resources Integration Solution project and will run all the integrations to keep HR running.

# Getting Started
HRIS has a dependence on the AIS projects that is setup using Git submodules. 
after you check out this project you need to retriev the AIS submodlule by runnning these git commands 

`$ git submodule init`

`$ git submodule update`

# Build and Test
The build pipelines for this project are visible here: [HRIS build Pipelines](https://dev.azure.com/mwcloud/HRIS/_build)


# Markdown reference
use this reference get some info about formatting markdown [Github basic markdown formatting](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax)