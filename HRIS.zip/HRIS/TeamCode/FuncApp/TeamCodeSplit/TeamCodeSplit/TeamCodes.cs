using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace HRIS.TeamCode.FuncApp;

public class TeamCodes
{
    private readonly ILogger<TeamCodes> _logger;

    public TeamCodes(ILogger<TeamCodes> logger)
    {
        _logger = logger;

    }

    [Function("CodeSplit")]
    public IActionResult Run([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequest req)
    {
        try
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
            return new OkObjectResult("Welcome to Azure Functions!");
        }
        catch(Exception ex)
        {

        }
    }
}